"""
okelas_client.py — lớp adapter DUY NHẤT nơi backend của website gửi KẾT QUẢ
ĐÃ TÍNH XONG sang OKELAS Core.

SỬA LẠI SAU KHI PHÁT HIỆN HIỂU SAI KIẾN TRÚC:

Phiên bản trước của file này coi OKELAS Core là nơi THỰC HIỆN tính điểm
(website chỉ forward raw answers). Đó là sai. Kiến trúc đúng:

  - Website (main.py + scoring_engine.py) tính TOÀN BỘ điểm/level/flag, LUÔN
    LUÔN, không phụ thuộc OKELAS Core có sẵn sàng hay không.
  - okelas_client.py ở đây chỉ làm MỘT việc: gửi kết quả đã tính xong (+ raw
    answers để lưu Evidence đầy đủ) sang OKELAS Core, để Core ghi Evidence và
    route vào Consultant Workflow (xem
    workflow-definitions/consultant_intake_workflow.json). Core không tính
    lại bất kỳ giá trị nào.
  - Vì đây chỉ là một notify/handoff (không phải bước tính toán), việc gọi
    OKELAS Core KHÔNG ĐƯỢC làm chậm hoặc chặn phản hồi cho người dùng trên
    website. Nếu OKELAS Core không phản hồi được, người dùng vẫn phải thấy
    kết quả của mình — lỗi notify chỉ được log lại để retry/theo dõi sau.

Có 2 cách triển khai:

  1. HttpOkelasCoreClient — dùng trong production. Gọi thật vào OKELAS Core
     API (của instance "OKELAS of OKELAS"). Endpoint/contract cụ thể (path,
     auth, payload envelope) hiện ĐANG LÀ GIẢ ĐỊNH (xem TODO bên dưới) vì
     tài liệu API thật của OKELAS Core chưa được cung cấp cho phiên làm việc
     này — cần thay bằng contract thật trước khi deploy.

  2. NoOpLoggingClient — dùng khi chưa nối được OKELAS Core thật (local dev,
     demo, staging chưa có instance). Nó KHÔNG tính toán gì (không còn lý do
     để "giả lập" một workflow chấm điểm vì phần đó luôn chạy ở
     scoring_engine.py) — nó chỉ ghi log ra để biết payload nào lẽ ra đã được
     gửi đi.
"""

from __future__ import annotations

import logging
import os
from abc import ABC, abstractmethod
from typing import Any

import httpx

logger = logging.getLogger("okelas_client")


class OkelasCoreClient(ABC):
    """Interface duy nhất mà main.py được phép gọi để HANDOFF kết quả đã
    tính xong sang OKELAS Core. Không có phương thức nào ở đây được dùng để
    tính toán — chỉ để gửi đi và ghi nhận."""

    @abstractmethod
    async def notify_consultant_intake(
        self,
        assessment_id: str,
        respondent: dict[str, Any],
        raw_answers: list[dict[str, Any]],
        computed_result: dict[str, Any],
        submission_id: str,
    ) -> None:
        """Gửi kết quả ĐÃ TÍNH XONG sang OKELAS Core. Không trả về gì mà
        main.py cần dùng để build response cho người dùng — response cho
        người dùng đã được build xong từ computed_result trước khi gọi hàm
        này. Nếu implementation này raise exception, main.py phải bắt lại và
        chỉ log, KHÔNG được để lỗi này ảnh hưởng tới response cho người dùng.
        """
        raise NotImplementedError


class HttpOkelasCoreClient(OkelasCoreClient):
    """Triển khai production — gọi thật vào OKELAS Core.

    TODO (bắt buộc xác nhận trước khi deploy — chưa có tài liệu API OKELAS
    Core thật trong phiên làm việc này):
      - Path chính xác của endpoint nhận consultant intake (giả định REST
        theo mô hình Process/Workflow/Event của 01_Context; nếu OKELAS Core
        dùng Frappe/DocType-style API như ERPNext thì path và envelope sẽ
        khác, ví dụ /api/method/okelas.workflow.trigger).
      - Cơ chế xác thực (giả định Bearer token qua OKELAS_CORE_API_KEY).
      - Envelope JSON chính xác OKELAS Core mong đợi (ở đây giả định
        {"event_type", "workflow_id", "data"}), khớp với input_schema trong
        workflow-definitions/consultant_intake_workflow.json.
    """

    def __init__(self) -> None:
        self.base_url = os.environ["OKELAS_CORE_BASE_URL"].rstrip("/")
        self.api_key = os.environ["OKELAS_CORE_API_KEY"]
        self._client = httpx.AsyncClient(
            base_url=self.base_url,
            headers={"Authorization": f"Bearer {self.api_key}"},
            timeout=10.0,
        )

    async def notify_consultant_intake(
        self,
        assessment_id: str,
        respondent: dict[str, Any],
        raw_answers: list[dict[str, Any]],
        computed_result: dict[str, Any],
        submission_id: str,
    ) -> None:
        payload = {
            "event_type": "website.assessment_result.computed",
            "workflow_id": "consultant_assessment_intake",
            "source": "website_backend",
            "data": {
                "assessment_id": assessment_id,
                "respondent": respondent,
                "raw_answers": raw_answers,
                "computed_result": computed_result,
                "submission_id": submission_id,
            },
        }
        # Fire-and-forget về phía trải nghiệm người dùng: lỗi ở đây không
        # được raise ngược lên main.py làm hỏng response đã trả cho người
        # dùng — main.py bọc lời gọi này trong try/except khi dùng.
        response = await self._client.post(
            "/api/v1/workflows/consultant-intake", json=payload
        )
        response.raise_for_status()

    async def aclose(self) -> None:
        await self._client.aclose()


class NoOpLoggingClient(OkelasCoreClient):
    """Dev/demo fallback khi chưa có OKELAS_CORE_BASE_URL. KHÔNG tính toán gì
    (không còn cần "giả lập workflow" vì scoring đã luôn chạy ở website) —
    chỉ log lại payload lẽ ra đã được gửi, để dev thấy được handoff sẽ trông
    như thế nào khi nối OKELAS Core thật."""

    async def notify_consultant_intake(
        self,
        assessment_id: str,
        respondent: dict[str, Any],
        raw_answers: list[dict[str, Any]],
        computed_result: dict[str, Any],
        submission_id: str,
    ) -> None:
        logger.info(
            "OKELAS_CORE_BASE_URL chưa được cấu hình — chỉ log, không gửi đi. "
            "submission_id=%s assessment_id=%s level=%s flags=%s",
            submission_id,
            assessment_id,
            computed_result.get("level"),
            computed_result.get("flags"),
        )


def build_okelas_client() -> OkelasCoreClient:
    """Factory — chọn implementation dựa trên biến môi trường.

    Production: đặt OKELAS_CORE_BASE_URL + OKELAS_CORE_API_KEY trỏ vào
    instance 'OKELAS of OKELAS' -> dùng HttpOkelasCoreClient.
    Local/demo: không đặt -> dùng NoOpLoggingClient (chỉ log, không tính gì).
    """
    if os.environ.get("OKELAS_CORE_BASE_URL"):
        return HttpOkelasCoreClient()
    return NoOpLoggingClient()
