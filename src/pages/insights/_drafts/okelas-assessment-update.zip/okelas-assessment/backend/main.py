"""
OKELAS Assessment API — backend cho okelas.com/assessment.

SỬA LẠI SAU KHI PHÁT HIỆN HIỂU SAI KIẾN TRÚC — vai trò của file này bây giờ:

  1. Serve config câu hỏi cho frontend.
  2. Nhận submission, validate hình dạng dữ liệu.
  3. Chống spam cơ bản (honeypot field).
  4. TÍNH TOÀN BỘ điểm/level/flag NGAY TẠI ĐÂY bằng AssessmentScoringEngine —
     đây là bước tính toán DUY NHẤT trong toàn hệ thống, luôn chạy ở website.
  5. Trả kết quả cho người dùng NGAY, không chờ OKELAS Core.
  6. Sau đó (không chặn response), gọi okelas_client để NOTIFY kết quả đã
     tính xong sang OKELAS Core — Core chỉ ghi Evidence + route vào
     Consultant Workflow, không tính toán lại gì.

Nếu bước 6 lỗi (OKELAS Core không phản hồi được), người dùng vẫn phải nhận
được kết quả của họ — lỗi notify chỉ được log lại.
"""

from __future__ import annotations

import logging

from fastapi import FastAPI, HTTPException
from fastapi.middleware.cors import CORSMiddleware

from .models import (
    AssessmentSubmission,
    PublicAssessmentResult,
    PublicResultRelatedLink,
)
from .okelas_client import build_okelas_client
from .scoring_engine import AssessmentScoringEngine, ValidationError

logger = logging.getLogger("okelas_assessment_api")

app = FastAPI(
    title="OKELAS Assessment API",
    description=(
        "Public assessment intake cho okelas.com. Toàn bộ điểm/level tính "
        "tại đây (scoring_engine.py) — OKELAS Core chỉ nhận kết quả, không "
        "tính lại."
    ),
    version="2.0.0",
)

# Giới hạn origin thật khi deploy — để rộng ở đây cho môi trường dev.
app.add_middleware(
    CORSMiddleware,
    allow_origins=["https://okelas.com", "https://www.okelas.com"],
    allow_methods=["GET", "POST"],
    allow_headers=["*"],
)

scoring_engine = AssessmentScoringEngine()
okelas_client = build_okelas_client()

# Bài viết liên quan theo assessment — tham chiếu 03_Pillar_Map §5
# "Mapping bài viết → assessment". Slug là placeholder, cập nhật khi có
# đường dẫn thật trên website.
RELATED_LINKS: dict[str, list[PublicResultRelatedLink]] = {
    "erp_readiness": [
        PublicResultRelatedLink(
            title="Doanh nghiệp bạn đã thực sự sẵn sàng triển khai ERP chưa?",
            url="/knowledge/erp-readiness-danh-gia-ban-dau",
        ),
        PublicResultRelatedLink(
            title="Quy trình chưa chuẩn hoá — rủi ro lớn nhất trước khi triển khai ERP",
            url="/knowledge/quy-trinh-chua-chuan-hoa-rui-ro-erp",
        ),
    ],
    "ai_readiness": [
        PublicResultRelatedLink(
            title="AI giúp nhân viên viết nhanh hơn, nhưng doanh nghiệp có xử lý được nhiều hơn không?",
            url="/knowledge/ai-nang-suat-vs-organizational-intelligence",
        ),
        PublicResultRelatedLink(
            title="AI readiness: 6 điều kiện để AI thực sự có ích trong vận hành",
            url="/knowledge/ai-readiness-6-dieu-kien",
        ),
    ],
    "km_maturity": [
        PublicResultRelatedLink(
            title="Khi nhân sự chủ chốt nghỉ việc, họ mang đi thứ gì?",
            url="/knowledge/nhan-su-nghi-viec-mang-di-tri-thuc",
        ),
        PublicResultRelatedLink(
            title="SOP có nhưng không được thực thi — tại sao?",
            url="/knowledge/sop-khong-duoc-thuc-thi",
        ),
    ],
    "digitalization_level": [
        PublicResultRelatedLink(
            title="Doanh nghiệp của bạn đang ở giai đoạn số hóa nào?",
            url="/knowledge/doanh-nghiep-dang-o-giai-doan-so-hoa-nao",
        ),
        PublicResultRelatedLink(
            title="Paperless không phải chuyển đổi số — đây là sự khác biệt",
            url="/knowledge/paperless-khong-phai-chuyen-doi-so",
        ),
    ],
}


@app.get("/api/assessment/{assessment_id}/questions")
async def get_questions(assessment_id: str) -> dict:
    """Trả về config câu hỏi cho frontend render (title, intro, questions).

    Không trả về bảng 'levels' — người dùng không cần biết ngưỡng điểm khi
    đang trả lời, tránh việc họ chọn đáp án để "đạt mức cao" thay vì phản
    ánh đúng thực tế (giữ đúng tinh thần giảm overclaim ở 05_Question_Sets §1).
    """
    try:
        config = scoring_engine.get_question_config(assessment_id)
    except ValidationError as exc:
        raise HTTPException(status_code=404, detail=str(exc)) from exc

    return {
        "assessment_id": config["assessment_id"],
        "title": config["title"],
        "intro": config["intro"],
        "questions": [
            {
                "id": q["id"],
                "text": q["text"],
                "type": q.get("type", "single_select"),
                "options": [
                    {"key": o["key"], "text": o["text"]}
                    for o in q.get("options", [])
                ],
            }
            for q in config["questions"]
        ],
    }


@app.post("/api/assessment/submit", response_model=PublicAssessmentResult)
async def submit_assessment(submission: AssessmentSubmission) -> PublicAssessmentResult:
    # Chống spam cơ bản: honeypot field phải rỗng.
    if submission.honeypot:
        raise HTTPException(status_code=400, detail="Invalid submission")

    respondent_dict = submission.respondent.model_dump()
    answers_dict = [a.model_dump() for a in submission.answers]

    # BƯỚC TÍNH TOÁN DUY NHẤT — luôn chạy tại website, không phụ thuộc OKELAS Core.
    try:
        computed_result = scoring_engine.compute_result(
            submission.assessment_id, answers_dict
        )
    except ValidationError as exc:
        raise HTTPException(status_code=422, detail=str(exc)) from exc

    public_result = PublicAssessmentResult(
        assessment_id=submission.assessment_id,
        level=computed_result.get("level"),
        label=computed_result.get("label"),
        description=computed_result.get("description"),
        insufficient_data_message=computed_result.get("insufficient_data_message"),
        related_links=RELATED_LINKS.get(submission.assessment_id, []),
        submission_id=computed_result["submission_id"],
    )

    # Handoff sang OKELAS Core — CHỈ NOTIFY, không tính toán, và KHÔNG được
    # phép làm hỏng response đã sẵn sàng cho người dùng nếu thất bại.
    try:
        await okelas_client.notify_consultant_intake(
            assessment_id=submission.assessment_id,
            respondent=respondent_dict,
            raw_answers=answers_dict,
            computed_result=computed_result,
            submission_id=computed_result["submission_id"],
        )
    except Exception:  # noqa: BLE001 — cố ý bắt rộng, đây là notify phụ, không phải happy path
        logger.exception(
            "Gửi kết quả sang OKELAS Core thất bại (submission_id=%s) — "
            "người dùng vẫn nhận được kết quả bình thường, cần retry/theo dõi riêng.",
            computed_result["submission_id"],
        )

    return public_result


@app.get("/health")
async def health() -> dict:
    return {"status": "ok"}
