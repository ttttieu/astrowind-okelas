# OKELAS Assessment — Website Widget + Handoff sang OKELAS of OKELAS

Code cho bước "tiến hành assessment trên website okelas.com, đồng thời chuyển
kết quả thành đầu vào cho OKELAS of OKELAS (nội bộ)". Đây là bản triển khai
tham chiếu, đã chạy test thật (xem `docs/TEST_LOG.md`), sẵn sàng để tích hợp
— với một số điểm **bắt buộc xác nhận lại** trước khi đưa vào production
(liệt kê ở mục 5).

> **Lưu ý version 2.0:** phiên bản đầu của tài liệu/code này từng đặt sai vị
> trí logic tính điểm (đẩy sang phía OKELAS Core). Đã sửa lại toàn bộ theo
> đúng yêu cầu gốc — xem mục 1.

---

## 1. Nguyên tắc kiến trúc bắt buộc (đến từ yêu cầu của bạn)

> "Tất cả mọi assessment và phân tích về nó thực hiện ở website, OKELAS Core
> (OKELAS of OKELAS) chỉ nhận kết quả và đưa vào process cho consultant thực
> hiện."

Cách hiện thực hoá nguyên tắc này trong code:

* **Toàn bộ logic tính điểm/level/flag chỉ tồn tại ở MỘT nơi, và nơi đó là
  WEBSITE BACKEND**: [`backend/scoring_workflow.json`](backend/scoring_workflow.json)
  (đặc tả khai báo) được thực thi bởi
  [`backend/scoring_engine.py`](backend/scoring_engine.py) — chạy **thường
  trực, cho mọi submission**, không phụ thuộc OKELAS Core có sẵn sàng hay
  không.
* OKELAS Core **không đọc, không thực thi** file scoring này. Core chỉ nhận
  **kết quả đã tính xong** (qua `backend/okelas_client.py`) và thực hiện
  đúng một việc: ghi Evidence + route vào **Consultant Workflow** — process
  thật sự "được xây dựng để phục vụ khách hàng" (Discover → Assess →
  Diagnose → Design → Implement → Improve, theo `04_Verification_Framework`)
  — xem [`workflow-definitions/consultant_intake_workflow.json`](workflow-definitions/consultant_intake_workflow.json).
* Việc gửi kết quả sang OKELAS Core là **notify, không phải bước tính toán**
  — nếu OKELAS Core không phản hồi được, **người dùng trên website vẫn phải
  nhận được kết quả của họ** (đã test thật, xem `docs/TEST_LOG.md` mục 3).
  Lỗi notify chỉ được log lại để retry/theo dõi riêng, không được raise
  ngược lên làm hỏng trải nghiệm người dùng.

## 2. Luồng dữ liệu

```
[Người dùng trên okelas.com]
        |
        v
frontend/assessment-widget.html   (render câu hỏi từ config/questions_*.json,
        |                          không tính điểm ở client)
        | POST /api/assessment/submit
        v
backend/main.py
        |
        |-- (1) validate + chống spam
        |-- (2) scoring_engine.compute_result(...)   <-- TÍNH TOÀN BỘ Ở ĐÂY,
        |         thực thi backend/scoring_workflow.json (validate_submission
        |         -> compute_dimension_scores -> compute_overall_average
        |         -> classify_level -> detect_straight_lining_flag
        |         -> detect_contradiction_signal -> generate_public_output)
        |-- (3) TRẢ KẾT QUẢ CHO NGƯỜI DÙNG NGAY (không chờ bước 4)
        |-- (4) okelas_client.notify_consultant_intake(...)  <-- fire-and-forget,
        |         lỗi ở đây chỉ log, KHÔNG ảnh hưởng response đã trả ở bước 3
        v
=== ranh giới: từ đây là OKELAS Core, KHÔNG tính toán lại gì ===
        |
workflow-definitions/consultant_intake_workflow.json
        |  (create_evidence_record -> route_to_consultant_workflow
        |   -> create_task_if_flagged)
        v
   [Evidence record] + [WorkflowInstance của Consultant Workflow, bắt đầu
    ở bước "Assess"] + [Task ưu tiên cho consultant nếu bị flag]
```

Vì Consultant Workflow (Discover→Assess→Diagnose→...) là process thật sự
dùng chung giữa nội bộ và on-prem khách hàng, đúng nguyên tắc "OKELAS Core
không chạy thêm phân tích, chỉ tiến hành theo process/workflow phục vụ khách
hàng" — nhưng phần **tính điểm form self-assessment** không thuộc process
đó, nó là logic intake của website.

## 3. Cấu trúc thư mục

```
okelas-assessment/
├── config/
│   ├── questions_erp.json         # 4 bộ câu hỏi — nguồn từ 05_Question_Sets.md
│   ├── questions_ai.json
│   ├── questions_km.json
│   └── questions_dig.json
├── backend/
│   ├── main.py                    # FastAPI — tính điểm tại đây, notify OKELAS Core sau
│   ├── models.py                  # Pydantic schema (request/response)
│   ├── scoring_engine.py          # Thực thi scoring_workflow.json — THƯỜNG TRỰC ở website
│   ├── scoring_workflow.json      # NGUỒN DUY NHẤT của logic scoring/level/flag (thuộc website)
│   ├── okelas_client.py           # Adapter NOTIFY kết quả sang OKELAS Core (không tính toán)
│   └── requirements.txt
├── workflow-definitions/
│   └── consultant_intake_workflow.json  # Workflow THẬT của OKELAS Core: chỉ ghi Evidence
│                                          # + route vào Consultant Workflow, không tính lại gì
├── frontend/
│   └── assessment-widget.html     # Widget tự chứa (HTML/CSS/JS thuần), nhúng iframe được
└── docs/
    └── TEST_LOG.md                # Bằng chứng đã chạy test thật trước khi bàn giao
```

## 4. Chạy thử local

```bash
cd backend
pip install -r requirements.txt
uvicorn main:app --reload --port 8000
```

Mở `frontend/assessment-widget.html` bằng một static server bất kỳ (hoặc
`python3 -m http.server` trong thư mục `frontend/`), đổi `API_BASE` trong file
nếu backend không chạy ở `/api` cùng origin.

Ở chế độ này, `okelas_client.py` tự động dùng `NoOpLoggingClient` (không cần
biến môi trường nào) — nó **không tính toán gì cả** (vì scoring luôn chạy ở
`scoring_engine.py`, độc lập với việc có OKELAS Core hay không), chỉ log lại
payload lẽ ra đã được gửi đi, để bạn thấy handoff sẽ trông như thế nào khi
nối OKELAS Core thật.

## 5. Việc BẮT BUỘC xác nhận trước khi deploy production

Phần này quan trọng — code hiện tại đưa ra giả định hợp lý nhưng **chưa được
xác nhận** vì tài liệu API thật của OKELAS Core chưa có trong phiên làm việc
này:

| Giả định hiện tại | Cần xác nhận |
|---|---|
| OKELAS Core có REST endpoint `POST /api/v1/workflows/consultant-intake` nhận `{event_type, workflow_id, source, data}` | Endpoint/path/envelope thật của OKELAS Core (có thể theo kiểu Frappe/DocType nếu OKELAS Core build trên nền Frappe — path và payload sẽ khác) |
| Xác thực bằng Bearer token qua `OKELAS_CORE_API_KEY` | Cơ chế auth thật (API key, OAuth, mTLS...) |
| Notify là gọi một chiều, không cần chờ kết quả xử lý xong ở Core | Nếu Core cần trả về id của WorkflowInstance vừa tạo để website lưu đối chiếu, cần bổ sung xử lý response — hiện tại `HttpOkelasCoreClient.notify_consultant_intake` bỏ qua response body |
| Workflow `consultant_assessment_intake` đã được nạp sẵn vào OKELAS Core dưới `workflow_id` này | Cách thật để đăng ký/nạp workflow definition vào OKELAS Core (qua UI, qua migration script, qua API riêng...) |
| Slug bài viết trong `RELATED_LINKS` (main.py) | Đường dẫn thật trên website khi các bài trong `03_Pillar_Map` được xuất bản |

Cho tới khi các điểm trên được xác nhận, hệ thống **vẫn chạy được đầy đủ và
đúng logic cho người dùng cuối** ở chế độ `NoOpLoggingClient` — chỉ chưa thật
sự ghi Evidence vào OKELAS Core nội bộ (chỉ log lại). Khi có thông tin API
thật, chỉ cần sửa `HttpOkelasCoreClient` trong `okelas_client.py` — không
cần đổi bất kỳ chỗ nào khác (frontend, scoring logic đều giữ nguyên, vì
chúng không phụ thuộc vào OKELAS Core).

## 6. Việc cần làm tiếp (theo đúng roadmap đã thống nhất trước đó)

* Pilot bộ câu hỏi với người dùng thật để hiệu chỉnh ngưỡng level trong từng
  `config/questions_*.json` (mục `levels`) — không đổi vị trí chạy logic này
  (vẫn luôn ở `scoring_engine.py`).
* Viết Interview Script cho consultant (việc còn thiếu đã nêu ở
  `04_Verification_Framework`) — dùng bởi consultant ở bước "Assess"/"Diagnose"
  của Consultant Workflow, sau khi `route_to_consultant_workflow` đã tạo
  WorkflowInstance.
* Xây 4 Decision Tree đầy đủ (ERP, KM, Digitalization theo mẫu AI Readiness) —
  đây là bước **bên trong** Consultant Workflow (giai đoạn Diagnose), nhận
  input là `computed_result` + `raw_answers` đã ghi trong Evidence, **không**
  đụng tới `scoring_workflow.json` hay `consultant_intake_workflow.json`.
