# Manifest hình bài Process standardization before ERP (VI + EN)

Tiền tố cụm: `erps`. Cover PNG 1200×630; hình thường SVG (inline có dark mode; dùng `<img>` thì cần xuất PNG light).


## VI — `/images/insights/chuan-hoa-quy-trinh-truoc-erp/`

```yaml
cover_image: /images/insights/chuan-hoa-quy-trinh-truoc-erp/erps-00-og-cover-vi.png
og_image: /images/insights/chuan-hoa-quy-trinh-truoc-erp/erps-00-og-cover-vi.png
cover_alt: "Bốn đường đi khác nhau cho cùng một việc hội tụ thành một đường nhất quán trước khi vào khối ERP."
```

| # | File | Đặt ở mục |
|---|---|---|
| 1 | `erps-01-six-questions-vi.svg` | ERP cần gì từ quy trình doanh nghiệp? |
| 2 | `erps-02-five-warning-signs-vi.svg` | 5 dấu hiệu quy trình chưa sẵn sàng cho ERP (đầu mục) |
| 3 | `erps-03-three-consequences-vi.svg` | Hậu quả khi đưa quy trình chưa chuẩn vào ERP |
| 4 | `erps-04-consistent-not-perfect-vi.svg` | Chuẩn hóa quy trình trước ERP — không cần hoàn hảo, cần nhất quán |
| 5 | `erps-05-self-check-one-process-vi.svg` | Tự đánh giá: quy trình doanh nghiệp bạn đang ở đâu? |

**Alt:**

1. `six-questions`: Sáu câu hỏi nhà triển khai ERP cần biết về mỗi quy trình: số bước, người thực hiện, người phê duyệt, dữ liệu nhập, ngoại lệ và liên kết với quy trình khác; nếu các phòng ban trả lời khác nhau thì không thể cấu hình chính xác.
2. `five-warning-signs`: Năm dấu hiệu quy trình chưa sẵn sàng cho ERP: nằm trong đầu người, mỗi người một cách làm, họp yêu cầu kết thúc bằng tùy trường hợp, ngoại lệ nhiều hơn quy tắc và không rõ ai chịu trách nhiệm.
3. `three-consequences`: Đưa quy trình chưa chuẩn hóa vào ERP dẫn tới ba hướng: cấu hình theo quy trình sai, customization không kiểm soát và cạn ngân sách trước go-live.
4. `consistent-not-perfect`: Chuẩn hóa trước ERP không cần flowchart được mọi bên phê duyệt, chuẩn hóa toàn tổ chức hay xử lý mọi ngoại lệ; cần ưu tiên phạm vi đầu, quy trình lõi, tài liệu đủ cho người mới và một người chịu trách nhiệm cho mỗi quy trình.
5. `self-check-one-process`: Tự đánh giá một quy trình: chọn một quy trình trong phạm vi ERP rồi trả lời bốn câu hỏi về tài liệu hóa, độ nhất quán giữa nhân viên, người phê duyệt cuối và việc cập nhật tài liệu.

**Markdown mẫu:**
```md
![Sáu câu hỏi nhà triển khai ERP cần biết về mỗi quy trình: số…](/images/insights/chuan-hoa-quy-trinh-truoc-erp/erps-01-six-questions-vi.svg)
![Năm dấu hiệu quy trình chưa sẵn sàng cho ERP: nằm trong đầu …](/images/insights/chuan-hoa-quy-trinh-truoc-erp/erps-02-five-warning-signs-vi.svg)
![Đưa quy trình chưa chuẩn hóa vào ERP dẫn tới ba hướng: cấu h…](/images/insights/chuan-hoa-quy-trinh-truoc-erp/erps-03-three-consequences-vi.svg)
![Chuẩn hóa trước ERP không cần flowchart được mọi bên phê duy…](/images/insights/chuan-hoa-quy-trinh-truoc-erp/erps-04-consistent-not-perfect-vi.svg)
![Tự đánh giá một quy trình: chọn một quy trình trong phạm vi …](/images/insights/chuan-hoa-quy-trinh-truoc-erp/erps-05-self-check-one-process-vi.svg)
```

## EN — `/images/insights/process-standardization-before-erp/`

```yaml
cover_image: /images/insights/process-standardization-before-erp/erps-00-og-cover-en.png
og_image: /images/insights/process-standardization-before-erp/erps-00-og-cover-en.png
cover_alt: "Four different paths for the same task converge into one consistent path before entering the ERP block."
```

| # | File | Đặt ở mục |
|---|---|---|
| 1 | `erps-01-six-questions-en.svg` | What ERP Actually Requires From Your Processes |
| 2 | `erps-02-five-warning-signs-en.svg` | 5 Warning Signs Your Processes Are Not Ready for ERP (start of section) |
| 3 | `erps-03-three-consequences-en.svg` | The Cost of Skipping This Step |
| 4 | `erps-04-consistent-not-perfect-en.svg` | Process Standardization Before ERP — Not Perfect, Just Consistent |
| 5 | `erps-05-self-check-one-process-en.svg` | Self-Assessment: Where Do Your Processes Stand? |

**Alt:**

1. `six-questions`: Six questions an ERP implementation partner needs answered about each process: number of steps, who performs them, who approves, data captured, exceptions and links to adjacent processes; if departments answer differently the system cannot be configured accurately.
2. `five-warning-signs`: Five warning signs processes are not ready for ERP: they live in people’s heads, every team has its own way, workshops end with it depends, exceptions outnumber the rule and accountability is unclear.
3. `three-consequences`: Loading unstandardized processes into ERP leads to three paths: configuration around the wrong process, uncontrolled customization and a budget that runs out before go-live.
4. `consistent-not-perfect`: Standardizing before ERP does not require flowcharts signed off by everyone, organization-wide standardization or resolving every exception; it requires prioritizing the initial scope, the core flow, documentation a new employee can follow and a named owner per process.
5. `self-check-one-process`: Self-assess one process: pick a process within the ERP scope and answer four questions on documentation, consistency between employees, the final approver and whether documentation was updated.

**Markdown mẫu:**
```md
![Six questions an ERP implementation partner needs answered a…](/images/insights/process-standardization-before-erp/erps-01-six-questions-en.svg)
![Five warning signs processes are not ready for ERP: they liv…](/images/insights/process-standardization-before-erp/erps-02-five-warning-signs-en.svg)
![Loading unstandardized processes into ERP leads to three pat…](/images/insights/process-standardization-before-erp/erps-03-three-consequences-en.svg)
![Standardizing before ERP does not require flowcharts signed …](/images/insights/process-standardization-before-erp/erps-04-consistent-not-perfect-en.svg)
![Self-assess one process: pick a process within the ERP scope…](/images/insights/process-standardization-before-erp/erps-05-self-check-one-process-en.svg)
```
