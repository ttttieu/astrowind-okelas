# Manifest hình bài Data readiness trước ERP (VI + EN)

Tiền tố cụm: `erpd`. Cover PNG 1200×630; hình thường SVG (inline có dark mode; dùng `<img>` thì cần xuất PNG light).


## VI — `/images/insights/data-readiness-trien-khai-erp/`

```yaml
cover_image: /images/insights/data-readiness-trien-khai-erp/erpd-00-og-cover-vi.png
og_image: /images/insights/data-readiness-trien-khai-erp/erpd-00-og-cover-vi.png
cover_alt: "Một lưới bản ghi có vài ô lỗi đi vào khối ERP, và các lỗi xuất hiện lại ở báo cáo, cảnh báo tồn kho và đơn mua hàng."
```

| # | File | Đặt ở mục |
|---|---|---|
| 1 | `erpd-01-two-kinds-of-data-vi.svg` | ERP cần loại dữ liệu nào? |
| 2 | `erpd-02-five-data-problems-vi.svg` | Vì sao dữ liệu hiện tại thường không đủ chuẩn |
| 3 | `erpd-03-same-word-two-meanings-vi.svg` | Định nghĩa không nhất quán |
| 4 | `erpd-04-hidden-costs-vi.svg` | Chi phí ẩn của data migration kém chuẩn bị |
| 5 | `erpd-05-readiness-checklist-vi.svg` | Checklist data readiness trước khi bắt đầu ERP |

**Alt:**

1. `two-kinds-of-data`: ERP cần hai loại dữ liệu: master data (sản phẩm, nhà cung cấp, khách hàng, chart of accounts, cơ cấu tổ chức) phải chính xác trước go-live, và transactional data (đơn hàng, hóa đơn, tồn kho, số dư kế toán) mà mức độ chuyển là quyết định kinh doanh.
2. `five-data-problems`: Năm lý do dữ liệu hiện tại hiếm khi sẵn sàng: trùng lặp và không nhất quán, không đầy đủ, nằm ở nhiều nơi, định nghĩa không nhất quán và tồn kho sổ sách không khớp thực tế.
3. `same-word-two-meanings`: Cùng một từ có hai định nghĩa: tồn kho ở kho gồm hàng đang về còn kế toán chỉ tính hàng đã nhập kho; khách hàng ở hệ thống kinh doanh gồm khách tiềm năng còn ERP chỉ cần khách đã có giao dịch.
4. `hidden-costs`: Bốn chi phí ẩn của chuẩn bị dữ liệu kém: kéo dài timeline, quyết định dựa trên dữ liệu sai, sửa sau go-live đắt hơn và mất niềm tin vào hệ thống, là chi phí khó phục hồi nhất.
5. `readiness-checklist`: Năm nhóm cần kiểm tra trước ERP, mỗi nhóm một câu hỏi đại diện: sản phẩm/SKU, nhà cung cấp và khách hàng, tồn kho, kế toán và quản trị dữ liệu.

**Markdown mẫu:**
```md
![ERP cần hai loại dữ liệu: master data (sản phẩm, nhà cung cấ…](/images/insights/data-readiness-trien-khai-erp/erpd-01-two-kinds-of-data-vi.svg)
![Năm lý do dữ liệu hiện tại hiếm khi sẵn sàng: trùng lặp và k…](/images/insights/data-readiness-trien-khai-erp/erpd-02-five-data-problems-vi.svg)
![Cùng một từ có hai định nghĩa: tồn kho ở kho gồm hàng đang v…](/images/insights/data-readiness-trien-khai-erp/erpd-03-same-word-two-meanings-vi.svg)
![Bốn chi phí ẩn của chuẩn bị dữ liệu kém: kéo dài timeline, q…](/images/insights/data-readiness-trien-khai-erp/erpd-04-hidden-costs-vi.svg)
![Năm nhóm cần kiểm tra trước ERP, mỗi nhóm một câu hỏi đại di…](/images/insights/data-readiness-trien-khai-erp/erpd-05-readiness-checklist-vi.svg)
```

## EN — `/images/insights/erp-data-readiness/`

```yaml
cover_image: /images/insights/erp-data-readiness/erpd-00-og-cover-en.png
og_image: /images/insights/erp-data-readiness/erpd-00-og-cover-en.png
cover_alt: "A grid of records with a few faulty cells enters the ERP block, and the faults reappear in reports, inventory alerts and purchase orders."
```

| # | File | Đặt ở mục |
|---|---|---|
| 1 | `erpd-01-two-kinds-of-data-en.svg` | What Data Does ERP Actually Need? |
| 2 | `erpd-02-five-data-problems-en.svg` | Why Existing Data Is Rarely Actually Ready |
| 3 | `erpd-03-same-word-two-meanings-en.svg` | Inconsistent definitions |
| 4 | `erpd-04-hidden-costs-en.svg` | The Real Cost of Inadequate Data Preparation |
| 5 | `erpd-05-readiness-checklist-en.svg` | Data Readiness Checklist — Before Starting ERP |

**Alt:**

1. `two-kinds-of-data`: ERP needs two kinds of data: master data (products, vendors, customers, chart of accounts, organizational structure), which must be accurate before go-live, and transactional data (orders, invoices, inventory, balances), where how much to migrate is a business decision.
2. `five-data-problems`: Five reasons existing data is rarely ready: duplicates and inconsistency, incomplete records, data scattered across sources, inconsistent definitions and book inventory that does not match reality.
3. `same-word-two-meanings`: The same word carries two definitions: inventory in the warehouse includes goods in transit while accounting counts only goods received; a customer in the sales system includes prospects while ERP needs only entities with transaction history.
4. `hidden-costs`: Four hidden costs of inadequate data preparation: timeline delays, decisions on wrong data, costlier fixes after go-live and lost confidence in the system, the hardest to recover.
5. `readiness-checklist`: Five areas to check before ERP, each with one representative question: product catalog and SKUs, vendors and customers, inventory, accounting and data governance.

**Markdown mẫu:**
```md
![ERP needs two kinds of data: master data (products, vendors,…](/images/insights/erp-data-readiness/erpd-01-two-kinds-of-data-en.svg)
![Five reasons existing data is rarely ready: duplicates and i…](/images/insights/erp-data-readiness/erpd-02-five-data-problems-en.svg)
![The same word carries two definitions: inventory in the ware…](/images/insights/erp-data-readiness/erpd-03-same-word-two-meanings-en.svg)
![Four hidden costs of inadequate data preparation: timeline d…](/images/insights/erp-data-readiness/erpd-04-hidden-costs-en.svg)
![Five areas to check before ERP, each with one representative…](/images/insights/erp-data-readiness/erpd-05-readiness-checklist-en.svg)
```
