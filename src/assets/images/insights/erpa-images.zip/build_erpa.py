import sys, re
import cairosvg
sys.path.insert(0, '/home/claude/erpf')
from lib import Fig, LIGHT, DARK, tw
import build_erpf as B
from build_erpf import bind, curly, chip, head, make, var_check, two_cols

OUT = '/home/claude/erpa/out'
CHK = '/home/claude/erpa/check'

B.PAIRS += ['scope creep', 'go-live', 'kick-off', 'giai đoạn', 'nhà triển khai', 'ngân sách', 'dự phòng', 'đánh giá', 'tác động', 'quy trình', 'yêu cầu', 'thay đổi', 'nguyên nhân', 'gốc rễ', 'nợ kỹ thuật', 'người có thẩm quyền', 'chi phí', 'rủi ro', 'bảo trì', 'nâng cấp', 'user adoption', 'change management', 'super user', 'người dùng', 'nhân viên', 'chart of accounts', 'số dư đầu kỳ', 'chi phí', 'kế toán', 'phân bổ', 'tài sản', 'tồn kho', 'bút toán']

CONC_VI = 'Sơ đồ minh họa khái niệm từ bài viết, không phải số liệu đo lường.'
CONC_EN = 'Conceptual diagram from the article, not measured data.'

VI = dict(
    mt=62,
    t={1: 'Mọi giao dịch vận hành đều đổ vào kế toán',
       2: 'Bốn yêu cầu ERP đặt ra với hệ thống kế toán',
       3: 'Bốn vấn đề phổ biến của chart of accounts',
       4: 'Năm nhóm dữ liệu kế toán cần chuẩn bị trước ERP',
       5: 'Phân bổ chi phí trong sản xuất: ba câu hỏi cần trả lời',
       6: 'Checklist accounting readiness: năm nhóm kiểm tra',
       0: 'Accounting readiness:\nnhững gì CFO cần biết trước ERP'},
    s={1: 'Kế toán hay bị xếp “xử lý sau”, nhưng là nền của mọi báo cáo đầu ra.',
       2: 'ERP cần được cấu hình theo các quyết định mà doanh nghiệp đã chốt.',
       3: 'Chart of accounts là quyết định có hậu quả lâu dài.',
       4: 'Mỗi nhóm có những vấn đề đặc trưng cần xử lý trước cutover.',
       5: 'Giá thành gồm ba thành phần; overhead phụ thuộc phương pháp đã chọn.',
       6: 'Mỗi nhóm kèm một câu hỏi đại diện cho checklist đầy đủ trong bài.'},
    f={1: 'Sơ đồ minh họa khái niệm từ bài viết, không phải số liệu đo lường.',
       2: 'Phân tích từ bài viết, không phải thống kê.',
       3: 'Phân tích từ bài viết, không phải thống kê.',
       4: 'Phân tích từ bài viết, không phải thống kê.',
       5: 'Sơ đồ minh họa khái niệm từ bài viết, không phải số liệu đo lường.',
       6: 'Câu hỏi tự đánh giá từ bài viết, là công cụ thảo luận định hướng, không phải phương pháp luận được chứng nhận.'},
    lt='Giao dịch vận hành', ct='Bút toán kế toán', rt='Báo cáo',
    ops=['Đơn mua', 'Nhập kho', 'Hóa đơn bán'],
    cb='Kế toán', cd='Mỗi giao dịch sinh bút toán',
    rb='Báo cáo đầu ra', rd='Dùng để ra quyết định sau go-live',
    e1='Dữ liệu kế toán sai thì mọi báo cáo đầu ra đều không đáng tin.',
    c2=[('Chart of accounts', 'Đủ chi tiết cho vận hành, không quá phức tạp; cùng loại giao dịch vào cùng tài khoản.'),
        ('Phương pháp phân bổ chi phí', 'Nhất quán, có tài liệu; ERP không tự quyết định thay doanh nghiệp.'),
        ('Kỳ kế toán', 'Tháng kế toán, năm tài chính và các kỳ đặc biệt như điều chỉnh cuối năm.'),
        ('Số dư đầu kỳ sạch', 'Chính xác, đã đối chiếu và được người có thẩm quyền kiểm tra trước khi nhập.')],
    e2='ERP cần các quyết định này được chốt trước khi cấu hình.',
    c3=[('Quá ít tài khoản', 'Đủ cho báo cáo thuế nhưng thiếu chi tiết để phân tích theo sản phẩm, bộ phận, kênh.'),
        ('Quá nhiều, thiếu cấu trúc', 'Thêm qua nhiều năm, không bao giờ xóa, khó bảo trì.'),
        ('Áp dụng không nhất quán', 'Chi phí vận chuyển hàng về ghi vào các tài khoản khác nhau; ERP khuếch đại sai lệch.'),
        ('Không đáp ứng yêu cầu báo cáo mới', 'Sửa chart of accounts sau khi dữ liệu đã vào hệ thống khó hơn nhiều.')],
    e3='Xác định câu hỏi kinh doanh cần báo cáo trả lời, rồi mới thiết kế chart of accounts.',
    c4=[('Số dư đầu kỳ', 'Điểm xuất phát của hệ thống; sai lệch đi theo suốt vòng đời.'),
        ('Công nợ phải thu', 'Khách hàng trùng, thanh toán một phần ghi sai, nợ cũ không thu được.'),
        ('Công nợ phải trả', 'Hóa đơn chưa khớp phiếu nhập kho, điều khoản sai, số dư âm do lỗi cũ.'),
        ('Tài sản cố định', 'Tài sản đã thanh lý vẫn trên sổ; tài sản đang dùng chưa ghi nhận.'),
        ('Tồn kho kế toán', 'Đối chiếu kiểm kê và điều chỉnh trước cutover, không để ERP tự điều chỉnh.')],
    e4='Mỗi nhóm cần người chịu trách nhiệm xác nhận trước ngày cutover.',
    parts=['Nguyên vật liệu', 'Nhân công trực tiếp', 'Chi phí sản xuất chung (overhead)'],
    ovp='Phụ thuộc phương pháp đã chọn',
    qh='Ba câu hỏi nhiều CFO SME sản xuất chưa trả lời rõ',
    qs=[('Đang dùng phương pháp tính giá thành nào?', 'Standard costing, actual costing hay phương pháp khác.'),
        ('Overhead phân bổ theo tiêu chí nào?', 'Giờ máy, giờ công hay tỷ lệ khác.'),
        ('Tỷ lệ phân bổ có được tính và cập nhật định kỳ không?', '')],
    e5='Câu trả lời thiếu hoặc khác nhau tùy người: giải quyết trước khi cấu hình module.',
    c6=[('Chart of accounts', 'Giao dịch cùng loại có luôn vào cùng một tài khoản không?'),
        ('Số dư đầu kỳ', 'Đã đối chiếu và được người có thẩm quyền xác nhận chưa?'),
        ('Tồn kho và tài sản', 'Tồn kho sổ sách đã đối chiếu kiểm kê thực tế gần đây chưa?'),
        ('Chi phí sản xuất', 'Phương pháp tính giá thành đã được xác định và tài liệu hóa chưa?'),
        ('Kỳ kế toán', 'Năm tài chính và cấu trúc kỳ đã được xác định chưa?')],
    e6='Nhiều ô chưa đánh dấu: cần thêm thời gian, nguồn lực và CFO tham gia sớm hơn.',
    kick='OKELAS · Insights · ERP',
    pl=['Chart of accounts', 'Phân bổ chi phí', 'Số dư đầu kỳ'],
    cp='Ba điểm cần chuẩn hóa trước khi bắt đầu dự án',
)

EN = dict(
    mt=62,
    t={1: 'Every operational transaction flows into accounting',
       2: 'Four things ERP requires from your accounting system',
       3: 'Four common problems with the chart of accounts',
       4: 'Five accounting records to prepare before ERP',
       5: 'Cost allocation in manufacturing: three questions to answer',
       6: 'Accounting readiness checklist: five areas to check',
       0: 'Accounting Readiness for ERP:\nA CFO’s Preparation Checklist'},
    s={1: 'Finance is often configured last, yet every report depends on it.',
       2: 'ERP must be configured around decisions the business has already made.',
       3: 'The chart of accounts is a long-term decision.',
       4: 'Each group has its own typical problems to resolve before cutover.',
       5: 'Product cost has three components; overhead depends on the chosen method.',
       6: 'Each area carries one representative question from the full checklist in the article.'},
    f={1: 'Conceptual diagram from the article, not measured data.',
       2: 'Analysis from the article, not statistics.',
       3: 'Analysis from the article, not statistics.',
       4: 'Analysis from the article, not statistics.',
       5: 'Conceptual diagram from the article, not measured data.',
       6: 'Self-assessment questions from the article, a discussion aid, not a certified methodology.'},
    lt='Operational transactions', ct='Accounting entries', rt='Reports',
    ops=['Purchase order', 'Goods receipt', 'Sales invoice'],
    cb='Accounting', cd='Every transaction creates entries',
    rb='Financial output', rd='Used for decisions after go-live',
    e1='If accounting data is wrong, every report built on it is unreliable.',
    c2=[('Chart of accounts', 'Detailed enough for operations yet maintainable; the same transaction type in the same account.'),
        ('Cost allocation method', 'Documented and consistent; ERP cannot decide this itself.'),
        ('Accounting periods', 'Month boundaries, fiscal year and special periods such as year-end adjustments.'),
        ('Clean opening balances', 'Accurate, reconciled and approved by an authorized person before entry.')],
    e2='ERP needs these decisions settled before it is configured.',
    c3=[('Too few accounts', 'Fine for tax filing, but cannot support product, department or channel analysis.'),
        ('Too many, no structure', 'Added over years, never retired, hard to maintain.'),
        ('Inconsistent application', 'Inbound freight booked to different accounts; ERP amplifies the discrepancy.'),
        ('Not aligned with new reporting', 'Redesigning the chart after data is loaded is much harder.')],
    e3='Define the business questions reporting must answer, then design the chart of accounts.',
    c4=[('Opening balances', 'The system’s starting point; errors follow it for life.'),
        ('Accounts receivable', 'Duplicate customers, partial payments recorded wrongly, old uncollectible balances.'),
        ('Accounts payable', 'Invoices not matched to receipts, wrong terms, negative vendor balances from old errors.'),
        ('Fixed assets', 'Disposed assets still listed; active assets never recorded.'),
        ('Inventory', 'Reconcile to a physical count and adjust before cutover, not inside ERP.')],
    e4='Each group needs a named person to confirm it before cutover.',
    parts=['Direct materials', 'Direct labor', 'Manufacturing overhead'],
    ovp='Depends on the chosen method',
    qh='Three questions many SME manufacturing CFOs have not answered clearly',
    qs=[('Which costing method is used?', 'Standard, actual or another method.'),
        ('What is the overhead allocation basis?', 'Machine hours, labor hours or another rate.'),
        ('Is the allocation rate calculated and updated regularly?', '')],
    e5='Missing or conflicting answers: resolve them before configuring modules.',
    c6=[('Chart of accounts', 'Is each transaction type always recorded in the same account?'),
        ('Opening balances', 'Are they reconciled and confirmed by an authorized person?'),
        ('Inventory and assets', 'Is book inventory reconciled to a recent physical count?'),
        ('Manufacturing costing', 'Is the costing methodology defined and documented?'),
        ('Accounting periods', 'Are the fiscal year and period structure defined?')],
    e6='Several unchecked items: allow more time, resources and earlier CFO involvement.',
    kick='OKELAS · Insights · ERP',
    pl=['Chart of accounts', 'Cost allocation', 'Opening balances'],
    cp='Three areas to standardize before the project starts',
)

ALT = {
    'vi': {
        1: 'Các giao dịch vận hành như đơn mua, nhập kho và hóa đơn bán đều đi vào kế toán dưới dạng bút toán, rồi thành báo cáo đầu ra dùng để ra quyết định; dữ liệu kế toán sai thì mọi báo cáo không đáng tin.',
        2: 'Bốn yêu cầu ERP đặt ra với hệ thống kế toán: chart of accounts nhất quán, phương pháp phân bổ chi phí, kỳ kế toán và số dư đầu kỳ sạch đã đối chiếu.',
        3: 'Bốn vấn đề phổ biến của chart of accounts: quá ít tài khoản, quá nhiều và thiếu cấu trúc, áp dụng không nhất quán và không đáp ứng yêu cầu báo cáo mới.',
        4: 'Năm nhóm dữ liệu kế toán cần chuẩn bị trước ERP: số dư đầu kỳ, công nợ phải thu, công nợ phải trả, tài sản cố định và tồn kho kế toán.',
        5: 'Giá thành gồm nguyên vật liệu, nhân công trực tiếp và chi phí sản xuất chung, trong đó overhead phụ thuộc phương pháp đã chọn; ba câu hỏi cần trả lời về phương pháp tính giá thành, tiêu chí phân bổ và việc cập nhật tỷ lệ.',
        6: 'Năm nhóm cần kiểm tra trong checklist accounting readiness, mỗi nhóm một câu hỏi đại diện: chart of accounts, số dư đầu kỳ, tồn kho và tài sản, chi phí sản xuất và kỳ kế toán.',
        0: 'Khối ERP nằm trên ba trụ cột là chart of accounts, phân bổ chi phí và số dư đầu kỳ, thể hiện ba điểm cần chuẩn hóa trước khi bắt đầu dự án.'},
    'en': {
        1: 'Operational transactions such as purchase orders, goods receipts and sales invoices all flow into accounting as entries and then into the financial output used for decisions; if accounting data is wrong, every report is unreliable.',
        2: 'Four things ERP requires from the accounting system: a consistent chart of accounts, a cost allocation method, defined accounting periods and clean reconciled opening balances.',
        3: 'Four common problems with the chart of accounts: too few accounts, too many with no structure, inconsistent application and misalignment with new reporting needs.',
        4: 'Five accounting records to prepare before ERP: opening balances, accounts receivable, accounts payable, fixed assets and inventory.',
        5: 'Product cost combines direct materials, direct labor and manufacturing overhead, where overhead depends on the chosen method; three questions cover the costing method, the allocation basis and regular updating of the rate.',
        6: 'Five areas in the accounting readiness checklist, each with one representative question: chart of accounts, opening balances, inventory and assets, manufacturing costing and accounting periods.',
        0: 'An ERP block resting on three pillars, chart of accounts, cost allocation and opening balances, showing the three areas to standardize before the project starts.'},
}

VI = bind(VI)
EN = curly(EN)
LANGS = {'vi': VI, 'en': EN}
NAMES = {1: 'operations-flow-into-accounting', 2: 'four-requirements', 3: 'coa-four-problems',
         4: 'five-record-groups', 5: 'cost-allocation-questions', 6: 'readiness-checklist'}


def numc(f, x, y, n, col='p', r=15):
    f.circle(x, y, r, col)
    f._line(x, y - 10, str(n), 15, 700, 'wh', 'middle', 20)


def cards(f, L, k, key, fill, stroke, n, numbered=False, big=False):
    head(f, L, k)
    items = L[key]
    gap, y = 15, 134
    cw = round((1080 - gap * (n - 1)) / n)
    ts, ds = (18, 14) if big else (16, 13)
    top = 62 if numbered else 20
    need = 0
    for t, d in items:
        need = max(need, top + f.measure(t, ts, 700, cw - 32) + 10 + f.measure(d, ds, 400, cw - 32, 1.42) + 20)
    ch = round(need)
    for i, (t, d) in enumerate(items):
        x = 60 + i * (cw + gap)
        f.rect(x, y, cw, ch, fill, stroke, 16, 1.8)
        if numbered:
            numc(f, x + 32, y + 32, i + 1, stroke)
        th = f.para(x + 16, y + top, t, ts, 700, 'hd', cw - 32)
        f.para(x + 16, y + top + th + 10, d, ds, 400, 'tx', cw - 32, lhr=1.42)
    f.ink(y + ch + 16, L['e%d' % k])


def fig1(f, L):
    head(f, L, 1)
    y0 = 134
    f._line(60, y0, L['lt'], 14, 700, 'mut', 'start', 20)
    f._line(480, y0, L['ct'], 14, 700, 'mut', 'start', 20)
    f._line(850, y0, L['rt'], 14, 700, 'mut', 'start', 20)
    oy, oh, og = y0 + 30, 52, 14
    mid = oy + (3 * oh + 2 * og) / 2
    for i, t in enumerate(L['ops']):
        y = oy + i * (oh + og)
        f.rect(60, y, 280, oh, 'pt', 'p', 12, 1.8)
        f.box_text(60, y, 280, oh, t, 17, 700, 'hd', 10)
        f.arrow(346, y + oh / 2, 474, mid, 'gm', 2.5, 9)
    ch = 3 * oh + 2 * og
    f.rect(480, oy, 280, ch, 'at', 'a', 16, 2.4)
    f.box_text(480, oy + 20, 280, 40, L['cb'], 24, 700, 'hd', 10)
    f.box_text(480, oy + 70, 280, 50, L['cd'], 15, 400, 'tx', 20)
    f.arrow(766, mid, 844, mid, 'gm', 2.5, 10)
    f.rect(850, oy, 290, ch, 'ink', None, 16)
    f.box_text(850, oy + 22, 290, 40, L['rb'], 20, 700, 'onink', 10)
    f.box_text(850, oy + 70, 290, 50, L['rd'], 14, 400, 'onink', 20)
    f.ink(oy + ch + 20, L['e1'])


def fig2(f, L): cards(f, L, 2, 'c2', 'pt', 'p', 4, numbered=True, big=True)
def fig3(f, L): cards(f, L, 3, 'c3', 'at', 'a', 4, big=True)
def fig4(f, L): cards(f, L, 4, 'c4', 'pt', 'p', 5, numbered=True)


def fig5(f, L):
    head(f, L, 5)
    y, bh = 134, 64
    cw, gap = 340, 30
    for i, t in enumerate(L['parts']):
        x = 60 + i * (cw + gap)
        hl = i == 2
        f.rect(x, y + (24 if hl else 0), cw, bh, 'at' if hl else 'pt', 'a' if hl else 'p', 14, 3 if hl else 1.8)
        f.box_text(x, y + (24 if hl else 0), cw, bh, t, 17, 700, 'hd', 10)
        if hl:
            f.pill(x + 14, y, L['ovp'], 'a', 'bg', 12, 'start', 24, 10)
        if i < 2:
            f._line(x + cw + gap / 2, y + 12 + bh / 2 - 14 + 6, '+', 28, 700, 'mut', 'middle', 34)
    qy = y + 24 + bh + 24
    f.para(60, qy, L['qh'], 16, 700, 's', 1080)
    cy = qy + 34
    n, g = 3, 15
    cw2 = round((1080 - g * 2) / 3)
    need = 0
    for t, d in L['qs']:
        need = max(need, 62 + f.measure(t, 16, 700, cw2 - 32) + (10 + f.measure(d, 14, 400, cw2 - 32, 1.42) if d else 0) + 20)
    ch = round(need)
    for i, (t, d) in enumerate(L['qs']):
        x = 60 + i * (cw2 + g)
        f.rect(x, cy, cw2, ch, 'gt', 'gm', 16, 1.8, '6 5')
        numc(f, x + 32, cy + 32, i + 1, 'mut')
        th = f.para(x + 16, cy + 62, t, 16, 700, 'hd', cw2 - 32)
        if d:
            f.para(x + 16, cy + 62 + th + 10, d, 14, 400, 'tx', cw2 - 32, lhr=1.42)
    f.ink(cy + ch + 16, L['e5'])


def fig6(f, L): cards(f, L, 6, 'c6', 'pt', 'p', 5)


def figcover(f, L):
    f.rect(0, 0, 1200, 630, 'bg', None, 0)
    f.rect(0, 0, 14, 630, 'p', None, 0)
    f._line(60, 44, L['kick'], 16, 700, 's', 'start', 22)
    f.para(60, 84, L['t'][0], 40, 700, 'hd', 1040, lhr=1.25)
    bx, bw = 300, 600
    f.rect(bx, 300, bw, 90, 'ink', None, 18)
    f._line(bx + bw / 2, 322, 'ERP', 40, 700, 'onink', 'middle', 50)
    pw, pg = 180, 30
    for i, t in enumerate(L['pl']):
        x = bx + i * (pw + pg)
        f.rect(x + 0, 404, pw, 84, 'pt', 'p', 14, 2.2)
        f.box_text(x, 404, pw, 84, t, 16, 700, 'hd', 10)
    f.para(bx, 512, L['cp'], 15, 700, 's', 600)
    f.mark(H_COVER - 30)


H_COVER = 630
FIGS = {1: fig1, 2: fig2, 3: fig3, 4: fig4, 5: fig5, 6: fig6}


def build(sel=None):
    for lang, L in LANGS.items():
        for k in list(FIGS) + [0]:
            if sel and k not in sel:
                continue
            label = ALT[lang][k]
            fn = figcover if k == 0 else FIGS[k]
            name = f'erpa-00-og-cover-{lang}' if k == 0 else f'erpa-{k:02d}-{NAMES[k]}-{lang}'
            if k == 0:
                s = Fig(H_COVER, 'svg', False, label); fn(s, L)
                p = Fig(H_COVER, 'png', False, label); fn(p, L)
                d = Fig(H_COVER, 'png', True, label); fn(d, L)
                H = H_COVER
            else:
                s = make(fn, L, label, 'svg')
                H = s.H
                p = make(fn, L, label, 'png', False, H)
                d = make(fn, L, label, 'png', True, H)
            svg = s.svg()
            assert var_check(svg, p.svg()), 'adaptive vs light mismatch ' + name
            open(f'{OUT}/{lang}/{name}.svg', 'w', encoding='utf-8').write(svg)
            if k == 0:
                cairosvg.svg2png(bytestring=p.svg().encode('utf-8'), write_to=f'{OUT}/{lang}/{name}.png', output_width=1200)
            cairosvg.svg2png(bytestring=p.svg().encode('utf-8'), write_to=f'{CHK}/{name}-light.png', output_width=1200)
            cairosvg.svg2png(bytestring=d.svg().encode('utf-8'), write_to=f'{CHK}/{name}-dark.png', output_width=1200)
            print('ok', name, 'H', H)


if __name__ == '__main__':
    build([int(a) for a in sys.argv[1:]] or None)
