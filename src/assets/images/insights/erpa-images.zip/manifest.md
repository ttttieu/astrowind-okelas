# Manifest hình bài Accounting readiness cho ERP (VI + EN)

Tiền tố cụm: `erpa`. Cover PNG 1200×630; hình thường SVG (inline có dark mode; dùng `<img>` thì cần xuất PNG light).

## VI — `/images/insights/ke-toan-san-sang-erp/`

```yaml
cover_image: /images/insights/ke-toan-san-sang-erp/erpa-00-og-cover-vi.png
og_image: /images/insights/ke-toan-san-sang-erp/erpa-00-og-cover-vi.png
cover_alt: "Khối ERP nằm trên ba trụ cột là chart of accounts, phân bổ chi phí và số dư đầu kỳ, thể hiện ba điểm cần chuẩn hóa trước khi bắt đầu dự án."
```

| # | File | Đặt ở mục |
|---|---|---|
| 1 | `erpa-01-operations-flow-into-accounting-vi.svg` | Tại sao tài chính - kế toán thường là điểm gây chậm nhất trong ERP? |
| 2 | `erpa-02-four-requirements-vi.svg` | ERP cần gì từ hệ thống kế toán? |
| 3 | `erpa-03-coa-four-problems-vi.svg` | Chart of accounts — tại sao nó quan trọng hơn bạn nghĩ |
| 4 | `erpa-04-five-record-groups-vi.svg` | Dữ liệu kế toán nào cần chuẩn bị trước ERP? |
| 5 | `erpa-05-cost-allocation-questions-vi.svg` | Vấn đề phân bổ chi phí trong sản xuất |
| 6 | `erpa-06-readiness-checklist-vi.svg` | Checklist accounting readiness cho CFO |

**Alt:**

1. `operations-flow-into-accounting`: Các giao dịch vận hành như đơn mua, nhập kho và hóa đơn bán đều đi vào kế toán dưới dạng bút toán, rồi thành báo cáo đầu ra dùng để ra quyết định; dữ liệu kế toán sai thì mọi báo cáo không đáng tin.
2. `four-requirements`: Bốn yêu cầu ERP đặt ra với hệ thống kế toán: chart of accounts nhất quán, phương pháp phân bổ chi phí, kỳ kế toán và số dư đầu kỳ sạch đã đối chiếu.
3. `coa-four-problems`: Bốn vấn đề phổ biến của chart of accounts: quá ít tài khoản, quá nhiều và thiếu cấu trúc, áp dụng không nhất quán và không đáp ứng yêu cầu báo cáo mới.
4. `five-record-groups`: Năm nhóm dữ liệu kế toán cần chuẩn bị trước ERP: số dư đầu kỳ, công nợ phải thu, công nợ phải trả, tài sản cố định và tồn kho kế toán.
5. `cost-allocation-questions`: Giá thành gồm nguyên vật liệu, nhân công trực tiếp và chi phí sản xuất chung, trong đó overhead phụ thuộc phương pháp đã chọn; ba câu hỏi cần trả lời về phương pháp tính giá thành, tiêu chí phân bổ và việc cập nhật tỷ lệ.
6. `readiness-checklist`: Năm nhóm cần kiểm tra trong checklist accounting readiness, mỗi nhóm một câu hỏi đại diện: chart of accounts, số dư đầu kỳ, tồn kho và tài sản, chi phí sản xuất và kỳ kế toán.

**Markdown mẫu:**
```md
![Các giao dịch vận hành như đơn mua, nhập kho và hóa đơn bán …](/images/insights/ke-toan-san-sang-erp/erpa-01-operations-flow-into-accounting-vi.svg)
![Bốn yêu cầu ERP đặt ra với hệ thống kế toán: chart of accoun…](/images/insights/ke-toan-san-sang-erp/erpa-02-four-requirements-vi.svg)
![Bốn vấn đề phổ biến của chart of accounts: quá ít tài khoản,…](/images/insights/ke-toan-san-sang-erp/erpa-03-coa-four-problems-vi.svg)
![Năm nhóm dữ liệu kế toán cần chuẩn bị trước ERP: số dư đầu k…](/images/insights/ke-toan-san-sang-erp/erpa-04-five-record-groups-vi.svg)
![Giá thành gồm nguyên vật liệu, nhân công trực tiếp và chi ph…](/images/insights/ke-toan-san-sang-erp/erpa-05-cost-allocation-questions-vi.svg)
![Năm nhóm cần kiểm tra trong checklist accounting readiness, …](/images/insights/ke-toan-san-sang-erp/erpa-06-readiness-checklist-vi.svg)
```

## EN — `/images/insights/accounting-readiness-erp/`

```yaml
cover_image: /images/insights/accounting-readiness-erp/erpa-00-og-cover-en.png
og_image: /images/insights/accounting-readiness-erp/erpa-00-og-cover-en.png
cover_alt: "An ERP block resting on three pillars, chart of accounts, cost allocation and opening balances, showing the three areas to standardize before the project starts."
```

| # | File | Đặt ở mục |
|---|---|---|
| 1 | `erpa-01-operations-flow-into-accounting-en.svg` | Why Finance and Accounting Is Consistently the Most Delayed ERP Component |
| 2 | `erpa-02-four-requirements-en.svg` | What ERP Requires From Your Accounting System |
| 3 | `erpa-03-coa-four-problems-en.svg` | Chart of Accounts: Why Getting This Right Matters |
| 4 | `erpa-04-five-record-groups-en.svg` | Which Accounting Records Need Preparation Before Migration? |
| 5 | `erpa-05-cost-allocation-questions-en.svg` | Cost Allocation in Manufacturing — A Specific Complexity |
| 6 | `erpa-06-readiness-checklist-en.svg` | Pre-ERP Accounting Readiness Checklist |

**Alt:**

1. `operations-flow-into-accounting`: Operational transactions such as purchase orders, goods receipts and sales invoices all flow into accounting as entries and then into the financial output used for decisions; if accounting data is wrong, every report is unreliable.
2. `four-requirements`: Four things ERP requires from the accounting system: a consistent chart of accounts, a cost allocation method, defined accounting periods and clean reconciled opening balances.
3. `coa-four-problems`: Four common problems with the chart of accounts: too few accounts, too many with no structure, inconsistent application and misalignment with new reporting needs.
4. `five-record-groups`: Five accounting records to prepare before ERP: opening balances, accounts receivable, accounts payable, fixed assets and inventory.
5. `cost-allocation-questions`: Product cost combines direct materials, direct labor and manufacturing overhead, where overhead depends on the chosen method; three questions cover the costing method, the allocation basis and regular updating of the rate.
6. `readiness-checklist`: Five areas in the accounting readiness checklist, each with one representative question: chart of accounts, opening balances, inventory and assets, manufacturing costing and accounting periods.

**Markdown mẫu:**
```md
![Operational transactions such as purchase orders, goods rece…](/images/insights/accounting-readiness-erp/erpa-01-operations-flow-into-accounting-en.svg)
![Four things ERP requires from the accounting system: a consi…](/images/insights/accounting-readiness-erp/erpa-02-four-requirements-en.svg)
![Four common problems with the chart of accounts: too few acc…](/images/insights/accounting-readiness-erp/erpa-03-coa-four-problems-en.svg)
![Five accounting records to prepare before ERP: opening balan…](/images/insights/accounting-readiness-erp/erpa-04-five-record-groups-en.svg)
![Product cost combines direct materials, direct labor and man…](/images/insights/accounting-readiness-erp/erpa-05-cost-allocation-questions-en.svg)
![Five areas in the accounting readiness checklist, each with …](/images/insights/accounting-readiness-erp/erpa-06-readiness-checklist-en.svg)
```
