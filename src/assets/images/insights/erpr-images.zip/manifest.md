# Manifest hình bài ERP readiness (VI + EN)

Tiền tố cụm: `erpr`. Cover PNG 1200×630; hình thường SVG (inline có dark mode; dùng `<img>` thì cần xuất PNG light).


## VI — `/images/insights/doanh-nghiep-san-sang-trien-khai-erp/`

```yaml
cover_image: /images/insights/doanh-nghiep-san-sang-trien-khai-erp/erpr-00-og-cover-vi.png
og_image: /images/insights/doanh-nghiep-san-sang-trien-khai-erp/erpr-00-og-cover-vi.png
cover_alt: "Tám chấm, một nửa đặc và một nửa viền đứt, phải đi qua một cổng sẵn sàng trước khi tới khối ERP."
```

| # | File | Đặt ở mục |
|---|---|---|
| 1 | `erpr-01-four-foundations-vi.svg` | ERP không phải bước đầu tiên |
| 2 | `erpr-02-eight-questions-vi.svg` | 8 câu hỏi để tự đánh giá mức độ sẵn sàng (đầu mục) |
| 3 | `erpr-03-three-employee-test-vi.svg` | Ngay sau câu hỏi 1 (quy trình đã được ghi lại và nhất quán chưa?) |
| 4 | `erpr-04-preparation-priorities-vi.svg` | Bước tiếp theo nếu câu trả lời là “chưa sẵn sàng” |

**Alt:**

1. `four-foundations`: ERP, vận hành dựa trên quy trình, đứng trên bốn nền tảng của tổ chức: quy trình đủ rõ, dữ liệu đủ sạch, con người sẵn sàng thay đổi và quản trị có người chịu trách nhiệm; thiếu nền tảng thì ERP khuếch đại sự hỗn loạn.
2. `eight-questions`: Tám câu hỏi tự đánh giá mức độ sẵn sàng cho ERP, nhóm theo bốn chiều: quy trình, dữ liệu, con người, phạm vi và quản trị.
3. `three-employee-test`: Hỏi ba nhân viên cùng một nghiệp vụ: nếu trả lời giống nhau thì quy trình nhất quán và ERP có cơ sở để cấu hình; nếu mỗi người một cách thì ERP khó cấu hình. Tình huống minh họa giả định.
4. `preparation-priorities`: Năm việc cần chuẩn bị khi chưa sẵn sàng: chuẩn hóa quy trình, làm sạch dữ liệu master, chọn phạm vi đầu nhỏ, chỉ định người chịu trách nhiệm và truyền thông với nhân viên.

**Markdown mẫu:**
```md
![ERP, vận hành dựa trên quy trình, đứng trên bốn nền tảng của…](/images/insights/doanh-nghiep-san-sang-trien-khai-erp/erpr-01-four-foundations-vi.svg)
![Tám câu hỏi tự đánh giá mức độ sẵn sàng cho ERP, nhóm theo b…](/images/insights/doanh-nghiep-san-sang-trien-khai-erp/erpr-02-eight-questions-vi.svg)
![Hỏi ba nhân viên cùng một nghiệp vụ: nếu trả lời giống nhau …](/images/insights/doanh-nghiep-san-sang-trien-khai-erp/erpr-03-three-employee-test-vi.svg)
![Năm việc cần chuẩn bị khi chưa sẵn sàng: chuẩn hóa quy trình…](/images/insights/doanh-nghiep-san-sang-trien-khai-erp/erpr-04-preparation-priorities-vi.svg)
```

## EN — `/images/insights/is-your-business-ready-for-erp/`

```yaml
cover_image: /images/insights/is-your-business-ready-for-erp/erpr-00-og-cover-en.png
og_image: /images/insights/is-your-business-ready-for-erp/erpr-00-og-cover-en.png
cover_alt: "Eight dots, half solid and half dashed, must pass through a readiness gate before reaching the ERP block."
```

| # | File | Đặt ở mục |
|---|---|---|
| 1 | `erpr-01-four-foundations-en.svg` | Why ERP Readiness Matters More Than ERP Selection |
| 2 | `erpr-02-eight-questions-en.svg` | 8 Questions to Assess Your Readiness (start of section) |
| 3 | `erpr-03-three-employee-test-en.svg` | Right after question 1 (processes documented and consistent?) |
| 4 | `erpr-04-preparation-priorities-en.svg` | If Your Honest Answer Is “Not Yet” |

**Alt:**

1. `four-foundations`: ERP, which is process-driven, stands on four organizational foundations: clear processes, clean data, people willing to change and governance with clear responsibility; without them ERP amplifies disorder.
2. `eight-questions`: Eight self-assessment questions on ERP readiness, grouped into four dimensions: processes, data, people, and scope and governance.
3. `three-employee-test`: Ask three employees to describe the same task: if answers match, the process is consistent and ERP has something to configure; if everyone does it their own way, ERP is hard to configure. Hypothetical illustration.
4. `preparation-priorities`: Five things to prepare when not yet ready: standardize processes, clean master data, choose a small first scope, assign clear ownership and communicate with employees.

**Markdown mẫu:**
```md
![ERP, which is process-driven, stands on four organizational …](/images/insights/is-your-business-ready-for-erp/erpr-01-four-foundations-en.svg)
![Eight self-assessment questions on ERP readiness, grouped in…](/images/insights/is-your-business-ready-for-erp/erpr-02-eight-questions-en.svg)
![Ask three employees to describe the same task: if answers ma…](/images/insights/is-your-business-ready-for-erp/erpr-03-three-employee-test-en.svg)
![Five things to prepare when not yet ready: standardize proce…](/images/insights/is-your-business-ready-for-erp/erpr-04-preparation-priorities-en.svg)
```
