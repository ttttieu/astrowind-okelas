# Manifest hình bài ERP failure (VI + EN)

Tiền tố cụm: `erpf`. Cover PNG 1200×630; hình thường SVG (inline có dark mode; dùng `<img>` thì cần xuất PNG light).


## VI — `/images/insights/tai-sao-du-an-erp-that-bai/`

```yaml
cover_image: /images/insights/tai-sao-du-an-erp-that-bai/erpf-00-og-cover-vi.png
og_image: /images/insights/tai-sao-du-an-erp-that-bai/erpf-00-og-cover-vi.png
cover_alt: "Hai chuỗi đầu vào đi qua cùng một khối ERP: chuỗi có trật tự cho ra kết quả có trật tự được nhân lên, chuỗi lộn xộn cho ra sự lộn xộn được nhân lên."
```

| # | File | Đặt ở mục (H2) |
|---|---|---|
| 1 | `erpf-01-what-failure-looks-like-vi.svg` | ERP “thất bại” nghĩa là gì? |
| 2 | `erpf-02-erp-is-an-amplifier-vi.svg` | Vấn đề không nằm ở phần mềm |
| 3 | `erpf-03-eight-root-causes-vi.svg` | 8 nguyên nhân phổ biến nhất khiến dự án ERP không đạt mục tiêu (cuối mục, sau nguyên nhân #8) |
| 4 | `erpf-04-early-warning-signs-vi.svg` | Dấu hiệu nhận biết sớm — trước khi dự án gặp vấn đề |
| 5 | `erpf-05-manufacturing-challenges-vi.svg` | Doanh nghiệp sản xuất có thêm những thách thức riêng |
| 6 | `erpf-06-readiness-before-selection-vi.svg` | Câu hỏi đúng không phải “chọn ERP nào?” |

**Alt:**

1. `what-failure-looks-like`: Dự án ERP “xong” có phần nhìn thấy (cài phần mềm, nhân viên đăng nhập, dữ liệu được nhập) và phần bị che khuất (việc thật vẫn chạy bằng Excel và email, dữ liệu không được tin, customization tăng, vận hành chưa đổi); nếu chưa đổi cách vận hành thì vẫn là thất bại về kinh doanh.
2. `erp-is-an-amplifier`: Doanh nghiệp có nền tảng đi qua ERP thì điểm mạnh được nhân lên; doanh nghiệp chưa sẵn sàng đi qua cùng một ERP thì điểm yếu cũng được nhân lên trên một hệ thống phức tạp và tốn kém hơn.
3. `eight-root-causes`: Tám nguyên nhân phổ biến khiến dự án ERP không đạt mục tiêu: quy trình chưa chuẩn hóa, dữ liệu kém, scope không kiểm soát, customization quá nhiều, con người không đổi cách làm việc, thiếu governance sau go-live, kế toán chưa sẵn sàng và không định nghĩa thành công.
4. `early-warning-signs`: Dấu hiệu sớm của dự án ERP gặp vấn đề, chia theo ba giai đoạn: chuẩn bị, triển khai và sau go-live, mỗi giai đoạn bốn dấu hiệu.
5. `manufacturing-challenges`: Năm thách thức riêng của doanh nghiệp sản xuất khi triển khai ERP: BOM, chất lượng và traceability, tích hợp thiết bị, đơn vị tính và hao hụt, mùa vụ.
6. `readiness-before-selection`: Sáu câu hỏi về quy trình, dữ liệu, phạm vi, người ra quyết định, change management và trách nhiệm sau dự án phải được trả lời trước khi đến câu hỏi chọn ERP nào và nhà triển khai nào.

**Markdown mẫu:**
```md
![Dự án ERP “xong” có phần nhìn thấy (cài phần mềm, nhân viên …](/images/insights/tai-sao-du-an-erp-that-bai/erpf-01-what-failure-looks-like-vi.svg)
![Doanh nghiệp có nền tảng đi qua ERP thì điểm mạnh được nhân …](/images/insights/tai-sao-du-an-erp-that-bai/erpf-02-erp-is-an-amplifier-vi.svg)
![Tám nguyên nhân phổ biến khiến dự án ERP không đạt mục tiêu:…](/images/insights/tai-sao-du-an-erp-that-bai/erpf-03-eight-root-causes-vi.svg)
![Dấu hiệu sớm của dự án ERP gặp vấn đề, chia theo ba giai đoạ…](/images/insights/tai-sao-du-an-erp-that-bai/erpf-04-early-warning-signs-vi.svg)
![Năm thách thức riêng của doanh nghiệp sản xuất khi triển kha…](/images/insights/tai-sao-du-an-erp-that-bai/erpf-05-manufacturing-challenges-vi.svg)
![Sáu câu hỏi về quy trình, dữ liệu, phạm vi, người ra quyết đ…](/images/insights/tai-sao-du-an-erp-that-bai/erpf-06-readiness-before-selection-vi.svg)
```

## EN — `/images/insights/why-erp-projects-fail/`

```yaml
cover_image: /images/insights/why-erp-projects-fail/erpf-00-og-cover-en.png
og_image: /images/insights/why-erp-projects-fail/erpf-00-og-cover-en.png
cover_alt: "Two input streams pass through the same ERP block: the orderly one comes out as multiplied order, the messy one as multiplied chaos."
```

| # | File | Đặt ở mục (H2) |
|---|---|---|
| 1 | `erpf-01-what-failure-looks-like-en.svg` | What Does ERP “Failure” Actually Mean? |
| 2 | `erpf-02-erp-is-an-amplifier-en.svg` | The Problem Is Not the Software |
| 3 | `erpf-03-eight-root-causes-en.svg` | 8 Root Causes of ERP Underperformance (end of section, after cause #8) |
| 4 | `erpf-04-early-warning-signs-en.svg` | Early Warning Signs — Before the Project Runs Into Trouble |
| 5 | `erpf-05-manufacturing-challenges-en.svg` | Manufacturing SMEs Face Additional Challenges |
| 6 | `erpf-06-readiness-before-selection-en.svg` | The Right Question Is Not “Which ERP?” |

**Alt:**

1. `what-failure-looks-like`: A “finished” ERP project has a visible side (software installed, employees logging in, data entered) and a hidden side (real work still on spreadsheets and email, data not trusted, customization growing, operations unchanged); without changed operations it is still a business failure.
2. `erp-is-an-amplifier`: An organization with foundations passing through ERP has its strengths multiplied; an organization not yet ready passing through the same ERP has its weaknesses multiplied on a more complex and expensive system.
3. `eight-root-causes`: Eight common root causes of ERP underperformance: unstandardized processes, poor data, uncontrolled scope, too much customization, people not changing how they work, no governance after go-live, finance not ready, and no definition of success.
4. `early-warning-signs`: Early warning signs of an ERP project in trouble, in three project stages: preparation, implementation and after go-live, four signs each.
5. `manufacturing-challenges`: Five challenges specific to manufacturing SMEs implementing ERP: BOM, quality and traceability, equipment integration, units of measure and yield, and seasonality.
6. `readiness-before-selection`: Six questions on processes, data, scope, decision-makers, change management and post-project ownership must be answered before the question of which ERP and which implementation partner.

**Markdown mẫu:**
```md
![A “finished” ERP project has a visible side (software instal…](/images/insights/why-erp-projects-fail/erpf-01-what-failure-looks-like-en.svg)
![An organization with foundations passing through ERP has its…](/images/insights/why-erp-projects-fail/erpf-02-erp-is-an-amplifier-en.svg)
![Eight common root causes of ERP underperformance: unstandard…](/images/insights/why-erp-projects-fail/erpf-03-eight-root-causes-en.svg)
![Early warning signs of an ERP project in trouble, in three p…](/images/insights/why-erp-projects-fail/erpf-04-early-warning-signs-en.svg)
![Five challenges specific to manufacturing SMEs implementing …](/images/insights/why-erp-projects-fail/erpf-05-manufacturing-challenges-en.svg)
![Six questions on processes, data, scope, decision-makers, ch…](/images/insights/why-erp-projects-fail/erpf-06-readiness-before-selection-en.svg)
```
