import sys, re
import cairosvg
sys.path.insert(0, '/home/claude/erpf')
from lib import Fig, LIGHT, DARK, tw
import build_erpf as B
from build_erpf import bind, curly, chip, head, make, var_check, two_cols

OUT = '/home/claude/erpu/out'
CHK = '/home/claude/erpu/check'

B.PAIRS += ['scope creep', 'go-live', 'kick-off', 'giai đoạn', 'nhà triển khai', 'ngân sách', 'dự phòng', 'đánh giá', 'tác động', 'quy trình', 'yêu cầu', 'thay đổi', 'nguyên nhân', 'gốc rễ', 'nợ kỹ thuật', 'người có thẩm quyền', 'chi phí', 'rủi ro', 'bảo trì', 'nâng cấp', 'user adoption', 'change management', 'super user', 'người dùng', 'nhân viên', 'đào tạo']

CONC_VI = 'Sơ đồ minh họa khái niệm từ bài viết, không phải số liệu đo lường.'
CONC_EN = 'Conceptual diagram from the article, not measured data.'

VI = dict(
    mt=62,
    t={1: 'Bốn lo ngại khiến nhân viên kháng cự ERP',
       2: 'Ba dạng kháng cự phổ biến',
       3: 'Bốn sai lầm phổ biến khi đào tạo ERP',
       4: 'Đào tạo phần mềm không phải change management',
       5: 'Năm yếu tố change management hiệu quả',
       6: 'Sáu câu hỏi: đã sẵn sàng cho change management chưa?',
       0: 'ERP và con người:\nvì sao user adoption quyết định thành bại'},
    s={1: 'Phần lớn là lo ngại hợp lý chưa được giải quyết, không chỉ là thái độ tiêu cực.',
       2: 'Cả ba đều khiến ERP không phản ánh thực tế vận hành.',
       3: 'Vấn đề thường nằm ở thời điểm, cách làm và hỗ trợ sau đào tạo.',
       4: 'Câu hỏi thứ hai cần được trả lời trước.',
       5: 'Mỗi yếu tố giải quyết một lo ngại của người dùng cuối.',
       6: 'Tự đánh giá trước go-live.'},
    f={1: 'Phân tích từ bài viết, không phải thống kê.',
       2: 'Phân tích từ bài viết, không phải thống kê.',
       3: 'Phân tích từ bài viết, không phải thống kê.',
       4: 'Sơ đồ minh họa khái niệm từ bài viết, không phải số liệu đo lường.',
       5: 'Phân tích từ bài viết, không phải thống kê.',
       6: 'Câu hỏi tự đánh giá từ bài viết, là công cụ thảo luận định hướng, không phải phương pháp luận được chứng nhận.'},
    c1=[('Phức tạp hơn, không thấy lợi ích', 'ERP thường thêm bước vào việc người dùng vốn làm nhanh.'),
        ('Sợ làm sai', 'Lo nhập sai, phê duyệt nhầm; thiếu đào tạo và nơi hỏi thì tránh dùng.'),
        ('Dữ liệu không đáng tin', 'Dữ liệu kém làm giảm niềm tin, rồi dữ liệu càng kém hơn.'),
        ('Không có thời gian học', 'Áp lực vận hành khiến người dùng kẹt giữa hai hệ thống.')],
    e1='Kháng cự thường phản ánh lo ngại mà tổ chức chưa giải quyết.',
    c2=[('Kháng cự thụ động', 'Nhập tối thiểu, vẫn giữ Excel và sổ tay song song.'),
        ('Kháng cự ngầm', 'Xử lý ngoài hệ thống, nhờ người khác nhập thay hoặc tạo quy trình riêng.'),
        ('Kháng cự công khai', 'Thường là quản lý trung gian chê hệ thống; dễ thấy nhất và dễ lan.')],
    hard='Khó phát hiện nhất',
    e2='Cả ba dạng đều làm giá trị của ERP giảm dần theo thời gian.',
    c3=[('Đào tạo quá muộn', 'Thường chỉ 1–2 tuần trước go-live, ít thời gian thực hành.'),
        ('Đào tạo kiểu demo', 'Người dùng xem và gật đầu, nhưng học thật bằng cách tự làm và được sửa.'),
        ('Không gắn với công việc thực tế', 'Dạy thao tác nhưng không nói ai phê duyệt, khi nào nhập, cần đính kèm gì.'),
        ('Thiếu hỗ trợ sau đào tạo', 'Không có kênh hỏi hay người phụ trách; người dùng tự xử lý, thường là bỏ qua hệ thống.')],
    e3='Đào tạo cần thực hành, gắn với quy trình công ty và có hỗ trợ sau đó.',
    a_t='Đào tạo phần mềm', a_q='“Làm thao tác này thế nào?”', a_n='Cần thiết, nhưng chưa đủ để tạo thay đổi hành vi bền vững.',
    b_t='Change management', b_q='“Vì sao tôi nên đổi, và điều đó có ý nghĩa gì với tôi?”', b_n='Phải được trả lời trước.',
    first='Trả lời trước',
    e4='Biết cách làm mà không hiểu lý do thì không tạo được thay đổi bền vững.',
    c5=[('Truyền thông sớm và rõ ràng', 'Về ảnh hưởng đến công việc, lịch trình và cách hỗ trợ.'),
        ('Lợi ích theo góc nhìn người dùng', 'Như bớt chờ phê duyệt qua email, theo dõi đơn hàng theo thời gian thực.'),
        ('Super user', 'Nhóm nội bộ hỗ trợ đồng nghiệp hằng ngày, bền hơn chỉ dựa vào nhà triển khai.'),
        ('Lãnh đạo dùng hệ thống trước', 'Yêu cầu báo cáo từ ERP, ra quyết định dựa trên dữ liệu đó.'),
        ('Môi trường thử an toàn', 'Sandbox hoặc parallel run để thực hành với dữ liệu thật.')],
    e5='Lãnh đạo dùng ERP trước là tín hiệu mạnh nhất cho cả tổ chức.',
    q6=['Nhân viên có biết dự án đang ở đâu và ảnh hưởng đến công việc của họ ra sao?',
        'Có giải thích được lợi ích cụ thể cho từng nhóm người dùng không?',
        'Có kế hoạch đào tạo thực hành, không chỉ demo, trước go-live không?',
        'Mỗi bộ phận đã có super user chưa?',
        'Lãnh đạo có cam kết dùng ERP để ra quyết định sau go-live không?',
        'Có kênh hỗ trợ rõ ràng khi người dùng gặp vấn đề sau go-live không?'],
    e6='Nhiều câu trả lời “không”: cần chuẩn bị thêm trước go-live.',
    kick='OKELAS · Insights · ERP',
    src='Công việc thực tế', ch=['Excel', 'Email', 'Tin nhắn'],
    cl='Công việc vẫn chạy qua Excel, email, tin nhắn', cr='ERP chỉ là nơi nhập liệu cho đủ',
)

EN = dict(
    mt=62,
    t={1: 'Four concerns behind employee resistance to ERP',
       2: 'Three common patterns of resistance',
       3: 'Four common ERP training mistakes',
       4: 'Software training is not change management',
       5: 'Five change management elements that work',
       6: 'Six questions: ready for change management?',
       0: 'ERP User Adoption:\nThe Human Factor in ERP Success'},
    s={1: 'Mostly reasonable concerns the organization has not addressed, not just a bad attitude.',
       2: 'All three leave ERP out of step with operational reality.',
       3: 'The problem is usually timing, approach and support after training.',
       4: 'The second question has to be answered first.',
       5: 'Each element addresses a concern of the end user.',
       6: 'A self-check before go-live.'},
    f={1: 'Analysis from the article, not statistics.',
       2: 'Analysis from the article, not statistics.',
       3: 'Analysis from the article, not statistics.',
       4: 'Conceptual diagram from the article, not measured data.',
       5: 'Analysis from the article, not statistics.',
       6: 'Self-assessment questions from the article, a discussion aid, not a certified methodology.'},
    c1=[('More complicated, no personal benefit', 'ERP often adds steps to tasks people already do quickly.'),
        ('Fear of getting it wrong', 'Worry about wrong entries or approvals; weak training and no support push people away.'),
        ('Data they cannot trust', 'Poor data lowers trust, and then the data gets worse.'),
        ('No time to learn', 'Operational pressure traps users between two systems.')],
    e1='Resistance usually reflects concerns the organization has not addressed.',
    c2=[('Passive resistance', 'Minimal entry, with spreadsheets and notebooks kept alongside.'),
        ('Quiet workarounds', 'Off-system handling, colleagues entering data for someone, unofficial processes.'),
        ('Open resistance', 'Often middle managers criticizing the system; the most visible and likely to spread.')],
    hard='Hardest to detect',
    e2='All three erode the value of ERP over time.',
    c3=[('Training happens too late', 'Often one or two weeks before launch, with little time to practice.'),
        ('Training is a demonstration', 'Users watch and nod, but real learning comes from doing and being corrected.'),
        ('Disconnected from actual work', 'Teaches the action, not who approves, when to enter or what to attach.'),
        ('No support after training', 'No channel or named contact; users solve it alone, often by avoiding the system.')],
    e3='Training needs practice, ties to company process and continues with support.',
    a_t='Software training', a_q='“How do I perform this action?”', a_n='Necessary, but not enough for lasting behavior change.',
    b_t='Change management', b_q='“Why should I change how I work, and what does it mean for me?”', b_n='Must be answered first.',
    first='Answer first',
    e4='Knowing how without understanding why does not produce lasting change.',
    c5=[('Early, clear communication', 'On daily work, timeline and available support.'),
        ('Benefits from the end user’s view', 'Such as no waiting on email approvals, real-time order tracking.'),
        ('Super users', 'Internal experts who support colleagues daily; more sustainable than relying on the partner.'),
        ('Visible leadership use', 'Request reports from ERP and decide from its data.'),
        ('A safe practice space', 'A sandbox or parallel run to practice with real data.')],
    e5='Leaders using ERP first is the strongest signal to the whole organization.',
    q6=['Do employees know where the project stands and how it affects their jobs?',
        'Can you state the concrete benefits for each user group?',
        'Is there a hands-on practice plan, not just a demo, before go-live?',
        'Has a super user been named for each department?',
        'Is leadership committed to using ERP for decisions after go-live?',
        'Is there a clear support channel for problems after go-live?'],
    e6='Several “no” answers: more preparation is needed before go-live.',
    kick='OKELAS · Insights · ERP',
    src='Day-to-day work', ch=['Spreadsheets', 'Email', 'Messaging apps'],
    cl='Work still runs through spreadsheets, email and chat', cr='ERP is only a data-entry requirement',
)

ALT = {
    'vi': {
        1: 'Bốn lo ngại khiến nhân viên kháng cự ERP: phức tạp hơn và không thấy lợi ích cho bản thân, sợ làm sai, dữ liệu không đáng tin và không có thời gian học.',
        2: 'Ba dạng kháng cự phổ biến: kháng cự thụ động, kháng cự ngầm là dạng khó phát hiện nhất và kháng cự công khai.',
        3: 'Bốn sai lầm phổ biến khi đào tạo ERP: đào tạo quá muộn, đào tạo kiểu demo, không gắn với công việc thực tế và thiếu hỗ trợ sau đào tạo.',
        4: 'Đào tạo phần mềm trả lời câu hỏi làm thao tác này thế nào, còn change management trả lời vì sao tôi nên đổi và điều đó có ý nghĩa gì với tôi; câu hỏi thứ hai cần được trả lời trước.',
        5: 'Năm yếu tố change management hiệu quả: truyền thông sớm và rõ ràng, lợi ích theo góc nhìn người dùng, super user, lãnh đạo dùng hệ thống trước và môi trường thử an toàn.',
        6: 'Sáu câu hỏi tự đánh giá mức sẵn sàng change management: thông tin dự án, lợi ích theo nhóm người dùng, đào tạo thực hành, super user, cam kết của lãnh đạo và kênh hỗ trợ sau go-live.',
        0: 'Một vòng tròn công việc thực tế gửi nhiều luồng tới Excel, email và tin nhắn, chỉ một luồng mảnh đi vào khối ERP.'},
    'en': {
        1: 'Four concerns behind employee resistance to ERP: more complicated with no personal benefit, fear of getting it wrong, data they cannot trust and no time to learn.',
        2: 'Three common patterns of resistance: passive resistance, quiet workarounds as the hardest to detect, and open resistance.',
        3: 'Four common ERP training mistakes: training too late, training as a demonstration, training disconnected from actual work and no support afterwards.',
        4: 'Software training answers how do I perform this action, while change management answers why should I change how I work and what does it mean for me; the second question must be answered first.',
        5: 'Five change management elements that work: early and clear communication, benefits from the end user’s view, super users, visible leadership use and a safe practice space.',
        6: 'Six self-assessment questions on change management readiness: project awareness, benefits per user group, hands-on practice, super users, leadership commitment and post-go-live support.',
        0: 'A circle of day-to-day work sends heavy flows to spreadsheets, email and messaging apps, with only a thin flow reaching the ERP block.'},
}

VI = bind(VI)
EN = curly(EN)
LANGS = {'vi': VI, 'en': EN}
NAMES = {1: 'four-concerns', 2: 'three-resistance-patterns', 3: 'four-training-mistakes',
         4: 'training-vs-change-management', 5: 'five-change-elements', 6: 'six-readiness-questions'}


def numc(f, x, y, n, col='p', r=15):
    f.circle(x, y, r, col)
    f._line(x, y - 10, str(n), 15, 700, 'wh', 'middle', 20)


def cards(f, L, k, key, fill, stroke, n, numbered=False, big=False, pillidx=None):
    head(f, L, k)
    items = L[key]
    gap, y = 15, 134
    cw = round((1080 - gap * (n - 1)) / n)
    ts, ds = (18, 14) if big else (16, 13)
    top = 62 if numbered else (52 if pillidx is not None else 20)
    need = 0
    for t, d in items:
        need = max(need, top + f.measure(t, ts, 700, cw - 32) + 10 + f.measure(d, ds, 400, cw - 32, 1.42) + 20)
    ch = round(need)
    for i, (t, d) in enumerate(items):
        x = 60 + i * (cw + gap)
        hl = pillidx == i
        f.rect(x, y, cw, ch, fill, stroke, 16, 3 if hl else 1.8)
        if numbered:
            numc(f, x + 32, y + 32, i + 1, stroke)
        if hl:
            f.pill(x + 16, y + 16, L['hard'], 'a', 'bg', 12, 'start', 24, 10)
        th = f.para(x + 16, y + top, t, ts, 700, 'hd', cw - 32)
        f.para(x + 16, y + top + th + 10, d, ds, 400, 'tx', cw - 32, lhr=1.42)
    f.ink(y + ch + 16, L['e%d' % k])


def fig1(f, L): cards(f, L, 1, 'c1', 'at', 'a', 4, big=True)
def fig2(f, L): cards(f, L, 2, 'c2', 'at', 'a', 3, big=True, pillidx=1)
def fig3(f, L): cards(f, L, 3, 'c3', 'pt', 'p', 4, big=True)
def fig5(f, L): cards(f, L, 5, 'c5', 'pt', 'p', 5, numbered=True)


def fig4(f, L):
    head(f, L, 4)
    y, h = 134, 196
    for x, t, q, n, fill, st, dash in ((60, L['a_t'], L['a_q'], L['a_n'], 'gt', 'gm', '6 5'),
                                        (612, L['b_t'], L['b_q'], L['b_n'], 'pt', 'p', None)):
        f.rect(x, y, 528, h, fill, st, 16, 1.8, dash)
        f.para(x + 24, y + 22, t, 22, 700, 'hd', 480)
        qh = f.para(x + 24, y + 70, q, 20, 700, 's' if st == 'p' else 'mut', 480)
        f.para(x + 24, y + 70 + qh + 16, n, 14, 400, 'tx', 480, lhr=1.42)
    f.pill(1140 - 24, y + 20, L['first'], 'a', 'at', 12, 'end', 24, 10)
    f.ink(y + h + 16, L['e4'])


def fig6(f, L):
    head(f, L, 6)
    n, gap, y = 3, 15, 134
    cw = 350
    need = 0
    for q in L['q6']:
        need = max(need, f.measure(q, 15, 700, cw - 76) + 32)
    ch = max(round(need), 84)
    for i, q in enumerate(L['q6']):
        r, c = divmod(i, 3)
        x, yy = 60 + c * (cw + gap), y + r * (ch + gap)
        f.rect(x, yy, cw, ch, 'pt', 'p', 14, 1.8)
        numc(f, x + 32, yy + ch / 2, i + 1, 'p')
        qh = f.measure(q, 15, 700, cw - 76)
        f.para(x + 60, yy + (ch - qh) / 2, q, 15, 700, 'hd', cw - 76)
    f.ink(y + 2 * ch + gap + 16, L['e6'])


def figcover(f, L):
    f.rect(0, 0, 1200, 630, 'bg', None, 0)
    f.rect(0, 0, 14, 630, 'p', None, 0)
    f._line(60, 44, L['kick'], 16, 700, 's', 'start', 22)
    f.para(60, 84, L['t'][0], 40, 700, 'hd', 1040, lhr=1.25)
    cx, cy, r = 190, 395, 72
    f.circle(cx, cy, r, 'pt', 'p', 2.4)
    f.box_text(cx - 58, cy - 30, 116, 60, L['src'], 15, 700, 'hd', 4)
    ex, ew, eh = 860, 240, 120
    f.rect(ex, cy - eh / 2, ew, eh, 'ink', None, 18)
    f._line(ex + ew / 2, cy - 25, 'ERP', 40, 700, 'onink', 'middle', 50)
    cw_, ch_ = 240, 46
    for i, t in enumerate(L['ch']):
        y = 315 + i * 64
        f.arrow(cx + r + 6, cy, 394, y + ch_ / 2, 'a', 3.5, 11)
        f.rect(400, y, cw_, ch_, 'at', 'a', 12, 2, '6 5')
        f.box_text(400, y, cw_, ch_, t, 15, 700, 'hd', 8)
        f.arrow(646, y + ch_ / 2, ex - 6, cy, 'gm', 1.5, 7)
    f.para(400, 522, L['cl'], 15, 700, 'a', 380)
    f.para(820, 522, L['cr'], 15, 700, 's', 330)
    f.mark(H_COVER - 30)


H_COVER = 630
FIGS = {1: fig1, 2: fig2, 3: fig3, 4: fig4, 5: fig5, 6: fig6}


def build(sel=None):
    for lang, L in LANGS.items():
        for k in list(FIGS) + [0]:
            if sel and k not in sel:
                continue
            label = ALT[lang][k]
            fn = figcover if k == 0 else FIGS[k]
            name = f'erpu-00-og-cover-{lang}' if k == 0 else f'erpu-{k:02d}-{NAMES[k]}-{lang}'
            if k == 0:
                s = Fig(H_COVER, 'svg', False, label); fn(s, L)
                p = Fig(H_COVER, 'png', False, label); fn(p, L)
                d = Fig(H_COVER, 'png', True, label); fn(d, L)
                H = H_COVER
            else:
                s = make(fn, L, label, 'svg')
                H = s.H
                p = make(fn, L, label, 'png', False, H)
                d = make(fn, L, label, 'png', True, H)
            svg = s.svg()
            assert var_check(svg, p.svg()), 'adaptive vs light mismatch ' + name
            open(f'{OUT}/{lang}/{name}.svg', 'w', encoding='utf-8').write(svg)
            if k == 0:
                cairosvg.svg2png(bytestring=p.svg().encode('utf-8'), write_to=f'{OUT}/{lang}/{name}.png', output_width=1200)
            cairosvg.svg2png(bytestring=p.svg().encode('utf-8'), write_to=f'{CHK}/{name}-light.png', output_width=1200)
            cairosvg.svg2png(bytestring=d.svg().encode('utf-8'), write_to=f'{CHK}/{name}-dark.png', output_width=1200)
            print('ok', name, 'H', H)


if __name__ == '__main__':
    build([int(a) for a in sys.argv[1:]] or None)
