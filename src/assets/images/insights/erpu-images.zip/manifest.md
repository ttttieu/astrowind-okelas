# Manifest hình bài User adoption ERP (VI + EN)

Tiền tố cụm: `erpu`. Cover PNG 1200×630; hình thường SVG (inline có dark mode; dùng `<img>` thì cần xuất PNG light).

## VI — `/images/insights/user-adoption-erp/`

```yaml
cover_image: /images/insights/user-adoption-erp/erpu-00-og-cover-vi.png
og_image: /images/insights/user-adoption-erp/erpu-00-og-cover-vi.png
cover_alt: "Một vòng tròn công việc thực tế gửi nhiều luồng tới Excel, email và tin nhắn, chỉ một luồng mảnh đi vào khối ERP."
```

| # | File | Đặt ở mục |
|---|---|---|
| 1 | `erpu-01-four-concerns-vi.svg` | Tại sao nhân viên kháng cự ERP? |
| 2 | `erpu-02-three-resistance-patterns-vi.svg` | Ba dạng kháng cự phổ biến |
| 3 | `erpu-03-four-training-mistakes-vi.svg` | Những sai lầm phổ biến trong đào tạo ERP |
| 4 | `erpu-04-training-vs-change-management-vi.svg` | Change management không phải đào tạo phần mềm |
| 5 | `erpu-05-five-change-elements-vi.svg` | Change management không phải đào tạo phần mềm — năm yếu tố hiệu quả (cuối mục) |
| 6 | `erpu-06-six-readiness-questions-vi.svg` | Tự đánh giá: doanh nghiệp đã sẵn sàng cho change management chưa? |

**Alt:**

1. `four-concerns`: Bốn lo ngại khiến nhân viên kháng cự ERP: phức tạp hơn và không thấy lợi ích cho bản thân, sợ làm sai, dữ liệu không đáng tin và không có thời gian học.
2. `three-resistance-patterns`: Ba dạng kháng cự phổ biến: kháng cự thụ động, kháng cự ngầm là dạng khó phát hiện nhất và kháng cự công khai.
3. `four-training-mistakes`: Bốn sai lầm phổ biến khi đào tạo ERP: đào tạo quá muộn, đào tạo kiểu demo, không gắn với công việc thực tế và thiếu hỗ trợ sau đào tạo.
4. `training-vs-change-management`: Đào tạo phần mềm trả lời câu hỏi làm thao tác này thế nào, còn change management trả lời vì sao tôi nên đổi và điều đó có ý nghĩa gì với tôi; câu hỏi thứ hai cần được trả lời trước.
5. `five-change-elements`: Năm yếu tố change management hiệu quả: truyền thông sớm và rõ ràng, lợi ích theo góc nhìn người dùng, super user, lãnh đạo dùng hệ thống trước và môi trường thử an toàn.
6. `six-readiness-questions`: Sáu câu hỏi tự đánh giá mức sẵn sàng change management: thông tin dự án, lợi ích theo nhóm người dùng, đào tạo thực hành, super user, cam kết của lãnh đạo và kênh hỗ trợ sau go-live.

**Markdown mẫu:**
```md
![Bốn lo ngại khiến nhân viên kháng cự ERP: phức tạp hơn và kh…](/images/insights/user-adoption-erp/erpu-01-four-concerns-vi.svg)
![Ba dạng kháng cự phổ biến: kháng cự thụ động, kháng cự ngầm …](/images/insights/user-adoption-erp/erpu-02-three-resistance-patterns-vi.svg)
![Bốn sai lầm phổ biến khi đào tạo ERP: đào tạo quá muộn, đào …](/images/insights/user-adoption-erp/erpu-03-four-training-mistakes-vi.svg)
![Đào tạo phần mềm trả lời câu hỏi làm thao tác này thế nào, c…](/images/insights/user-adoption-erp/erpu-04-training-vs-change-management-vi.svg)
![Năm yếu tố change management hiệu quả: truyền thông sớm và r…](/images/insights/user-adoption-erp/erpu-05-five-change-elements-vi.svg)
![Sáu câu hỏi tự đánh giá mức sẵn sàng change management: thôn…](/images/insights/user-adoption-erp/erpu-06-six-readiness-questions-vi.svg)
```

## EN — `/images/insights/erp-user-adoption/`

```yaml
cover_image: /images/insights/erp-user-adoption/erpu-00-og-cover-en.png
og_image: /images/insights/erp-user-adoption/erpu-00-og-cover-en.png
cover_alt: "A circle of day-to-day work sends heavy flows to spreadsheets, email and messaging apps, with only a thin flow reaching the ERP block."
```

| # | File | Đặt ở mục |
|---|---|---|
| 1 | `erpu-01-four-concerns-en.svg` | Why Employees Resist ERP |
| 2 | `erpu-02-three-resistance-patterns-en.svg` | Three Common Patterns of Resistance |
| 3 | `erpu-03-four-training-mistakes-en.svg` | Common ERP Training Mistakes |
| 4 | `erpu-04-training-vs-change-management-en.svg` | Change Management Is Not Software Training |
| 5 | `erpu-05-five-change-elements-en.svg` | Change Management Is Not Software Training — elements that work (end of section) |
| 6 | `erpu-06-six-readiness-questions-en.svg` | Self-Assessment |

**Alt:**

1. `four-concerns`: Four concerns behind employee resistance to ERP: more complicated with no personal benefit, fear of getting it wrong, data they cannot trust and no time to learn.
2. `three-resistance-patterns`: Three common patterns of resistance: passive resistance, quiet workarounds as the hardest to detect, and open resistance.
3. `four-training-mistakes`: Four common ERP training mistakes: training too late, training as a demonstration, training disconnected from actual work and no support afterwards.
4. `training-vs-change-management`: Software training answers how do I perform this action, while change management answers why should I change how I work and what does it mean for me; the second question must be answered first.
5. `five-change-elements`: Five change management elements that work: early and clear communication, benefits from the end user’s view, super users, visible leadership use and a safe practice space.
6. `six-readiness-questions`: Six self-assessment questions on change management readiness: project awareness, benefits per user group, hands-on practice, super users, leadership commitment and post-go-live support.

**Markdown mẫu:**
```md
![Four concerns behind employee resistance to ERP: more compli…](/images/insights/erp-user-adoption/erpu-01-four-concerns-en.svg)
![Three common patterns of resistance: passive resistance, qui…](/images/insights/erp-user-adoption/erpu-02-three-resistance-patterns-en.svg)
![Four common ERP training mistakes: training too late, traini…](/images/insights/erp-user-adoption/erpu-03-four-training-mistakes-en.svg)
![Software training answers how do I perform this action, whil…](/images/insights/erp-user-adoption/erpu-04-training-vs-change-management-en.svg)
![Five change management elements that work: early and clear c…](/images/insights/erp-user-adoption/erpu-05-five-change-elements-en.svg)
![Six self-assessment questions on change management readiness…](/images/insights/erp-user-adoption/erpu-06-six-readiness-questions-en.svg)
```
