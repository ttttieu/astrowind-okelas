import sys, re
import cairosvg
sys.path.insert(0, '/home/claude/erpf')
from lib import Fig, LIGHT, DARK, tw
import build_erpf as B
from build_erpf import bind, curly, chip, head, make, var_check, two_cols

OUT = '/home/claude/erpk/out'
CHK = '/home/claude/erpk/check'

B.PAIRS += ['scope creep', 'go-live', 'kick-off', 'giai đoạn', 'nhà triển khai', 'ngân sách', 'dự phòng', 'đánh giá', 'tác động', 'quy trình', 'yêu cầu', 'thay đổi', 'nguyên nhân', 'gốc rễ', 'nợ kỹ thuật', 'người có thẩm quyền', 'chi phí', 'rủi ro', 'bảo trì', 'nâng cấp']

CONC_VI = 'Sơ đồ minh họa khái niệm từ bài viết, không phải số liệu đo lường.'
CONC_EN = 'Conceptual diagram from the article, not measured data.'

VI = dict(
    mt=62,
    t={1: 'Configuration khác customization',
       2: 'Ba trường hợp customization hợp lý',
       3: 'Bốn nguồn customization không cần thiết',
       4: 'Năm chi phí ẩn của customization quá mức',
       5: 'Năm câu hỏi trước khi chấp nhận một customization',
       0: 'Customization ERP:\nranh giới giữa linh hoạt và rủi ro'},
    s={1: 'Một bên điều chỉnh trong phạm vi phần mềm hỗ trợ; bên kia đổi hành vi mặc định bằng code.',
       2: 'Mỗi trường hợp đều cần lý do kinh doanh rõ ràng.',
       3: 'Customization thường là phản ứng, không phải quyết định có phân tích.',
       4: 'Những chi phí này thường không được tính vào TCO ban đầu.',
       5: 'Trả lời lần lượt trước khi chấp thuận bất kỳ yêu cầu nào.'},
    f={1: 'Sơ đồ minh họa khái niệm từ bài viết, không phải số liệu đo lường.',
       2: 'Phân tích từ bài viết, không phải thống kê.',
       3: 'Phân tích từ bài viết, không phải thống kê.',
       4: 'Chi phí theo phân tích trong bài viết, không phải số liệu đo lường.',
       5: 'Framework từ bài viết, là công cụ thảo luận định hướng, không phải phương pháp luận được chứng nhận.'},
    a_t='Configuration', a_d='Điều chỉnh trong phạm vi phần mềm đã hỗ trợ, không cần sửa code',
    a_i=['Workflow phê duyệt', 'Tiền tệ', 'Danh mục sản phẩm', 'Phân quyền người dùng'],
    b_t='Customization', b_d='Thay đổi hành vi mặc định bằng code, sửa code gốc hoặc module mới',
    b_i=['Logic tính giá riêng', 'Màn hình nhập liệu mới', 'Tích hợp với hệ thống ngoài'],
    e1='Gọi customization là “cấu hình thêm một chút” là cách nợ kỹ thuật tích lũy.',
    c2=[('Yêu cầu pháp lý hoặc compliance', 'Thuế địa phương, báo cáo nhà nước, ISO, GMP, HACCP.'),
        ('Quy trình tạo lợi thế cạnh tranh', 'Đo lường được và không thể làm bằng configuration.'),
        ('Tích hợp không thể thay thế', 'Thiết bị sản xuất, hệ thống cân, phần mềm ngành không có connector sẵn.')],
    e2='Cần lý do kinh doanh rõ, chi phí tính đủ và người có thẩm quyền quyết định.',
    c3=[('Quy trình chưa chuẩn hóa', 'Bắt ERP chạy theo cách cũ thay vì xem xét lại quy trình.'),
        ('Không muốn thay đổi cách làm việc', 'Ít kháng cự trong ngắn hạn, nhưng tốn kém về dài hạn.'),
        ('Áp lực timeline', 'Deadline gấp khiến nhà triển khai chọn giải pháp nhanh.'),
        ('Yêu cầu báo cáo chưa phân tích', 'Báo cáo chuẩn của ERP đã đáp ứng được chưa?')],
    e3='Phần lớn customization bắt nguồn từ quy trình chưa chuẩn hóa hoặc yêu cầu chưa phân tích.',
    c4=[('Bảo trì định kỳ', 'Phải cập nhật khi quy trình hoặc quy định thay đổi.'),
        ('Rủi ro khi nâng cấp', 'Mỗi lần nâng cấp phải kiểm tra lại mọi customization.'),
        ('Phụ thuộc vào vài người', 'Khi người xây dựng rời đi, khó có ai bảo trì tiếp.'),
        ('Khó tích hợp công cụ mới', 'Như BI, CRM, QMS.'),
        ('Mất best practice', 'Thực hành ngành mà ERP chuẩn đã tổng hợp.')],
    e4='Customization quá mức tăng chi phí bảo trì, rủi ro nâng cấp và sự phụ thuộc.',
    q=[('Đây là customization hay configuration?', 'Nếu là configuration, làm ngay.'),
       ('Có thể đổi quy trình để phù hợp ERP không?', 'Quy trình có nên vận hành theo cách ERP hỗ trợ?'),
       ('Chi phí thực tế là bao nhiêu?', 'Lập trình, kiểm thử, bảo trì, nâng cấp, rủi ro phụ thuộc.'),
       ('Lợi ích kinh doanh có đo lường được không?', 'Nếu không, cân nhắc lại.'),
       ('Ai là người quyết định?', 'Người có thẩm quyền kinh doanh, không chỉ nhóm dự án hay IT.')],
    e5='Quyết định customization cần một framework, không phải phản ứng theo yêu cầu.',
    kick='OKELAS · Insights · ERP',
    lc=['Workflow', 'Phân quyền', 'Danh mục'], rc=['Logic tính giá', 'Màn hình mới', 'Tích hợp ngoài'],
    cl='Configuration: trong phạm vi phần mềm hỗ trợ', cr='Customization: thêm code, thêm nợ kỹ thuật',
)

EN = dict(
    mt=62,
    t={1: 'Configuration is not customization',
       2: 'Three cases where customization is justified',
       3: 'Four sources of unnecessary customization',
       4: 'Five hidden costs of over-customized ERP',
       5: 'Five questions before approving a customization',
       0: 'ERP Customization Risks:\nFlexibility vs. Technical Debt'},
    s={1: 'One adjusts within what the software supports; the other changes default behavior through code.',
       2: 'Each case needs a clear business rationale.',
       3: 'Customization is often a reaction, not an analyzed decision.',
       4: 'These costs are often missing from the initial Total Cost of Ownership.',
       5: 'Answer in order before approving any request.'},
    f={1: 'Conceptual diagram from the article, not measured data.',
       2: 'Analysis from the article, not statistics.',
       3: 'Analysis from the article, not statistics.',
       4: 'Costs from the article’s analysis, not measured data.',
       5: 'Framework from the article, a discussion aid, not a certified methodology.'},
    a_t='Configuration', a_d='Works within the software’s design; no code changes needed',
    a_i=['Approval workflow', 'Currencies and tax rates', 'Product categories', 'User permissions'],
    b_t='Customization', b_d='Changes default behavior through code or new modules',
    b_i=['Custom pricing logic', 'New data entry screen', 'Integration with a system with no native connector'],
    e1='Treating customization as “a bit of extra configuration” is how technical debt builds up.',
    c2=[('Regulatory or compliance requirements', 'Local tax law, government reporting, ISO, GMP, HACCP.'),
        ('Competitive advantage', 'A differentiating process that configuration cannot meet.'),
        ('Irreplaceable systems', 'Production equipment, industrial scales or industry software with no standard connector.')],
    e2='Needs a clear business rationale, a full cost estimate and a decision by someone with authority.',
    c3=[('Unstandardized processes', 'ERP is used to lock in current habits instead of improving them.'),
        ('Resistance to change', 'Cheap in the short term, costly in the long term.'),
        ('Timeline pressure', 'Deadline-driven fixes rarely optimize for maintainability.'),
        ('Unanalyzed reporting needs', 'Could standard ERP reports already meet them?')],
    e3='Most customization stems from unstandardized processes or unanalyzed requirements.',
    c4=[('Ongoing maintenance', 'Must be updated as processes and regulations change.'),
        ('Upgrade risk', 'Every upgrade requires retesting all customizations.'),
        ('Knowledge concentration', 'When the builders leave, few want to modify the system.'),
        ('Harder integration', 'New tools such as BI, CRM or quality management.'),
        ('Departure from best practice', 'Practices refined across many implementations.')],
    e4='Over-customization raises maintenance cost, upgrade risk and dependence on a few people.',
    q=[('Is this customization or configuration?', 'If it is configuration, do it now.'),
       ('Can the process be adapted to fit ERP?', 'Should this process work the way ERP supports?'),
       ('What is the true total cost?', 'Development, testing, annual maintenance, upgrade impact, dependency risk.'),
       ('Is the business value measurable?', 'If not, reconsider.'),
       ('Who is the decision-maker?', 'Someone with business authority, not only the project or IT team.')],
    e5='Customization needs a structured framework, not a reaction to requests.',
    kick='OKELAS · Insights · ERP',
    lc=['Approvals', 'Permissions', 'Categories'], rc=['Pricing logic', 'New screen', 'Integration'],
    cl='Configuration: within what the software supports', cr='Customization: more code, more technical debt',
)

ALT = {
    'vi': {
        1: 'Configuration điều chỉnh trong phạm vi phần mềm hỗ trợ (workflow phê duyệt, tiền tệ, danh mục sản phẩm, phân quyền) không cần sửa code; customization thay đổi hành vi mặc định bằng code (logic tính giá, màn hình nhập liệu mới, tích hợp hệ thống ngoài).',
        2: 'Ba trường hợp customization hợp lý: yêu cầu pháp lý hoặc compliance, quy trình tạo lợi thế cạnh tranh không thể làm bằng configuration, và tích hợp không thể thay thế với thiết bị hoặc phần mềm ngành.',
        3: 'Bốn nguồn customization không cần thiết: quy trình chưa chuẩn hóa, không muốn thay đổi cách làm việc, áp lực timeline và yêu cầu báo cáo chưa phân tích.',
        4: 'Năm chi phí ẩn của customization quá mức: bảo trì định kỳ, rủi ro khi nâng cấp, phụ thuộc vào vài người, khó tích hợp công cụ mới và mất best practice.',
        5: 'Năm câu hỏi trước khi chấp nhận customization: là customization hay configuration, có đổi quy trình được không, chi phí thực tế, lợi ích có đo lường được không và ai là người quyết định.',
        0: 'Khối ERP ở giữa: bên trái là các mục configuration nằm trong phạm vi phần mềm, bên phải là các khối customization đứt nét thêm code và nợ kỹ thuật.'},
    'en': {
        1: 'Configuration works within the software’s design with no code changes (approval workflow, currencies and tax rates, product categories, user permissions); customization changes default behavior through code (custom pricing logic, a new data entry screen, integration with an external system).',
        2: 'Three cases where customization is justified: regulatory or compliance requirements, a competitive-advantage process configuration cannot meet, and irreplaceable systems such as production equipment or industry software.',
        3: 'Four sources of unnecessary customization: unstandardized processes, resistance to change, timeline pressure and unanalyzed reporting needs.',
        4: 'Five hidden costs of over-customized ERP: ongoing maintenance, upgrade risk, knowledge concentration, harder integration and departure from best practice.',
        5: 'Five questions before approving a customization: is it customization or configuration, can the process adapt, what is the true total cost, is the value measurable and who decides.',
        0: 'An ERP block in the middle: configuration items inside the software’s scope on the left, dashed customization blocks adding code and technical debt on the right.'},
}

VI = bind(VI)
EN = curly(EN)
LANGS = {'vi': VI, 'en': EN}
NAMES = {1: 'configuration-vs-customization', 2: 'three-justified-cases', 3: 'four-unnecessary-sources',
         4: 'five-hidden-costs', 5: 'five-decision-questions'}


def numc(f, x, y, n, col='p', r=15):
    f.circle(x, y, r, col)
    f._line(x, y - 10, str(n), 15, 700, 'wh', 'middle', 20)


def cards(f, L, k, key, fill, stroke, n, numbered=False, big=False):
    head(f, L, k)
    items = L[key]
    gap, y = 15, 134
    cw = round((1080 - gap * (n - 1)) / n)
    ts, ds = (18, 14) if big else (16, 13)
    top = 62 if numbered else 20
    need = 0
    for t, d in items:
        need = max(need, top + f.measure(t, ts, 700, cw - 32) + 10 + f.measure(d, ds, 400, cw - 32, 1.42) + 20)
    ch = round(need)
    for i, (t, d) in enumerate(items):
        x = 60 + i * (cw + gap)
        f.rect(x, y, cw, ch, fill, stroke, 16, 1.8)
        if numbered:
            numc(f, x + 32, y + 32, i + 1, stroke)
        th = f.para(x + 16, y + top, t, ts, 700, 'hd', cw - 32)
        f.para(x + 16, y + top + th + 10, d, ds, 400, 'tx', cw - 32, lhr=1.42)
    f.ink(y + ch + 16, L['e%d' % k])


def fig1(f, L):
    head(f, L, 1)
    two_cols(f, L, 1,
             (L['a_t'], L['a_d'], L['a_i'], 'pt', 'p', None, 44),
             (L['b_t'], L['b_d'], L['b_i'], 'at', 'a', '6 5', 62))


def fig2(f, L): cards(f, L, 2, 'c2', 'pt', 'p', 3, numbered=True, big=True)
def fig3(f, L): cards(f, L, 3, 'c3', 'at', 'a', 4, big=True)
def fig4(f, L): cards(f, L, 4, 'c4', 'at', 'a', 5, numbered=True)


def fig5(f, L):
    head(f, L, 5)
    y, rh, gap = 134, 62, 10
    for i, (q, n) in enumerate(L['q']):
        yy = y + i * (rh + gap)
        f.rect(60, yy, 1080, rh, 'pt', 'p', 14, 1.6)
        numc(f, 96, yy + rh / 2, i + 1, 'p')
        h1 = f.measure(q, 17, 700, 470)
        f.para(130, yy + (rh - h1) / 2, q, 17, 700, 'hd', 470)
        h2 = f.measure(n, 15, 400, 490, 1.38)
        f.para(640, yy + (rh - h2) / 2, n, 15, 400, 'tx', 490)
    f.ink(y + 5 * (rh + gap) + 6, L['e5'])


def figcover(f, L):
    f.rect(0, 0, 1200, 630, 'bg', None, 0)
    f.rect(0, 0, 14, 630, 'p', None, 0)
    f._line(60, 44, L['kick'], 16, 700, 's', 'start', 22)
    f.para(60, 84, L['t'][0], 40, 700, 'hd', 1040, lhr=1.25)
    bx, by, bw, bh = 470, 330, 260, 130
    f.rect(bx, by, bw, bh, 'ink', None, 18)
    f._line(bx + bw / 2, by + bh / 2 - 25, 'ERP', 40, 700, 'onink', 'middle', 50)
    cw_, ch_ = 220, 46
    for i in range(3):
        y = 310 + i * 64
        lx, rx = 100, 880
        f.arrow(lx + cw_ + 6, y + ch_ / 2, bx - 8, by + bh / 2, 'gm', 2.5, 9)
        f.rect(lx, y, cw_, ch_, 'pt', 'p', 12, 1.8)
        f.box_text(lx, y, cw_, ch_, L['lc'][i], 15, 700, 'hd', 8)
        f.arrow(bx + bw + 6, by + bh / 2, rx - 8, y + ch_ / 2, 'gm', 2.5, 9)
        f.rect(rx, y, cw_, ch_, 'at', 'a', 12, 2, '6 5')
        f.box_text(rx, y, cw_, ch_, L['rc'][i], 15, 700, 'hd', 8)
    f.para(100, 522, L['cl'], 15, 700, 's', 340)
    f.para(840, 522, L['cr'], 15, 700, 'a', 300)
    f.mark(H_COVER - 30)


H_COVER = 630
FIGS = {1: fig1, 2: fig2, 3: fig3, 4: fig4, 5: fig5}


def build(sel=None):
    for lang, L in LANGS.items():
        for k in list(FIGS) + [0]:
            if sel and k not in sel:
                continue
            label = ALT[lang][k]
            fn = figcover if k == 0 else FIGS[k]
            name = f'erpk-00-og-cover-{lang}' if k == 0 else f'erpk-{k:02d}-{NAMES[k]}-{lang}'
            if k == 0:
                s = Fig(H_COVER, 'svg', False, label); fn(s, L)
                p = Fig(H_COVER, 'png', False, label); fn(p, L)
                d = Fig(H_COVER, 'png', True, label); fn(d, L)
                H = H_COVER
            else:
                s = make(fn, L, label, 'svg')
                H = s.H
                p = make(fn, L, label, 'png', False, H)
                d = make(fn, L, label, 'png', True, H)
            svg = s.svg()
            assert var_check(svg, p.svg()), 'adaptive vs light mismatch ' + name
            open(f'{OUT}/{lang}/{name}.svg', 'w', encoding='utf-8').write(svg)
            if k == 0:
                cairosvg.svg2png(bytestring=p.svg().encode('utf-8'), write_to=f'{OUT}/{lang}/{name}.png', output_width=1200)
            cairosvg.svg2png(bytestring=p.svg().encode('utf-8'), write_to=f'{CHK}/{name}-light.png', output_width=1200)
            cairosvg.svg2png(bytestring=d.svg().encode('utf-8'), write_to=f'{CHK}/{name}-dark.png', output_width=1200)
            print('ok', name, 'H', H)


if __name__ == '__main__':
    build([int(a) for a in sys.argv[1:]] or None)
