# Manifest hình bài Customization ERP: rủi ro (VI + EN)

Tiền tố cụm: `erpk`. Cover PNG 1200×630; hình thường SVG (inline có dark mode; dùng `<img>` thì cần xuất PNG light).

## VI — `/images/insights/customization-erp-rui-ro/`

```yaml
cover_image: /images/insights/customization-erp-rui-ro/erpk-00-og-cover-vi.png
og_image: /images/insights/customization-erp-rui-ro/erpk-00-og-cover-vi.png
cover_alt: "Khối ERP ở giữa: bên trái là các mục configuration nằm trong phạm vi phần mềm, bên phải là các khối customization đứt nét thêm code và nợ kỹ thuật."
```

| # | File | Đặt ở mục |
|---|---|---|
| 1 | `erpk-01-configuration-vs-customization-vi.svg` | Customization và Configuration — sự khác biệt quan trọng |
| 2 | `erpk-02-three-justified-cases-vi.svg` | Khi nào customization là hợp lý? |
| 3 | `erpk-03-four-unnecessary-sources-vi.svg` | Khi nào customization trở thành vấn đề? |
| 4 | `erpk-04-five-hidden-costs-vi.svg` | Chi phí ẩn của customization quá mức |
| 5 | `erpk-05-five-decision-questions-vi.svg` | Framework để ra quyết định customization |

**Alt:**

1. `configuration-vs-customization`: Configuration điều chỉnh trong phạm vi phần mềm hỗ trợ (workflow phê duyệt, tiền tệ, danh mục sản phẩm, phân quyền) không cần sửa code; customization thay đổi hành vi mặc định bằng code (logic tính giá, màn hình nhập liệu mới, tích hợp hệ thống ngoài).
2. `three-justified-cases`: Ba trường hợp customization hợp lý: yêu cầu pháp lý hoặc compliance, quy trình tạo lợi thế cạnh tranh không thể làm bằng configuration, và tích hợp không thể thay thế với thiết bị hoặc phần mềm ngành.
3. `four-unnecessary-sources`: Bốn nguồn customization không cần thiết: quy trình chưa chuẩn hóa, không muốn thay đổi cách làm việc, áp lực timeline và yêu cầu báo cáo chưa phân tích.
4. `five-hidden-costs`: Năm chi phí ẩn của customization quá mức: bảo trì định kỳ, rủi ro khi nâng cấp, phụ thuộc vào vài người, khó tích hợp công cụ mới và mất best practice.
5. `five-decision-questions`: Năm câu hỏi trước khi chấp nhận customization: là customization hay configuration, có đổi quy trình được không, chi phí thực tế, lợi ích có đo lường được không và ai là người quyết định.

**Markdown mẫu:**
```md
![Configuration điều chỉnh trong phạm vi phần mềm hỗ trợ (work…](/images/insights/customization-erp-rui-ro/erpk-01-configuration-vs-customization-vi.svg)
![Ba trường hợp customization hợp lý: yêu cầu pháp lý hoặc com…](/images/insights/customization-erp-rui-ro/erpk-02-three-justified-cases-vi.svg)
![Bốn nguồn customization không cần thiết: quy trình chưa chuẩ…](/images/insights/customization-erp-rui-ro/erpk-03-four-unnecessary-sources-vi.svg)
![Năm chi phí ẩn của customization quá mức: bảo trì định kỳ, r…](/images/insights/customization-erp-rui-ro/erpk-04-five-hidden-costs-vi.svg)
![Năm câu hỏi trước khi chấp nhận customization: là customizat…](/images/insights/customization-erp-rui-ro/erpk-05-five-decision-questions-vi.svg)
```

## EN — `/images/insights/erp-customization-risks/`

```yaml
cover_image: /images/insights/erp-customization-risks/erpk-00-og-cover-en.png
og_image: /images/insights/erp-customization-risks/erpk-00-og-cover-en.png
cover_alt: "An ERP block in the middle: configuration items inside the software’s scope on the left, dashed customization blocks adding code and technical debt on the right."
```

| # | File | Đặt ở mục |
|---|---|---|
| 1 | `erpk-01-configuration-vs-customization-en.svg` | Customization vs Configuration: Why the Distinction Matters |
| 2 | `erpk-02-three-justified-cases-en.svg` | When Customization Is Justified |
| 3 | `erpk-03-four-unnecessary-sources-en.svg` | When Customization Becomes a Problem |
| 4 | `erpk-04-five-hidden-costs-en.svg` | The Hidden Cost of Over-Customized ERP |
| 5 | `erpk-05-five-decision-questions-en.svg` | A Framework for Making the Customization Decision |

**Alt:**

1. `configuration-vs-customization`: Configuration works within the software’s design with no code changes (approval workflow, currencies and tax rates, product categories, user permissions); customization changes default behavior through code (custom pricing logic, a new data entry screen, integration with an external system).
2. `three-justified-cases`: Three cases where customization is justified: regulatory or compliance requirements, a competitive-advantage process configuration cannot meet, and irreplaceable systems such as production equipment or industry software.
3. `four-unnecessary-sources`: Four sources of unnecessary customization: unstandardized processes, resistance to change, timeline pressure and unanalyzed reporting needs.
4. `five-hidden-costs`: Five hidden costs of over-customized ERP: ongoing maintenance, upgrade risk, knowledge concentration, harder integration and departure from best practice.
5. `five-decision-questions`: Five questions before approving a customization: is it customization or configuration, can the process adapt, what is the true total cost, is the value measurable and who decides.

**Markdown mẫu:**
```md
![Configuration works within the software’s design with no cod…](/images/insights/erp-customization-risks/erpk-01-configuration-vs-customization-en.svg)
![Three cases where customization is justified: regulatory or …](/images/insights/erp-customization-risks/erpk-02-three-justified-cases-en.svg)
![Four sources of unnecessary customization: unstandardized pr…](/images/insights/erp-customization-risks/erpk-03-four-unnecessary-sources-en.svg)
![Five hidden costs of over-customized ERP: ongoing maintenanc…](/images/insights/erp-customization-risks/erpk-04-five-hidden-costs-en.svg)
![Five questions before approving a customization: is it custo…](/images/insights/erp-customization-risks/erpk-05-five-decision-questions-en.svg)
```
