import sys, re
import cairosvg
sys.path.insert(0, '/home/claude/erpf')
from lib import Fig, LIGHT, DARK, tw
import build_erpf as B
from build_erpf import bind, curly, chip, head, make, var_check, two_cols

OUT = '/home/claude/erpm/out'
CHK = '/home/claude/erpm/check'

B.PAIRS += ['scope creep', 'go-live', 'kick-off', 'giai đoạn', 'nhà triển khai', 'ngân sách', 'dự phòng', 'đánh giá', 'tác động', 'quy trình', 'yêu cầu', 'thay đổi', 'nguyên nhân', 'gốc rễ', 'nợ kỹ thuật', 'người có thẩm quyền', 'chi phí', 'rủi ro', 'bảo trì', 'nâng cấp', 'user adoption', 'change management', 'super user', 'người dùng', 'nhân viên', 'chart of accounts', 'số dư đầu kỳ', 'chi phí', 'kế toán', 'phân bổ', 'tài sản', 'tồn kho', 'bút toán', 'routing', 'traceability', 'sản xuất', 'nguyên liệu', 'thành phẩm', 'nhà triển khai']

CONC_VI = 'Sơ đồ minh họa khái niệm từ bài viết, không phải số liệu đo lường.'
CONC_EN = 'Conceptual diagram from the article, not measured data.'

VI = dict(
    mt=62,
    t={1: 'ERP sản xuất khác ở phần giữa mua và giao hàng',
       2: 'Ba vấn đề phổ biến của BOM ở doanh nghiệp sản xuất',
       3: 'BOM và routing cho phép ERP làm gì?',
       4: 'Lot tracking và serial tracking',
       5: 'Ba yêu cầu quản lý chất lượng trong ERP sản xuất',
       6: 'Bốn đặc thù ngành cần cân nhắc',
       7: 'Tự đánh giá manufacturing readiness: bốn nhóm',
       0: 'ERP cho doanh nghiệp sản xuất:\nkhác gì ERP thương mại?'},
    s={1: 'Giá trị đặc thù của ERP sản xuất nằm ở những gì xảy ra trên xưởng.',
       2: 'BOM là nền tảng cho kế hoạch, giá thành và quản lý vật tư.',
       3: 'Khi có cả BOM và routing, ERP mới tính toán và theo dõi được sản xuất.',
       4: 'Cả hai đều cần dữ liệu được nhập nhất quán.',
       5: 'ERP cần hỗ trợ kiểm tra, xử lý sự cố và quản lý hạn sử dụng.',
       6: 'Mỗi ngành có đặc thù mà ERP chuẩn có thể chưa xử lý hết.',
       7: 'Mỗi nhóm kèm một câu hỏi đại diện cho danh sách đầy đủ trong bài.'},
    f={1: 'Sơ đồ minh họa khái niệm từ bài viết, không phải số liệu đo lường.',
       2: 'Phân tích từ bài viết, không phải thống kê.',
       3: 'Sơ đồ minh họa khái niệm từ bài viết, không phải số liệu đo lường.',
       4: 'Sơ đồ minh họa khái niệm từ bài viết, không phải số liệu đo lường.',
       5: 'Phân tích từ bài viết, không phải thống kê.',
       6: 'Phân tích từ bài viết, không phải thống kê.',
       7: 'Câu hỏi tự đánh giá từ bài viết, là công cụ thảo luận định hướng, không phải phương pháp luận được chứng nhận.'},
    l1='Mua nguyên liệu', r1='Giao hàng', m1t='Sản xuất',
    m1=['Chuyển đổi vật liệu thành sản phẩm', 'Theo dõi số lượng và chất lượng từng công đoạn',
        'Hao hụt và tỷ lệ thu hồi', 'Năng lực máy và nhân công', 'Hồ sơ lot/batch'],
    e1='ERP thiếu module sản xuất chỉ quản lý được phần thương mại.',
    c2=[('Chưa từng được tài liệu hóa', 'Công thức và định mức nằm trong đầu người thợ hoặc quản lý.'),
        ('Không chính xác hoặc lỗi thời', 'Sản phẩm đã đổi nhưng BOM không đổi; không rõ phiên bản nào đúng.'),
        ('Nhiều cấp phức tạp', 'Bán thành phẩm cần BOM nhiều cấp, khó dựng và duy trì lần đầu.')],
    e2='Cần BOM bằng văn bản, phản ánh định mức thực tế và có người chịu trách nhiệm cập nhật.',
    bom='BOM', bomd='Nguyên vật liệu, bán thành phẩm, thành phần và số lượng', rtg='Routing', rtgd='Công đoạn, thời gian, máy hoặc work center, nhân công',
    outs=['Tính chi phí sản xuất dự kiến', 'Lập kế hoạch theo năng lực', 'Tạo Production Order', 'Theo dõi tiến độ từng công đoạn'],
    e3='Routing là bước chuẩn bị, không phải việc ERP tự tạo ra trong triển khai.',
    a_t='Lot tracking', a_d='Ghi nhận từng lô nguyên liệu và sản phẩm',
    a_i=['Số lot', 'Ngày sản xuất', 'Hạn sử dụng', 'Nhà cung cấp'],
    b_t='Serial tracking', b_d='Theo dõi từng đơn vị bằng số serial riêng',
    b_i=['Phù hợp sản phẩm giá trị cao', 'Phù hợp bảo hành theo từng đơn vị'],
    e4='Thiếu dữ liệu nhập nhất quán, ERP có tính năng truy xuất nhưng không đủ dữ liệu để dùng.',
    c5=[('Kiểm tra chất lượng tại các điểm kiểm tra', 'Nguyên liệu nhập, bán thành phẩm giữa công đoạn, thành phẩm trước xuất kho.'),
        ('Sự cố và hành động khắc phục', 'Ghi nhận sự cố, phân tích nguyên nhân, theo dõi hành động khắc phục; liên quan đến ISO 9001.'),
        ('Hạn sử dụng và FEFO', 'Với thực phẩm và dược phẩm, xuất hàng hết hạn trước thay vì FIFO thông thường.')],
    e5='ERP cần ghi nhận kết quả kiểm tra, quyết định đạt hoặc không đạt và xử lý hàng lỗi.',
    c6=[('Thực phẩm và thủy sản', 'Hao hụt thay đổi theo nguyên liệu; nhiều đơn vị tính; truy xuất đến vùng nuôi hoặc đánh bắt.'),
        ('Sản xuất theo đơn đặt hàng', 'BOM riêng theo khách hàng; Sales Order gắn chặt Production Order; giá thành theo từng đơn.'),
        ('Sản xuất có mùa vụ', 'Khối lượng biến động lớn; lập kế hoạch năng lực linh hoạt; theo dõi tồn kho theo mùa.'),
        ('Sản xuất trà', 'Phân cấp nguyên liệu ảnh hưởng công thức pha trộn; quản lý recipe; truy xuất vùng trồng.')],
    e6='Nên trao đổi sớm với nhà triển khai về các đặc thù này.',
    c7=[('BOM và routing', 'BOM đã chính xác, cập nhật cho toàn bộ sản phẩm trong phạm vi chưa?'),
        ('Traceability', 'Có yêu cầu lot tracking không, và hiện ghi nhận lot ra sao?'),
        ('Chất lượng', 'Các điểm kiểm tra chất lượng đã được xác định chưa?'),
        ('Đặc thù ngành', 'Đã trao đổi với nhà triển khai về yield, đơn vị tính, quản lý nguyên liệu chưa?')],
    e7='Manufacturing readiness là điều kiện tiên quyết, không giải quyết trong lúc triển khai.',
    kick='OKELAS · Insights · ERP',
    cin='Nguyên liệu', cout='Thành phẩm', cch=['BOM', 'Routing', 'Lot', 'QC'],
    cp='BOM, routing, truy xuất và chất lượng cần được chuẩn bị trước khi triển khai',
)

EN = dict(
    mt=62,
    t={1: 'Manufacturing ERP differs in the middle: buy to ship',
       2: 'Three common BOM problems in manufacturing SMEs',
       3: 'What BOM and routing let ERP do',
       4: 'Lot tracking and serial tracking',
       5: 'Three quality management needs in manufacturing ERP',
       6: 'Four industry-specific considerations',
       7: 'Manufacturing readiness self-assessment: four areas',
       0: 'ERP for Manufacturing Companies:\nKey Differences and Preparation'},
    s={1: 'The distinctive value of manufacturing ERP lies in what happens on the shop floor.',
       2: 'The BOM underpins planning, costing and material management.',
       3: 'Only with both BOM and routing can ERP calculate and track production.',
       4: 'Both depend on data being entered consistently.',
       5: 'ERP must support inspection, incident handling and expiry control.',
       6: 'Each industry has needs standard ERP may not fully handle.',
       7: 'Each area carries one representative question from the full list in the article.'},
    f={1: 'Conceptual diagram from the article, not measured data.',
       2: 'Analysis from the article, not statistics.',
       3: 'Conceptual diagram from the article, not measured data.',
       4: 'Conceptual diagram from the article, not measured data.',
       5: 'Analysis from the article, not statistics.',
       6: 'Analysis from the article, not statistics.',
       7: 'Self-assessment questions from the article, a discussion aid, not a certified methodology.'},
    l1='Procure materials', r1='Ship to customer', m1t='Production',
    m1=['Converting materials into products', 'Tracking quantity and quality at each stage',
        'Yield and loss', 'Machine and labor capacity', 'Lot and batch records'],
    e1='Without a production module, ERP manages only the commercial side.',
    c2=[('Never formally documented', 'Recipes and ratios live in people’s heads.'),
        ('Inaccurate or outdated', 'Products evolved but the BOM did not; no one is sure which version is correct.'),
        ('Multi-level complexity', 'Subassemblies need a multi-level BOM, hard to build and maintain first time.')],
    e2='Needs a written BOM that reflects actual ratios and a named person to maintain it.',
    bom='BOM', bomd='Materials, subassemblies, components and quantities', rtg='Routing', rtgd='Operations, time per step, machines or work centers, labor',
    outs=['Calculate expected production cost', 'Plan against capacity', 'Generate production orders', 'Track progress by operation'],
    e3='Routing is a preparation step, not something ERP creates during implementation.',
    a_t='Lot tracking', a_d='Records each batch of materials and products',
    a_i=['Lot number', 'Production date', 'Expiry date', 'Supplier'],
    b_t='Serial tracking', b_d='Tracks each unit with its own serial number',
    b_i=['Suited to high-value products', 'Suited to unit-level warranty tracking'],
    e4='Without consistent data entry, ERP has traceability features but too little data to use them.',
    c5=[('Quality control at inspection points', 'Incoming material, in-process between stages and finished goods before dispatch.'),
        ('Non-conformance and corrective action', 'Document incidents, analyze root causes and track corrective actions; tied to ISO 9001.'),
        ('Expiry management and FEFO', 'For food and pharma, dispatch earliest expiry first instead of standard FIFO.')],
    e5='ERP must record results, accept or reject decisions and handle non-conforming material.',
    c6=[('Food processing and seafood', 'Variable yield; multiple units of measure; traceability to the farm or fishing zone.'),
        ('Make-to-order', 'Customer-specific BOMs; sales and production orders tightly linked; costing per order.'),
        ('Seasonal manufacturing', 'Large volume swings; flexible capacity planning; careful seasonal inventory tracking.'),
        ('Tea production', 'Input grade affects blending; recipe management; traceability to region and harvest.')],
    e6='Discuss these needs with the implementation partner early.',
    c7=[('BOM and routing', 'Is there an accurate, current BOM for all in-scope products?'),
        ('Traceability', 'Is lot tracking required, and how is lot data recorded today?'),
        ('Quality', 'Have inspection points in the production process been defined?'),
        ('Industry-specific needs', 'Have yield, unit-of-measure and material needs been discussed with the partner?')],
    e7='Manufacturing readiness is a prerequisite, not something to resolve during implementation.',
    kick='OKELAS · Insights · ERP',
    cin='Materials', cout='Finished goods', cch=['BOM', 'Routing', 'Lot', 'QC'],
    cp='BOM, routing, traceability and quality need preparation before implementation',
)

ALT = {
    'vi': {
        1: 'ERP sản xuất khác ở phần giữa mua nguyên liệu và giao hàng: chuyển đổi vật liệu, theo dõi số lượng và chất lượng từng công đoạn, hao hụt, năng lực máy và nhân công, hồ sơ lot/batch.',
        2: 'Ba vấn đề phổ biến của BOM ở doanh nghiệp sản xuất SME: chưa được tài liệu hóa, không chính xác hoặc lỗi thời, và phức tạp do nhiều cấp.',
        3: 'BOM và routing kết hợp cho phép ERP tính chi phí sản xuất dự kiến, lập kế hoạch theo năng lực, tạo Production Order và theo dõi tiến độ từng công đoạn.',
        4: 'Lot tracking ghi nhận số lot, ngày sản xuất, hạn sử dụng và nhà cung cấp; serial tracking theo dõi từng đơn vị bằng số serial riêng cho sản phẩm giá trị cao hoặc bảo hành theo đơn vị.',
        5: 'Ba yêu cầu quản lý chất lượng trong ERP sản xuất: kiểm tra tại các điểm kiểm tra, ghi nhận sự cố và hành động khắc phục, và quản lý hạn sử dụng theo FEFO.',
        6: 'Bốn đặc thù ngành: thực phẩm và thủy sản, sản xuất theo đơn đặt hàng, sản xuất có mùa vụ và sản xuất trà.',
        7: 'Bốn nhóm câu hỏi tự đánh giá manufacturing readiness, mỗi nhóm một câu hỏi đại diện: BOM và routing, traceability, chất lượng và đặc thù ngành.',
        0: 'Nguyên liệu đi vào khối ERP có các chip BOM, Routing, Lot và QC, rồi ra thành phẩm.'},
    'en': {
        1: 'Manufacturing ERP differs in the middle between procuring materials and shipping: converting materials, tracking quantity and quality at each stage, yield and loss, machine and labor capacity and lot and batch records.',
        2: 'Three common BOM problems in manufacturing SMEs: never formally documented, inaccurate or outdated, and multi-level complexity.',
        3: 'Together BOM and routing let ERP calculate expected production cost, plan against capacity, generate production orders and track progress by operation.',
        4: 'Lot tracking records lot number, production date, expiry date and supplier; serial tracking follows each unit with its own serial number for high-value products or unit-level warranty.',
        5: 'Three quality management needs in manufacturing ERP: quality control at inspection points, non-conformance and corrective action, and expiry management with FEFO.',
        6: 'Four industry-specific considerations: food processing and seafood, make-to-order, seasonal manufacturing and tea production.',
        7: 'Four self-assessment areas for manufacturing readiness, each with one representative question: BOM and routing, traceability, quality and industry-specific needs.',
        0: 'Materials enter an ERP block marked with BOM, Routing, Lot and QC chips, and finished goods come out.'},
}

VI = bind(VI)
EN = curly(EN)
LANGS = {'vi': VI, 'en': EN}
NAMES = {1: 'middle-of-the-chain', 2: 'three-bom-problems', 3: 'bom-routing-outputs', 4: 'lot-vs-serial',
         5: 'three-quality-needs', 6: 'four-industry-cases', 7: 'readiness-self-check'}


def numc(f, x, y, n, col='p', r=15):
    f.circle(x, y, r, col)
    f._line(x, y - 10, str(n), 15, 700, 'wh', 'middle', 20)


def cards(f, L, k, key, fill, stroke, n, numbered=False, big=False):
    head(f, L, k)
    items = L[key]
    gap, y = 15, 134
    cw = round((1080 - gap * (n - 1)) / n)
    ts, ds = (18, 14) if big else (16, 13)
    top = 62 if numbered else 20
    need = 0
    for t, d in items:
        need = max(need, top + f.measure(t, ts, 700, cw - 32) + 10 + f.measure(d, ds, 400, cw - 32, 1.42) + 20)
    ch = round(need)
    for i, (t, d) in enumerate(items):
        x = 60 + i * (cw + gap)
        f.rect(x, y, cw, ch, fill, stroke, 16, 1.8)
        if numbered:
            numc(f, x + 32, y + 32, i + 1, stroke)
        th = f.para(x + 16, y + top, t, ts, 700, 'hd', cw - 32)
        f.para(x + 16, y + top + th + 10, d, ds, 400, 'tx', cw - 32, lhr=1.42)
    f.ink(y + ch + 16, L['e%d' % k])


def fig1(f, L):
    head(f, L, 1)
    y0 = 134
    n = len(L['m1'])
    ch_ = 38
    mh = 62 + n * (ch_ + 8) + 8
    mid = y0 + mh / 2
    f.rect(60, mid - 40, 220, 80, 'gt', 'gm', 14, 1.8)
    f.box_text(60, mid - 40, 220, 80, L['l1'], 17, 700, 'hd', 10)
    f.arrow(286, mid, 354, mid, 'gm', 2.5, 10)
    f.rect(360, y0, 480, mh, 'at', 'a', 16, 2.4)
    f._line(384, y0 + 18, L['m1t'], 22, 700, 'hd', 'start', 30)
    for i, t in enumerate(L['m1']):
        chip(f, 384, y0 + 62 + i * (ch_ + 8), 432, ch_, t, 'a', 'bg', 14, 'hd')
    f.arrow(846, mid, 914, mid, 'gm', 2.5, 10)
    f.rect(920, mid - 40, 220, 80, 'gt', 'gm', 14, 1.8)
    f.box_text(920, mid - 40, 220, 80, L['r1'], 17, 700, 'hd', 10)
    f.ink(y0 + mh + 18, L['e1'])


def fig2(f, L): cards(f, L, 2, 'c2', 'at', 'a', 3, numbered=True, big=True)


def fig3(f, L):
    head(f, L, 3)
    y0 = 134
    bh = 100
    for i, (t, d) in enumerate(((L['bom'], L['bomd']), (L['rtg'], L['rtgd']))):
        y = y0 + i * (bh + 16)
        f.rect(60, y, 440, bh, 'pt', 'p', 16, 1.8)
        f._line(84, y + 16, t, 20, 700, 'hd', 'start', 28)
        f.para(84, y + 52, d, 14, 400, 'tx', 392, lhr=1.42)
    mid = y0 + bh + 8
    oh, og = 44, 14
    oy = mid - (4 * oh + 3 * og) / 2
    for i, t in enumerate(L['outs']):
        y = oy + i * (oh + og)
        f.arrow(510, mid, 696, y + oh / 2, 'gm', 2.5, 9)
        f.rect(700, y, 440, oh, 'at', 'a', 12, 1.8)
        f.box_text(700, y, 440, oh, t, 16, 700, 'hd', 10)
    f.ink(y0 + 2 * bh + 16 + 20, L['e3'])


def fig4(f, L):
    head(f, L, 4)
    two_cols(f, L, 4,
             (L['a_t'], L['a_d'], L['a_i'], 'pt', 'p', None, 44),
             (L['b_t'], L['b_d'], L['b_i'], 'at', 'a', '6 5', 62))


def fig5(f, L): cards(f, L, 5, 'c5', 'pt', 'p', 3, numbered=True, big=True)
def fig6(f, L): cards(f, L, 6, 'c6', 'at', 'a', 4, big=True)
def fig7(f, L): cards(f, L, 7, 'c7', 'pt', 'p', 4, big=True)


def figcover(f, L):
    f.rect(0, 0, 1200, 630, 'bg', None, 0)
    f.rect(0, 0, 14, 630, 'p', None, 0)
    f._line(60, 44, L['kick'], 16, 700, 's', 'start', 22)
    f.para(60, 84, L['t'][0], 40, 700, 'hd', 1040, lhr=1.25)
    f.rect(100, 340, 220, 80, 'gt', 'gm', 14, 1.8)
    f.box_text(100, 340, 220, 80, L['cin'], 17, 700, 'hd', 10)
    f.arrow(326, 380, 414, 380, 'gm', 3, 11)
    bx, bw = 420, 360
    f.rect(bx, 320, bw, 120, 'ink', None, 18)
    f._line(bx + bw / 2, 355, 'ERP', 40, 700, 'onink', 'middle', 50)
    f.arrow(786, 380, 874, 380, 'gm', 3, 11)
    f.rect(880, 340, 220, 80, 'gt', 'gm', 14, 1.8)
    f.box_text(880, 340, 220, 80, L['cout'], 17, 700, 'hd', 10)
    cw_, g = 80, 13
    for i, t in enumerate(L['cch']):
        chip(f, bx + i * (cw_ + g), 456, cw_, 40, t, 'a', 'at', 14, 'hd')
    f.para(bx, 520, L['cp'], 15, 700, 's', 360)
    f.mark(H_COVER - 30)


H_COVER = 630
FIGS = {1: fig1, 2: fig2, 3: fig3, 4: fig4, 5: fig5, 6: fig6, 7: fig7}


def build(sel=None):
    for lang, L in LANGS.items():
        for k in list(FIGS) + [0]:
            if sel and k not in sel:
                continue
            label = ALT[lang][k]
            fn = figcover if k == 0 else FIGS[k]
            name = f'erpm-00-og-cover-{lang}' if k == 0 else f'erpm-{k:02d}-{NAMES[k]}-{lang}'
            if k == 0:
                s = Fig(H_COVER, 'svg', False, label); fn(s, L)
                p = Fig(H_COVER, 'png', False, label); fn(p, L)
                d = Fig(H_COVER, 'png', True, label); fn(d, L)
                H = H_COVER
            else:
                s = make(fn, L, label, 'svg')
                H = s.H
                p = make(fn, L, label, 'png', False, H)
                d = make(fn, L, label, 'png', True, H)
            svg = s.svg()
            assert var_check(svg, p.svg()), 'adaptive vs light mismatch ' + name
            open(f'{OUT}/{lang}/{name}.svg', 'w', encoding='utf-8').write(svg)
            if k == 0:
                cairosvg.svg2png(bytestring=p.svg().encode('utf-8'), write_to=f'{OUT}/{lang}/{name}.png', output_width=1200)
            cairosvg.svg2png(bytestring=p.svg().encode('utf-8'), write_to=f'{CHK}/{name}-light.png', output_width=1200)
            cairosvg.svg2png(bytestring=d.svg().encode('utf-8'), write_to=f'{CHK}/{name}-dark.png', output_width=1200)
            print('ok', name, 'H', H)


if __name__ == '__main__':
    build([int(a) for a in sys.argv[1:]] or None)
