# Manifest hình bài ERP cho doanh nghiệp sản xuất (VI + EN)

Tiền tố cụm: `erpm`. Cover PNG 1200×630; hình thường SVG (inline có dark mode; dùng `<img>` thì cần xuất PNG light).

## VI — `/images/insights/erp-cho-doanh-nghiep-san-xuat/`

```yaml
cover_image: /images/insights/erp-cho-doanh-nghiep-san-xuat/erpm-00-og-cover-vi.png
og_image: /images/insights/erp-cho-doanh-nghiep-san-xuat/erpm-00-og-cover-vi.png
cover_alt: "Nguyên liệu đi vào khối ERP có các chip BOM, Routing, Lot và QC, rồi ra thành phẩm."
```

| # | File | Đặt ở mục |
|---|---|---|
| 1 | `erpm-01-middle-of-the-chain-vi.svg` | Tại sao ERP cho sản xuất khác với ERP thương mại? |
| 2 | `erpm-02-three-bom-problems-vi.svg` | Bill of Materials (BOM) — nền tảng của mọi thứ |
| 3 | `erpm-03-bom-routing-outputs-vi.svg` | Routing và Production Order — quản lý quy trình sản xuất |
| 4 | `erpm-04-lot-vs-serial-vi.svg` | Traceability (lot tracking và serial tracking) |
| 5 | `erpm-05-three-quality-needs-vi.svg` | Quản lý chất lượng trong ERP sản xuất |
| 6 | `erpm-06-four-industry-cases-vi.svg` | Các đặc thù ngành cụ thể mà manufacturing SME cần cân nhắc |
| 7 | `erpm-07-readiness-self-check-vi.svg` | Tự đánh giá manufacturing readiness |

**Alt:**

1. `middle-of-the-chain`: ERP sản xuất khác ở phần giữa mua nguyên liệu và giao hàng: chuyển đổi vật liệu, theo dõi số lượng và chất lượng từng công đoạn, hao hụt, năng lực máy và nhân công, hồ sơ lot/batch.
2. `three-bom-problems`: Ba vấn đề phổ biến của BOM ở doanh nghiệp sản xuất SME: chưa được tài liệu hóa, không chính xác hoặc lỗi thời, và phức tạp do nhiều cấp.
3. `bom-routing-outputs`: BOM và routing kết hợp cho phép ERP tính chi phí sản xuất dự kiến, lập kế hoạch theo năng lực, tạo Production Order và theo dõi tiến độ từng công đoạn.
4. `lot-vs-serial`: Lot tracking ghi nhận số lot, ngày sản xuất, hạn sử dụng và nhà cung cấp; serial tracking theo dõi từng đơn vị bằng số serial riêng cho sản phẩm giá trị cao hoặc bảo hành theo đơn vị.
5. `three-quality-needs`: Ba yêu cầu quản lý chất lượng trong ERP sản xuất: kiểm tra tại các điểm kiểm tra, ghi nhận sự cố và hành động khắc phục, và quản lý hạn sử dụng theo FEFO.
6. `four-industry-cases`: Bốn đặc thù ngành: thực phẩm và thủy sản, sản xuất theo đơn đặt hàng, sản xuất có mùa vụ và sản xuất trà.
7. `readiness-self-check`: Bốn nhóm câu hỏi tự đánh giá manufacturing readiness, mỗi nhóm một câu hỏi đại diện: BOM và routing, traceability, chất lượng và đặc thù ngành.

**Markdown mẫu:**
```md
![ERP sản xuất khác ở phần giữa mua nguyên liệu và giao hàng: …](/images/insights/erp-cho-doanh-nghiep-san-xuat/erpm-01-middle-of-the-chain-vi.svg)
![Ba vấn đề phổ biến của BOM ở doanh nghiệp sản xuất SME: chưa…](/images/insights/erp-cho-doanh-nghiep-san-xuat/erpm-02-three-bom-problems-vi.svg)
![BOM và routing kết hợp cho phép ERP tính chi phí sản xuất dự…](/images/insights/erp-cho-doanh-nghiep-san-xuat/erpm-03-bom-routing-outputs-vi.svg)
![Lot tracking ghi nhận số lot, ngày sản xuất, hạn sử dụng và …](/images/insights/erp-cho-doanh-nghiep-san-xuat/erpm-04-lot-vs-serial-vi.svg)
![Ba yêu cầu quản lý chất lượng trong ERP sản xuất: kiểm tra t…](/images/insights/erp-cho-doanh-nghiep-san-xuat/erpm-05-three-quality-needs-vi.svg)
![Bốn đặc thù ngành: thực phẩm và thủy sản, sản xuất theo đơn …](/images/insights/erp-cho-doanh-nghiep-san-xuat/erpm-06-four-industry-cases-vi.svg)
![Bốn nhóm câu hỏi tự đánh giá manufacturing readiness, mỗi nh…](/images/insights/erp-cho-doanh-nghiep-san-xuat/erpm-07-readiness-self-check-vi.svg)
```

## EN — `/images/insights/erp-for-manufacturing-companies/`

```yaml
cover_image: /images/insights/erp-for-manufacturing-companies/erpm-00-og-cover-en.png
og_image: /images/insights/erp-for-manufacturing-companies/erpm-00-og-cover-en.png
cover_alt: "Materials enter an ERP block marked with BOM, Routing, Lot and QC chips, and finished goods come out."
```

| # | File | Đặt ở mục |
|---|---|---|
| 1 | `erpm-01-middle-of-the-chain-en.svg` | Why Manufacturing ERP Is Different |
| 2 | `erpm-02-three-bom-problems-en.svg` | Bill of Materials (BOM): The Foundation of Manufacturing ERP |
| 3 | `erpm-03-bom-routing-outputs-en.svg` | Routing and Production Orders: Managing the Production Process |
| 4 | `erpm-04-lot-vs-serial-en.svg` | Traceability (lot tracking and serial tracking) |
| 5 | `erpm-05-three-quality-needs-en.svg` | Quality Management in Manufacturing ERP |
| 6 | `erpm-06-four-industry-cases-en.svg` | Industry-Specific Considerations for Manufacturing SMEs |
| 7 | `erpm-07-readiness-self-check-en.svg` | Manufacturing Readiness Self-Assessment |

**Alt:**

1. `middle-of-the-chain`: Manufacturing ERP differs in the middle between procuring materials and shipping: converting materials, tracking quantity and quality at each stage, yield and loss, machine and labor capacity and lot and batch records.
2. `three-bom-problems`: Three common BOM problems in manufacturing SMEs: never formally documented, inaccurate or outdated, and multi-level complexity.
3. `bom-routing-outputs`: Together BOM and routing let ERP calculate expected production cost, plan against capacity, generate production orders and track progress by operation.
4. `lot-vs-serial`: Lot tracking records lot number, production date, expiry date and supplier; serial tracking follows each unit with its own serial number for high-value products or unit-level warranty.
5. `three-quality-needs`: Three quality management needs in manufacturing ERP: quality control at inspection points, non-conformance and corrective action, and expiry management with FEFO.
6. `four-industry-cases`: Four industry-specific considerations: food processing and seafood, make-to-order, seasonal manufacturing and tea production.
7. `readiness-self-check`: Four self-assessment areas for manufacturing readiness, each with one representative question: BOM and routing, traceability, quality and industry-specific needs.

**Markdown mẫu:**
```md
![Manufacturing ERP differs in the middle between procuring ma…](/images/insights/erp-for-manufacturing-companies/erpm-01-middle-of-the-chain-en.svg)
![Three common BOM problems in manufacturing SMEs: never forma…](/images/insights/erp-for-manufacturing-companies/erpm-02-three-bom-problems-en.svg)
![Together BOM and routing let ERP calculate expected producti…](/images/insights/erp-for-manufacturing-companies/erpm-03-bom-routing-outputs-en.svg)
![Lot tracking records lot number, production date, expiry dat…](/images/insights/erp-for-manufacturing-companies/erpm-04-lot-vs-serial-en.svg)
![Three quality management needs in manufacturing ERP: quality…](/images/insights/erp-for-manufacturing-companies/erpm-05-three-quality-needs-en.svg)
![Four industry-specific considerations: food processing and s…](/images/insights/erp-for-manufacturing-companies/erpm-06-four-industry-cases-en.svg)
![Four self-assessment areas for manufacturing readiness, each…](/images/insights/erp-for-manufacturing-companies/erpm-07-readiness-self-check-en.svg)
```
