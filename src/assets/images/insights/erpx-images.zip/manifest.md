# Manifest hình bài ERP và Excel (VI + EN)

Tiền tố cụm: `erpx`. Cover PNG 1200×630; hình thường SVG (inline có dark mode; dùng `<img>` thì cần xuất PNG light).

## VI — `/images/insights/co-erp-van-dung-excel/`

```yaml
cover_image: /images/insights/co-erp-van-dung-excel/erpx-00-og-cover-vi.png
og_image: /images/insights/co-erp-van-dung-excel/erpx-00-og-cover-vi.png
cover_alt: "Một khối ERP được đánh dấu đã cài, đặt cạnh một lưới bảng tính nét đứt là nơi công việc thực tế đang chạy."
```

| # | File | Đặt ở mục |
|---|---|---|
| 1 | `erpx-01-installed-vs-adopted-vi.svg` | ERP được cài không có nghĩa là được dùng |
| 2 | `erpx-02-three-reasons-vi.svg` | Ba nguyên nhân phổ biến nhất (đầu mục) |
| 3 | `erpx-03-data-trust-loop-vi.svg` | Ba nguyên nhân phổ biến nhất (vòng lặp dữ liệu, nguyên nhân thứ 3) |
| 4 | `erpx-04-symptom-or-cause-vi.svg` | Đây là triệu chứng hay nguyên nhân? |
| 5 | `erpx-05-two-points-before-acting-vi.svg` | Bước tiếp theo |

**Alt:**

1. `installed-vs-adopted`: Đã cài đặt nghĩa là phần mềm chạy, nhập được dữ liệu và tạo được báo cáo; đã được áp dụng nghĩa là hệ thống phản ánh đúng cách doanh nghiệp vận hành, và khoảng cách giữa hai trạng thái thường lớn hơn trạng thái dự án hoàn thành cho thấy.
2. `three-reasons`: Ba nguyên nhân phổ biến khiến nhân viên quay lại Excel: cấu hình không khớp quy trình thực tế, thiếu lý do cá nhân để thay đổi và dữ liệu ERP không đáng tin.
3. `data-trust-loop`: Vòng lặp dữ liệu không đáng tin: nhập thiếu hoặc sai, dữ liệu ERP không chính xác, người khác không tin và lập file Excel riêng, rồi ERP càng ít dữ liệu đúng.
4. `symptom-or-cause`: Excel đang thay thế phần nào của ERP gợi ý vấn đề ở đâu: làm việc kho gợi ý cấu hình hoặc quy trình nhập kho, làm báo cáo tài chính gợi ý dữ liệu chưa đáng tin, lưu thông tin ngoài hệ thống gợi ý phạm vi ERP chưa đủ.
5. `two-points-before-acting`: Hai điều cần cân nhắc trước khi hành động: chẩn đoán trước khi kê đơn, và xem xét cả hệ thống lẫn tổ chức.

**Markdown mẫu:**
```md
![Đã cài đặt nghĩa là phần mềm chạy, nhập được dữ liệu và tạo …](/images/insights/co-erp-van-dung-excel/erpx-01-installed-vs-adopted-vi.svg)
![Ba nguyên nhân phổ biến khiến nhân viên quay lại Excel: cấu …](/images/insights/co-erp-van-dung-excel/erpx-02-three-reasons-vi.svg)
![Vòng lặp dữ liệu không đáng tin: nhập thiếu hoặc sai, dữ liệ…](/images/insights/co-erp-van-dung-excel/erpx-03-data-trust-loop-vi.svg)
![Excel đang thay thế phần nào của ERP gợi ý vấn đề ở đâu: làm…](/images/insights/co-erp-van-dung-excel/erpx-04-symptom-or-cause-vi.svg)
![Hai điều cần cân nhắc trước khi hành động: chẩn đoán trước k…](/images/insights/co-erp-van-dung-excel/erpx-05-two-points-before-acting-vi.svg)
```

## EN — `/images/insights/erp-still-using-excel/`

```yaml
cover_image: /images/insights/erp-still-using-excel/erpx-00-og-cover-en.png
og_image: /images/insights/erp-still-using-excel/erpx-00-og-cover-en.png
cover_alt: "An ERP block marked installed beside a dashed spreadsheet grid where real work actually runs."
```

| # | File | Đặt ở mục |
|---|---|---|
| 1 | `erpx-01-installed-vs-adopted-en.svg` | Installed Is Not the Same as Adopted |
| 2 | `erpx-02-three-reasons-en.svg` | Three Reasons ERP Does Not Stick (start of section) |
| 3 | `erpx-03-data-trust-loop-en.svg` | Three Reasons ERP Does Not Stick (unreliable data loop, reason 3) |
| 4 | `erpx-04-symptom-or-cause-en.svg` | Is This a Symptom or a Cause? |
| 5 | `erpx-05-two-points-before-acting-en.svg` | What to Do Next |

**Alt:**

1. `installed-vs-adopted`: Installed means the software runs, data can be entered and reports generated; adopted means the system reflects how the organization actually operates, and the gap is usually wider than a completed project status implies.
2. `three-reasons`: Three reasons your team goes back to Excel: configuration mismatch, no personal incentive and unreliable data.
3. `data-trust-loop`: The unreliable data loop: incorrect entries, inaccurate ERP data, users who stop trusting it and keep spreadsheets, and then less accurate data entered.
4. `symptom-or-cause`: What Excel is replacing hints at the problem: inventory work suggests configuration or the inbound process, financial reporting suggests unreliable data, and information stored outside suggests ERP scope gaps.
5. `two-points-before-acting`: Two points to consider before acting: diagnose before prescribing, and examine both system and organization.

**Markdown mẫu:**
```md
![Installed means the software runs, data can be entered and r…](/images/insights/erp-still-using-excel/erpx-01-installed-vs-adopted-en.svg)
![Three reasons your team goes back to Excel: configuration mi…](/images/insights/erp-still-using-excel/erpx-02-three-reasons-en.svg)
![The unreliable data loop: incorrect entries, inaccurate ERP …](/images/insights/erp-still-using-excel/erpx-03-data-trust-loop-en.svg)
![What Excel is replacing hints at the problem: inventory work…](/images/insights/erp-still-using-excel/erpx-04-symptom-or-cause-en.svg)
![Two points to consider before acting: diagnose before prescr…](/images/insights/erp-still-using-excel/erpx-05-two-points-before-acting-en.svg)
```
