import sys, re
import cairosvg
sys.path.insert(0, '/home/claude/erpf')
from lib import Fig, LIGHT, DARK, tw
import build_erpf as B
from build_erpf import bind, curly, chip, head, make, var_check, two_cols

OUT = '/home/claude/erpx/out'
CHK = '/home/claude/erpx/check'

B.PAIRS += ['scope creep', 'go-live', 'kick-off', 'giai đoạn', 'nhà triển khai', 'ngân sách', 'dự phòng', 'đánh giá', 'tác động', 'quy trình', 'yêu cầu', 'thay đổi', 'nguyên nhân', 'gốc rễ', 'nợ kỹ thuật', 'người có thẩm quyền', 'chi phí', 'rủi ro', 'bảo trì', 'nâng cấp', 'user adoption', 'change management', 'super user', 'người dùng', 'nhân viên', 'chart of accounts', 'số dư đầu kỳ', 'chi phí', 'kế toán', 'phân bổ', 'tài sản', 'tồn kho', 'bút toán', 'routing', 'traceability', 'sản xuất', 'nguyên liệu', 'thành phẩm', 'nhà triển khai', 'bảng tính', 'nguyên nhân', 'dữ liệu', 'cấu hình']

CONC_VI = 'Sơ đồ minh họa khái niệm từ bài viết, không phải số liệu đo lường.'
CONC_EN = 'Conceptual diagram from the article, not measured data.'

VI = dict(
    mt=62,
    t={1: 'Đã cài đặt không có nghĩa là đã được áp dụng',
       2: 'Ba nguyên nhân phổ biến khiến nhân viên quay lại Excel',
       3: 'Vòng lặp dữ liệu không đáng tin',
       4: 'Triệu chứng hay nguyên nhân? Excel đang thay thế gì?',
       5: 'Hai điều cần cân nhắc trước khi hành động',
       0: 'Doanh nghiệp đã có ERP\nnhưng vẫn chạy bằng Excel: tại sao?'},
    s={1: 'Phần mềm chạy được chưa chắc phản ánh đúng cách doanh nghiệp vận hành.',
       2: 'Excel linh hoạt hơn nên có giá trị ngay khi người dùng chịu áp lực vận hành.',
       3: 'Vòng lặp tự củng cố, không tự mất đi nếu không can thiệp.',
       4: 'Phần ERP bị Excel thay thế gợi ý vấn đề nằm ở đâu.',
       5: 'Nên tìm hiểu nguyên nhân trước khi chọn giải pháp.'},
    f={1: 'Sơ đồ minh họa khái niệm từ bài viết, không phải số liệu đo lường.',
       2: 'Phân tích từ bài viết, không phải thống kê.',
       3: 'Sơ đồ minh họa khái niệm từ bài viết, không phải số liệu đo lường.',
       4: 'Các giả thuyết chẩn đoán từ bài viết, không phải kết luận cho mọi doanh nghiệp.',
       5: 'Phân tích từ bài viết, không phải thống kê.'},
    a_t='Đã cài đặt', a_d='Trạng thái kỹ thuật của phần mềm',
    a_i=['Phần mềm chạy được', 'Nhập được dữ liệu', 'Tạo được báo cáo'],
    b_t='Đã được áp dụng', b_d='Trạng thái vận hành thật của doanh nghiệp',
    b_i=['Hệ thống phản ánh đúng cách doanh nghiệp vận hành',
         'Không chỉ là nơi dữ liệu đổ vào sau khi việc thật đã làm ở nơi khác'],
    e1='Khoảng cách giữa hai trạng thái thường lớn hơn mức “dự án hoàn thành” cho thấy.',
    c2=[('Cấu hình không khớp quy trình thực tế', 'Excel chấp nhận ngoại lệ, không bắt phê duyệt nhiều bước và không báo lỗi khi thiếu dữ liệu.'),
        ('Thiếu lý do cá nhân để thay đổi', 'ERP làm việc phức tạp hơn, không có lợi ích rõ ràng và không ai yêu cầu dùng đúng.'),
        ('Dữ liệu ERP không đáng tin', 'Người dùng không tin dữ liệu nên lập file Excel riêng.')],
    e2='Thiếu lý do thay đổi và dữ liệu không đáng tin đều dẫn người dùng về cách làm cũ.',
    lp=['Nhập thiếu hoặc sai', 'Dữ liệu ERP không chính xác', 'Người khác không tin, lập file Excel riêng', 'ERP càng ít dữ liệu đúng'],
    lpl='Vòng lặp tự củng cố',
    e3='Không can thiệp, ERP sống song song với một hệ thống bảng tính không chính thức.',
    rows=[('Excel đang làm việc của module kho', 'Cấu hình kho hoặc quy trình nhập kho có thể chưa phù hợp'),
          ('Excel đang làm báo cáo tài chính', 'Dữ liệu ERP có thể chưa đủ tin cậy để ra quyết định'),
          ('Excel đang lưu thông tin hệ thống không có chỗ nhập', 'Phạm vi ERP có thể chưa bao phủ đủ nghiệp vụ')],
    e4='Chẩn đoán trước khi chọn giải pháp.',
    c5=[('Chẩn đoán trước khi kê đơn', 'Tái triển khai, đổi phần mềm hoặc ép dùng hệ thống mà không xử lý nguyên nhân gốc thường chỉ tạo thêm xung đột.'),
        ('Xem xét cả hệ thống lẫn tổ chức', 'Cấu hình không khớp là vấn đề hệ thống; không thấy lý do đổi là vấn đề tổ chức; thường cả hai cùng tồn tại.')],
    e5='Hiểu nguyên nhân trước, rồi mới chọn giải pháp.',
    kick='OKELAS · Insights · ERP',
    pl='Đã cài', pr='Đang dùng thực tế',
    cl='Phần mềm đã được cài đặt', cr='Công việc thực tế chạy trên bảng tính, email, Word',
)

EN = dict(
    mt=62,
    t={1: 'Installed is not the same as adopted',
       2: 'Three reasons your team goes back to Excel',
       3: 'The unreliable data loop',
       4: 'Symptom or cause? What is Excel replacing?',
       5: 'Two points to consider before acting',
       0: 'You Have ERP, But Your Team\nStill Runs on Excel'},
    s={1: 'Software that runs does not necessarily reflect how the organization operates.',
       2: 'Excel is more flexible, which has immediate value under operational pressure.',
       3: 'A self-reinforcing loop that does not fade without intervention.',
       4: 'The part of ERP that Excel replaces hints at where the problem lies.',
       5: 'Diagnose the cause before choosing a solution.'},
    f={1: 'Conceptual diagram from the article, not measured data.',
       2: 'Analysis from the article, not statistics.',
       3: 'Conceptual diagram from the article, not measured data.',
       4: 'Diagnostic hypotheses from the article, not conclusions for every company.',
       5: 'Analysis from the article, not statistics.'},
    a_t='Installed', a_d='The technical state of the software',
    a_i=['The software runs', 'Data can be entered', 'Reports can be generated'],
    b_t='Adopted', b_d='The operational state of the organization',
    b_i=['The system reflects how the organization actually operates',
         'Not just where data lands after the real work is done elsewhere'],
    e1='The gap is usually wider than a “successfully completed” status implies.',
    c2=[('Configuration mismatch', 'Spreadsheets accept exceptions, skip approval steps and do not flag incomplete data.'),
        ('No personal incentive', 'ERP adds work with no visible gain, and no one requires correct use.'),
        ('Unreliable data', 'Users do not trust the data, so they keep their own spreadsheets.')],
    e2='No reason to change and unreliable data both send users back to old habits.',
    lp=['Incorrect entries', 'ERP data becomes inaccurate', 'Users stop trusting it and keep spreadsheets', 'Less accurate data gets entered'],
    lpl='A self-reinforcing loop',
    e3='Without intervention, ERP coexists with an unofficial spreadsheet system.',
    rows=[('Excel is doing inventory work', 'The module may be misconfigured or the inbound process may not fit'),
          ('Excel is doing financial reporting', 'ERP data may not be reliable enough for decisions'),
          ('Excel stores information ERP has no place for', 'ERP scope may not cover the real operation')],
    e4='Diagnose before choosing a solution.',
    c5=[('Diagnose before prescribing', 'Re-implementing, switching software or mandating use without fixing the root cause tends to create friction.'),
        ('Examine both system and organization', 'A process mismatch is a system problem; no reason to change is an organizational one; usually both exist together.')],
    e5='Understand the cause first, then choose the solution.',
    kick='OKELAS · Insights · ERP',
    pl='Installed', pr='Used in practice',
    cl='The software has been installed', cr='Real work runs on spreadsheets, email and Word',
)

ALT = {
    'vi': {
        1: 'Đã cài đặt nghĩa là phần mềm chạy, nhập được dữ liệu và tạo được báo cáo; đã được áp dụng nghĩa là hệ thống phản ánh đúng cách doanh nghiệp vận hành, và khoảng cách giữa hai trạng thái thường lớn hơn trạng thái dự án hoàn thành cho thấy.',
        2: 'Ba nguyên nhân phổ biến khiến nhân viên quay lại Excel: cấu hình không khớp quy trình thực tế, thiếu lý do cá nhân để thay đổi và dữ liệu ERP không đáng tin.',
        3: 'Vòng lặp dữ liệu không đáng tin: nhập thiếu hoặc sai, dữ liệu ERP không chính xác, người khác không tin và lập file Excel riêng, rồi ERP càng ít dữ liệu đúng.',
        4: 'Excel đang thay thế phần nào của ERP gợi ý vấn đề ở đâu: làm việc kho gợi ý cấu hình hoặc quy trình nhập kho, làm báo cáo tài chính gợi ý dữ liệu chưa đáng tin, lưu thông tin ngoài hệ thống gợi ý phạm vi ERP chưa đủ.',
        5: 'Hai điều cần cân nhắc trước khi hành động: chẩn đoán trước khi kê đơn, và xem xét cả hệ thống lẫn tổ chức.',
        0: 'Một khối ERP được đánh dấu đã cài, đặt cạnh một lưới bảng tính nét đứt là nơi công việc thực tế đang chạy.'},
    'en': {
        1: 'Installed means the software runs, data can be entered and reports generated; adopted means the system reflects how the organization actually operates, and the gap is usually wider than a completed project status implies.',
        2: 'Three reasons your team goes back to Excel: configuration mismatch, no personal incentive and unreliable data.',
        3: 'The unreliable data loop: incorrect entries, inaccurate ERP data, users who stop trusting it and keep spreadsheets, and then less accurate data entered.',
        4: 'What Excel is replacing hints at the problem: inventory work suggests configuration or the inbound process, financial reporting suggests unreliable data, and information stored outside suggests ERP scope gaps.',
        5: 'Two points to consider before acting: diagnose before prescribing, and examine both system and organization.',
        0: 'An ERP block marked installed beside a dashed spreadsheet grid where real work actually runs.'},
}

VI = bind(VI)
EN = curly(EN)
LANGS = {'vi': VI, 'en': EN}
NAMES = {1: 'installed-vs-adopted', 2: 'three-reasons', 3: 'data-trust-loop', 4: 'symptom-or-cause', 5: 'two-points-before-acting'}


def numc(f, x, y, n, col='p', r=15):
    f.circle(x, y, r, col)
    f._line(x, y - 10, str(n), 15, 700, 'wh', 'middle', 20)


def cards(f, L, k, key, fill, stroke, n, numbered=False, big=False):
    head(f, L, k)
    items = L[key]
    gap, y = 15, 134
    cw = round((1080 - gap * (n - 1)) / n)
    ts, ds = (18, 14) if big else (16, 13)
    top = 62 if numbered else 20
    need = 0
    for t, d in items:
        need = max(need, top + f.measure(t, ts, 700, cw - 32) + 10 + f.measure(d, ds, 400, cw - 32, 1.42) + 20)
    ch = round(need)
    for i, (t, d) in enumerate(items):
        x = 60 + i * (cw + gap)
        f.rect(x, y, cw, ch, fill, stroke, 16, 1.8)
        if numbered:
            numc(f, x + 32, y + 32, i + 1, stroke)
        th = f.para(x + 16, y + top, t, ts, 700, 'hd', cw - 32)
        f.para(x + 16, y + top + th + 10, d, ds, 400, 'tx', cw - 32, lhr=1.42)
    f.ink(y + ch + 16, L['e%d' % k])


def fig1(f, L):
    head(f, L, 1)
    two_cols(f, L, 1,
             (L['a_t'], L['a_d'], L['a_i'], 'gt', 'gm', '6 5', 62),
             (L['b_t'], L['b_d'], L['b_i'], 'pt', 'p', None, 62))


def fig2(f, L): cards(f, L, 2, 'c2', 'at', 'a', 3, numbered=True, big=True)


def fig3(f, L):
    head(f, L, 3)
    y0, bw, gap, bh = 150, 240, 40, 104
    for i, t in enumerate(L['lp']):
        x = 60 + i * (bw + gap)
        last = i == 3
        f.rect(x, y0, bw, bh, 'at' if i >= 2 else 'pt', 'a' if i >= 2 else 'p', 16, 1.8)
        numc(f, x + 28, y0 + 28, i + 1, 'a' if i >= 2 else 'p', 13)
        f.para(x + 48, y0 + 14, t, 16, 700, 'hd', bw - 64) if False else None
        th = f.measure(t, 16, 700, bw - 32)
        f.para(x + 16, y0 + 52 + (bh - 52 - th) / 2 - 6, t, 16, 700, 'hd', bw - 32)
        if i < 3:
            f.arrow(x + bw + 6, y0 + bh / 2, x + bw + gap - 6, y0 + bh / 2, 'gm', 2.5, 9)
    ry = y0 + bh + 44
    x4, x1 = 60 + 3 * (bw + gap) + bw / 2, 60 + bw / 2
    f.line(x4, y0 + bh, x4, ry, 'a', 2.5)
    f.line(x4, ry, x1, ry, 'a', 2.5)
    f.arrow(x1, ry, x1, y0 + bh + 8, 'a', 2.5, 10)
    f.pill(600 - 90, ry - 12, L['lpl'], 'a', 'bg', 13, 'start', 24, 12)
    f.ink(ry + 28, L['e3'])


def fig4(f, L):
    head(f, L, 4)
    y0, rh, gy = 134, 84, 14
    for i, (a, b) in enumerate(L['rows']):
        y = y0 + i * (rh + gy)
        f.rect(60, y, 470, rh, 'at', 'a', 14, 1.8, '6 5')
        f.box_text(60, y, 470, rh, a, 16, 700, 'hd', 16)
        f.arrow(540, y + rh / 2, 596, y + rh / 2, 'gm', 2.5, 10)
        f.rect(602, y, 538, rh, 'pt', 'p', 14, 1.8)
        f.box_text(602, y, 538, rh, b, 15, 400, 'tx', 18)
    f.ink(y0 + 3 * rh + 2 * gy + 18, L['e4'])


def fig5(f, L): cards(f, L, 5, 'c5', 'pt', 'p', 2, numbered=True, big=True)


def figcover(f, L):
    f.rect(0, 0, 1200, 630, 'bg', None, 0)
    f.rect(0, 0, 14, 630, 'p', None, 0)
    f._line(60, 44, L['kick'], 16, 700, 's', 'start', 22)
    f.para(60, 84, L['t'][0], 40, 700, 'hd', 1040, lhr=1.25)
    f.pill(120, 290, L['pl'], 'p', 'pt', 14, 'start', 28, 14)
    f.rect(120, 330, 300, 160, 'ink', None, 18)
    f._line(270, 385, 'ERP', 40, 700, 'onink', 'middle', 50)
    f._line(520, 380, '≠', 56, 700, 'mut', 'middle', 70)
    f.pill(650, 290, L['pr'], 'a', 'at', 14, 'start', 28, 14)
    cw_, ch_, g = 96, 44, 12
    for r in range(3):
        for c in range(4):
            f.rect(650 + c * (cw_ + g), 330 + r * (ch_ + g), cw_, ch_, 'at', 'a', 8, 2, '6 5')
    f.para(120, 520, L['cl'], 15, 700, 's', 330)
    f.para(650, 520, L['cr'], 15, 700, 'a', 450)
    f.mark(H_COVER - 30)


H_COVER = 630
FIGS = {1: fig1, 2: fig2, 3: fig3, 4: fig4, 5: fig5}


def build(sel=None):
    for lang, L in LANGS.items():
        for k in list(FIGS) + [0]:
            if sel and k not in sel:
                continue
            label = ALT[lang][k]
            fn = figcover if k == 0 else FIGS[k]
            name = f'erpx-00-og-cover-{lang}' if k == 0 else f'erpx-{k:02d}-{NAMES[k]}-{lang}'
            if k == 0:
                s = Fig(H_COVER, 'svg', False, label); fn(s, L)
                p = Fig(H_COVER, 'png', False, label); fn(p, L)
                d = Fig(H_COVER, 'png', True, label); fn(d, L)
                H = H_COVER
            else:
                s = make(fn, L, label, 'svg')
                H = s.H
                p = make(fn, L, label, 'png', False, H)
                d = make(fn, L, label, 'png', True, H)
            svg = s.svg()
            assert var_check(svg, p.svg()), 'adaptive vs light mismatch ' + name
            open(f'{OUT}/{lang}/{name}.svg', 'w', encoding='utf-8').write(svg)
            if k == 0:
                cairosvg.svg2png(bytestring=p.svg().encode('utf-8'), write_to=f'{OUT}/{lang}/{name}.png', output_width=1200)
            cairosvg.svg2png(bytestring=p.svg().encode('utf-8'), write_to=f'{CHK}/{name}-light.png', output_width=1200)
            cairosvg.svg2png(bytestring=d.svg().encode('utf-8'), write_to=f'{CHK}/{name}-dark.png', output_width=1200)
            print('ok', name, 'H', H)


if __name__ == '__main__':
    build([int(a) for a in sys.argv[1:]] or None)
