import sys, re
import cairosvg
sys.path.insert(0, '/home/claude/erpf')
from lib import Fig, LIGHT, DARK, tw
import build_erpf as B
from build_erpf import bind, curly, chip, head, make, var_check, two_cols

OUT = '/home/claude/erpg/out'
CHK = '/home/claude/erpg/check'

B.PAIRS += ['scope creep', 'go-live', 'kick-off', 'giai đoạn', 'nhà triển khai', 'ngân sách', 'dự phòng', 'đánh giá', 'tác động', 'quy trình', 'yêu cầu', 'thay đổi', 'nguyên nhân', 'gốc rễ', 'nợ kỹ thuật', 'người có thẩm quyền', 'chi phí', 'rủi ro', 'bảo trì', 'nâng cấp', 'user adoption', 'change management', 'super user', 'người dùng', 'nhân viên', 'chart of accounts', 'số dư đầu kỳ', 'chi phí', 'kế toán', 'phân bổ', 'tài sản', 'tồn kho', 'bút toán', 'routing', 'traceability', 'sản xuất', 'nguyên liệu', 'thành phẩm', 'nhà triển khai', 'bảng tính', 'nguyên nhân', 'dữ liệu', 'cấu hình', 'master data', 'vai trò', 'quyết định', 'chịu trách nhiệm']

CONC_VI = 'Sơ đồ minh họa khái niệm từ bài viết, không phải số liệu đo lường.'
CONC_EN = 'Conceptual diagram from the article, not measured data.'

VI = dict(
    mt=62,
    t={1: 'ERP không tự vận hành sau go-live',
       2: 'Năm dấu hiệu thiếu ERP governance',
       3: 'Bốn vai trò cần có sau go-live',
       4: 'Mô hình governance gọn nhẹ cho SME: năm thành phần',
       5: 'Governance bắt đầu trước go-live',
       6: 'Sáu câu hỏi: ERP governance của bạn đang ở đâu?',
       0: 'ERP governance: ai chịu trách nhiệm\nkhi ERP không hoạt động đúng?'},
    s={1: 'ERP phản ánh doanh nghiệp, nên phải được cập nhật khi doanh nghiệp thay đổi.',
       2: 'Các dấu hiệu thường xuất hiện 6 đến 18 tháng sau go-live.',
       3: 'Không cần bộ phận mới: SME có thể giao vai trò cho người hiện có, miễn là xác định rõ.',
       4: 'Governance không phải bộ máy hành chính.',
       5: 'Ít nhất cần xác định ba việc này trước go-live.',
       6: 'Mỗi câu hỏi lấy từ checklist tự đánh giá trong bài.'},
    f={1: 'Sơ đồ minh họa khái niệm từ bài viết, không phải số liệu đo lường.',
       2: 'Phân tích từ bài viết, không phải thống kê.',
       3: 'Phân tích từ bài viết, không phải thống kê.',
       4: 'Phân tích từ bài viết, không phải thống kê.',
       5: 'Phân tích từ bài viết, không phải thống kê.',
       6: 'Câu hỏi tự đánh giá từ bài viết, là công cụ thảo luận định hướng, không phải phương pháp luận được chứng nhận.'},
    lt='Doanh nghiệp thay đổi', li=['Sản phẩm', 'Quy trình', 'Nhân sự', 'Cơ cấu'],
    rt='ERP', rd='Phản ánh hoạt động thực tế, nên phải cập nhật theo',
    nog='Không có governance', no=['Dữ liệu xuống cấp dần', 'Vấn đề không người xử lý tích lũy'],
    e1='Governance: vai trò, quy trình và quyết định giúp ERP phản ánh đúng thực tế sau go-live.',
    c2=[('Dữ liệu master kém chất lượng', 'Sản phẩm tạo không theo chuẩn, nhà cung cấp trùng, thông tin khách hàng lỗi thời.'),
        ('Vấn đề báo cáo nhưng không được xử lý', 'Lỗi chuyển qua nhiều tầng; không có ticket, SLA hay người chịu trách nhiệm cuối.'),
        ('Yêu cầu thay đổi không được quản lý', 'Không rõ ai quyết định, thực hiện, kiểm tra; có thay đổi không tài liệu.'),
        ('Quyền truy cập không được kiểm soát', 'Cấp quyền theo yêu cầu cá nhân; tài khoản nghỉ việc không bị khóa kịp.'),
        ('Không ai biết hệ thống vận hành ra sao', 'Không có báo cáo định kỳ; lãnh đạo chỉ biết khi có sự cố lớn.')],
    e2='Không ai được giao duy trì và không có quy trình thì vấn đề cứ tích lũy.',
    c3=[('ERP System Owner', 'Chịu trách nhiệm cuối cùng về mặt kinh doanh; quyết định thay đổi lớn và chịu trách nhiệm trước lãnh đạo.'),
        ('Master Data Manager', 'Chất lượng và tính nhất quán của dữ liệu nền: sản phẩm, nhà cung cấp, khách hàng, chart of accounts.'),
        ('Key Users / Super Users', 'Ít nhất một người mỗi bộ phận chính; hỗ trợ đồng nghiệp và chuyển yêu cầu thay đổi lên System Owner.'),
        ('IT / System Administrator', 'Hạ tầng, backup, bảo mật, quản lý người dùng và thực hiện thay đổi đã được phê duyệt.')],
    e3='Cần một người cụ thể, vì “mọi người cùng chịu trách nhiệm” thực tế là không ai chịu.',
    c4=[('Change Management Process', 'Mỗi thay đổi đi qua: yêu cầu, đánh giá tác động, phê duyệt, thực hiện, kiểm tra.'),
        ('Master Data Governance', 'Quy tắc thêm, sửa, vô hiệu hóa bản ghi; rà soát chất lượng định kỳ, ví dụ hằng quý.'),
        ('User Access Management', 'Cấp quyền theo vai trò, thu hồi khi nghỉ việc, rà soát ít nhất hằng năm.'),
        ('Periodic Health Check', 'System Owner rà soát ít nhất hằng quý: dữ liệu, vấn đề tồn đọng, mức sử dụng.'),
        ('Escalation Path rõ ràng', 'Người dùng biết liên hệ ai, qua kênh nào và khi nào được phản hồi.')],
    e4='Nhất quán, không phức tạp.',
    c5=[('ERP System Owner', 'Có người chịu trách nhiệm cuối cùng về hệ thống ngay từ đầu.'),
        ('Master Data Manager', 'Có một người cụ thể chịu trách nhiệm chất lượng dữ liệu nền.'),
        ('Quy trình Change Request', 'Có đường đi rõ ràng cho yêu cầu thay đổi sau go-live.')],
    e5='Quyết định ad hoc từ những tuần đầu rất khó đảo ngược sau này.',
    q6=['Đã có ERP System Owner được chỉ định rõ, có thẩm quyền quyết định và chịu trách nhiệm trước lãnh đạo chưa?',
        'Có người cụ thể chịu trách nhiệm chất lượng master data chưa?',
        'Người dùng có biết liên hệ ai và qua kênh nào khi gặp vấn đề không?',
        'Có quy trình rõ ràng xử lý yêu cầu thay đổi cấu hình không?',
        'Khi nhân viên nghỉ việc, tài khoản ERP được xử lý thế nào và trong bao lâu?',
        'Lần gần nhất kiểm tra chất lượng dữ liệu ERP là khi nào?'],
    e6='Nhiều câu trả lời “không rõ”: đó là khoảng trống governance cần lấp.',
    kick='OKELAS · Insights · ERP',
    gl='Go-live', gb='Nhà triển khai', gch=['System Owner', 'Master Data', 'Key Users', 'IT'],
    gc='Sau go-live, ai chịu trách nhiệm?',
)

EN = dict(
    mt=62,
    t={1: 'ERP does not run itself after go-live',
       2: 'Five warning signs of a governance gap',
       3: 'Four key roles after go-live',
       4: 'A lightweight governance model for SMEs: five elements',
       5: 'Governance starts before go-live',
       6: 'Six questions: where does your ERP governance stand?',
       0: 'ERP Governance:\nDefining Responsibility After Go-Live'},
    s={1: 'ERP reflects the organization, so it must be updated as the organization changes.',
       2: 'These typically appear six to eighteen months after go-live.',
       3: 'No new department needed: in an SME, assign roles to existing people, as long as they are explicit.',
       4: 'Governance is not bureaucracy.',
       5: 'At minimum, define these three things before go-live.',
       6: 'Each question comes from the self-assessment in the article.'},
    f={1: 'Conceptual diagram from the article, not measured data.',
       2: 'Analysis from the article, not statistics.',
       3: 'Analysis from the article, not statistics.',
       4: 'Analysis from the article, not statistics.',
       5: 'Analysis from the article, not statistics.',
       6: 'Self-assessment questions from the article, a discussion aid, not a certified methodology.'},
    lt='The organization changes', li=['Products', 'Processes', 'Staff', 'Structure'],
    rt='ERP', rd='Reflects actual operations, so it must be updated to match',
    nog='Without governance', no=['Data degrades over time', 'Unowned problems accumulate'],
    e1='Governance: roles, processes and decision rights that keep ERP accurate after go-live.',
    c2=[('Master data quality deteriorates', 'Products created off-convention, duplicate vendors, stale customer data.'),
        ('Problems reported but not resolved', 'Issues bounce between managers; no ticket system, SLA or final owner.'),
        ('Change requests are unmanaged', 'No clear decider, implementer or validator; some changes undocumented.'),
        ('User access is uncontrolled', 'Granted by verbal request; leavers keep access.'),
        ('Nobody knows how well it works', 'No regular reporting; leaders learn only when something breaks.')],
    e2='With no owner and no process, problems simply accumulate.',
    c3=[('ERP System Owner', 'Ultimate business-side responsibility; decides major changes and answers to leadership.'),
        ('Master Data Manager', 'Quality and consistency of foundational data: products, vendors, customers, chart of accounts.'),
        ('Key Users / Super Users', 'At least one per major department; support colleagues and route change requests to the System Owner.'),
        ('IT / System Administrator', 'Infrastructure, backups, security, user accounts and implementing approved changes.')],
    e3='One named person, not “everyone”: shared responsibility is no one’s responsibility.',
    c4=[('Change Management Process', 'Every change follows request, impact assessment, approval, implementation, validation.'),
        ('Master Data Governance', 'Rules for creating, modifying and retiring records; periodic review, for example quarterly.'),
        ('User Access Management', 'Access by role, revoked when people leave, reviewed at least annually.'),
        ('Periodic Health Check', 'At least quarterly, the System Owner reviews data, open issues and usage.'),
        ('Clear Escalation Path', 'Users know whom to contact, through which channel and what response to expect.')],
    e4='Consistent, not complex.',
    c5=[('ERP System Owner', 'A person with ultimate responsibility for the system from day one.'),
        ('Master Data Manager', 'One named person accountable for foundational data quality.'),
        ('Change request process', 'A defined path for change requests after go-live.')],
    e5='Ad hoc decisions in the first weeks are costly to undo.',
    q6=['Is there a designated ERP System Owner with decision authority who is accountable to leadership?',
        'Is a named person responsible for master data quality?',
        'Do users know who to contact and how when they hit an ERP problem?',
        'Is there a defined process for configuration change requests?',
        'When an employee leaves, how and how quickly is their ERP access revoked?',
        'When was data quality in the ERP last reviewed?'],
    e6='Several “unclear” answers are governance gaps to fill.',
    kick='OKELAS · Insights · ERP',
    gl='Go-live', gb='Implementation partner', gch=['System Owner', 'Master Data', 'Key Users', 'IT'],
    gc='After go-live, who is responsible?',
)

ALT = {
    'vi': {
        1: 'Doanh nghiệp thay đổi về sản phẩm, quy trình, nhân sự và cơ cấu nên ERP phải được cập nhật theo; không có governance thì dữ liệu xuống cấp dần và vấn đề không người xử lý tích lũy.',
        2: 'Năm dấu hiệu thiếu ERP governance: dữ liệu master kém chất lượng, vấn đề báo cáo nhưng không được xử lý, yêu cầu thay đổi không được quản lý, quyền truy cập không được kiểm soát và không ai biết hệ thống vận hành ra sao.',
        3: 'Bốn vai trò cần có sau go-live: ERP System Owner, Master Data Manager, Key Users hoặc Super Users, và IT hoặc System Administrator.',
        4: 'Năm thành phần của mô hình governance gọn nhẹ cho SME: quy trình quản lý thay đổi, governance master data, quản lý quyền truy cập, kiểm tra sức khỏe định kỳ và đường escalation rõ ràng.',
        5: 'Ba việc cần xác định trước go-live: ERP System Owner, Master Data Manager và quy trình Change Request.',
        6: 'Sáu câu hỏi tự đánh giá ERP governance: System Owner, người chịu trách nhiệm master data, kênh liên hệ, quy trình thay đổi cấu hình, xử lý tài khoản khi nghỉ việc và lần kiểm tra chất lượng dữ liệu gần nhất.',
        0: 'Một đường go-live ngăn cách nhà triển khai ở bên trái với khối ERP ở bên phải, bên dưới là bốn vai trò System Owner, Master Data, Key Users và IT chịu trách nhiệm sau go-live.'},
    'en': {
        1: 'The organization changes in products, processes, staff and structure so ERP must be updated to match; without governance data degrades over time and unowned problems accumulate.',
        2: 'Five warning signs of a governance gap: master data quality deteriorates, problems reported but not resolved, unmanaged change requests, uncontrolled user access and nobody knowing how well the system works.',
        3: 'Four key roles after go-live: ERP System Owner, Master Data Manager, Key Users or Super Users, and IT or System Administrator.',
        4: 'Five elements of a lightweight governance model for SMEs: change management process, master data governance, user access management, periodic health check and a clear escalation path.',
        5: 'Three things to define before go-live: the ERP System Owner, the Master Data Manager and the change request process.',
        6: 'Six self-assessment questions on ERP governance: System Owner, master data owner, contact channel, change request process, handling accounts when people leave and the last data quality review.',
        0: 'A go-live line separating the implementation partner on the left from the ERP block on the right, with four roles beneath it: System Owner, Master Data, Key Users and IT.'},
}

VI = bind(VI)
EN = curly(EN)
LANGS = {'vi': VI, 'en': EN}
NAMES = {1: 'erp-does-not-run-itself', 2: 'five-warning-signs', 3: 'four-key-roles', 4: 'five-lightweight-elements',
         5: 'before-go-live', 6: 'six-self-check-questions'}


def numc(f, x, y, n, col='p', r=15):
    f.circle(x, y, r, col)
    f._line(x, y - 10, str(n), 15, 700, 'wh', 'middle', 20)


def cards(f, L, k, key, fill, stroke, n, numbered=False, big=False):
    head(f, L, k)
    items = L[key]
    gap, y = 15, 134
    cw = round((1080 - gap * (n - 1)) / n)
    ts, ds = (18, 14) if big else (16, 13)
    top = 62 if numbered else 20
    need = 0
    for t, d in items:
        need = max(need, top + f.measure(t, ts, 700, cw - 32) + 10 + f.measure(d, ds, 400, cw - 32, 1.42) + 20)
    ch = round(need)
    for i, (t, d) in enumerate(items):
        x = 60 + i * (cw + gap)
        f.rect(x, y, cw, ch, fill, stroke, 16, 1.8)
        if numbered:
            numc(f, x + 32, y + 32, i + 1, stroke)
        th = f.para(x + 16, y + top, t, ts, 700, 'hd', cw - 32)
        f.para(x + 16, y + top + th + 10, d, ds, 400, 'tx', cw - 32, lhr=1.42)
    f.ink(y + ch + 16, L['e%d' % k])


def fig1(f, L):
    head(f, L, 1)
    y0, ch = 134, 170
    f.rect(60, y0, 480, ch, 'pt', 'p', 16, 1.8)
    f._line(84, y0 + 18, L['lt'], 20, 700, 'hd', 'start', 28)
    for i, t in enumerate(L['li']):
        r, c = divmod(i, 2)
        chip(f, 84 + c * 216, y0 + 66 + r * 48, 204, 38, t, 'p', 'bg', 15, 'hd')
    f.arrow(546, y0 + ch / 2, 654, y0 + ch / 2, 'gm', 2.5, 10)
    f.rect(660, y0, 480, ch, 'ink', None, 16)
    f._line(900, y0 + 34, L['rt'], 36, 700, 'onink', 'middle', 46)
    f.box_text(684, y0 + 86, 432, 60, L['rd'], 16, 400, 'onink', 4)
    ny = y0 + ch + 16
    nh = 72
    f.rect(60, ny, 1080, nh, 'gt', 'gm', 14, 1.6, '6 5')
    f.pill(80, ny - 12, L['nog'], 'a', 'bg', 12, 'start', 24, 10)
    for i, t in enumerate(L['no']):
        f.box_text(60 + i * 540, ny + 8, 540, nh - 8, t, 16, 700, 'hd', 20)
    f.ink(ny + nh + 16, L['e1'])


def fig2(f, L): cards(f, L, 2, 'c2', 'at', 'a', 5, numbered=True)
def fig3(f, L): cards(f, L, 3, 'c3', 'pt', 'p', 4, big=True)
def fig4(f, L): cards(f, L, 4, 'c4', 'at', 'a', 5, numbered=True)
def fig5(f, L): cards(f, L, 5, 'c5', 'pt', 'p', 3, numbered=True, big=True)


def fig6(f, L):
    head(f, L, 6)
    gap, y = 15, 134
    cw = 350
    need = 0
    for q in L['q6']:
        need = max(need, f.measure(q, 15, 700, cw - 76) + 32)
    ch = max(round(need), 84)
    for i, q in enumerate(L['q6']):
        r, c = divmod(i, 3)
        x, yy = 60 + c * (cw + gap), y + r * (ch + gap)
        f.rect(x, yy, cw, ch, 'pt', 'p', 14, 1.8)
        numc(f, x + 32, yy + ch / 2, i + 1, 'p')
        qh = f.measure(q, 15, 700, cw - 76)
        f.para(x + 60, yy + (ch - qh) / 2, q, 15, 700, 'hd', cw - 76)
    f.ink(y + 2 * ch + gap + 16, L['e6'])


def figcover(f, L):
    f.rect(0, 0, 1200, 630, 'bg', None, 0)
    f.rect(0, 0, 14, 630, 'p', None, 0)
    f._line(60, 44, L['kick'], 16, 700, 's', 'start', 22)
    f.para(60, 84, L['t'][0], 40, 700, 'hd', 1040, lhr=1.25)
    f.line(400, 310, 400, 520, 'gm', 2.5, '6 5')
    f.pill(400 - 44, 282, L['gl'], 'a', 'at', 14, 'start', 28, 14)
    f.rect(100, 350, 240, 80, 'gt', 'gm', 14, 1.8, '6 5')
    f.box_text(100, 350, 240, 80, L['gb'], 16, 700, 'mut', 10)
    f.rect(460, 330, 280, 120, 'ink', None, 18)
    f._line(600, 365, 'ERP', 40, 700, 'onink', 'middle', 50)
    for i, t in enumerate(L['gch']):
        chip(f, 460 + i * 150, 466, 140, 40, t, 'a', 'at', 14, 'hd')
    f.para(460, 530, L['gc'], 15, 700, 'a', 600)
    f.mark(H_COVER - 30)


H_COVER = 630
FIGS = {1: fig1, 2: fig2, 3: fig3, 4: fig4, 5: fig5, 6: fig6}


def build(sel=None):
    for lang, L in LANGS.items():
        for k in list(FIGS) + [0]:
            if sel and k not in sel:
                continue
            label = ALT[lang][k]
            fn = figcover if k == 0 else FIGS[k]
            name = f'erpg-00-og-cover-{lang}' if k == 0 else f'erpg-{k:02d}-{NAMES[k]}-{lang}'
            if k == 0:
                s = Fig(H_COVER, 'svg', False, label); fn(s, L)
                p = Fig(H_COVER, 'png', False, label); fn(p, L)
                d = Fig(H_COVER, 'png', True, label); fn(d, L)
                H = H_COVER
            else:
                s = make(fn, L, label, 'svg')
                H = s.H
                p = make(fn, L, label, 'png', False, H)
                d = make(fn, L, label, 'png', True, H)
            svg = s.svg()
            assert var_check(svg, p.svg()), 'adaptive vs light mismatch ' + name
            open(f'{OUT}/{lang}/{name}.svg', 'w', encoding='utf-8').write(svg)
            if k == 0:
                cairosvg.svg2png(bytestring=p.svg().encode('utf-8'), write_to=f'{OUT}/{lang}/{name}.png', output_width=1200)
            cairosvg.svg2png(bytestring=p.svg().encode('utf-8'), write_to=f'{CHK}/{name}-light.png', output_width=1200)
            cairosvg.svg2png(bytestring=d.svg().encode('utf-8'), write_to=f'{CHK}/{name}-dark.png', output_width=1200)
            print('ok', name, 'H', H)


if __name__ == '__main__':
    build([int(a) for a in sys.argv[1:]] or None)
