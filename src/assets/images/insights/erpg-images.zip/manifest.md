# Manifest hình bài ERP governance (VI + EN)

Tiền tố cụm: `erpg`. Cover PNG 1200×630; hình thường SVG (inline có dark mode; dùng `<img>` thì cần xuất PNG light).

## VI — `/images/insights/quan-tri-erp-governance/`

```yaml
cover_image: /images/insights/quan-tri-erp-governance/erpg-00-og-cover-vi.png
og_image: /images/insights/quan-tri-erp-governance/erpg-00-og-cover-vi.png
cover_alt: "Một đường go-live ngăn cách nhà triển khai ở bên trái với khối ERP ở bên phải, bên dưới là bốn vai trò System Owner, Master Data, Key Users và IT chịu trách nhiệm sau go-live."
```

| # | File | Đặt ở mục |
|---|---|---|
| 1 | `erpg-01-erp-does-not-run-itself-vi.svg` | ERP không tự vận hành |
| 2 | `erpg-02-five-warning-signs-vi.svg` | Dấu hiệu thiếu ERP governance |
| 3 | `erpg-03-four-key-roles-vi.svg` | Các vai trò cần có sau go-live |
| 4 | `erpg-04-five-lightweight-elements-vi.svg` | Governance structure cho SME: không cần phức tạp |
| 5 | `erpg-05-before-go-live-vi.svg` | Governance bắt đầu trước go-live |
| 6 | `erpg-06-six-self-check-questions-vi.svg` | Tự đánh giá: ERP governance của bạn đang ở đâu? |

**Alt:**

1. `erp-does-not-run-itself`: Doanh nghiệp thay đổi về sản phẩm, quy trình, nhân sự và cơ cấu nên ERP phải được cập nhật theo; không có governance thì dữ liệu xuống cấp dần và vấn đề không người xử lý tích lũy.
2. `five-warning-signs`: Năm dấu hiệu thiếu ERP governance: dữ liệu master kém chất lượng, vấn đề báo cáo nhưng không được xử lý, yêu cầu thay đổi không được quản lý, quyền truy cập không được kiểm soát và không ai biết hệ thống vận hành ra sao.
3. `four-key-roles`: Bốn vai trò cần có sau go-live: ERP System Owner, Master Data Manager, Key Users hoặc Super Users, và IT hoặc System Administrator.
4. `five-lightweight-elements`: Năm thành phần của mô hình governance gọn nhẹ cho SME: quy trình quản lý thay đổi, governance master data, quản lý quyền truy cập, kiểm tra sức khỏe định kỳ và đường escalation rõ ràng.
5. `before-go-live`: Ba việc cần xác định trước go-live: ERP System Owner, Master Data Manager và quy trình Change Request.
6. `six-self-check-questions`: Sáu câu hỏi tự đánh giá ERP governance: System Owner, người chịu trách nhiệm master data, kênh liên hệ, quy trình thay đổi cấu hình, xử lý tài khoản khi nghỉ việc và lần kiểm tra chất lượng dữ liệu gần nhất.

**Markdown mẫu:**
```md
![Doanh nghiệp thay đổi về sản phẩm, quy trình, nhân sự và cơ …](/images/insights/quan-tri-erp-governance/erpg-01-erp-does-not-run-itself-vi.svg)
![Năm dấu hiệu thiếu ERP governance: dữ liệu master kém chất l…](/images/insights/quan-tri-erp-governance/erpg-02-five-warning-signs-vi.svg)
![Bốn vai trò cần có sau go-live: ERP System Owner, Master Dat…](/images/insights/quan-tri-erp-governance/erpg-03-four-key-roles-vi.svg)
![Năm thành phần của mô hình governance gọn nhẹ cho SME: quy t…](/images/insights/quan-tri-erp-governance/erpg-04-five-lightweight-elements-vi.svg)
![Ba việc cần xác định trước go-live: ERP System Owner, Master…](/images/insights/quan-tri-erp-governance/erpg-05-before-go-live-vi.svg)
![Sáu câu hỏi tự đánh giá ERP governance: System Owner, người …](/images/insights/quan-tri-erp-governance/erpg-06-six-self-check-questions-vi.svg)
```

## EN — `/images/insights/erp-governance/`

```yaml
cover_image: /images/insights/erp-governance/erpg-00-og-cover-en.png
og_image: /images/insights/erp-governance/erpg-00-og-cover-en.png
cover_alt: "A go-live line separating the implementation partner on the left from the ERP block on the right, with four roles beneath it: System Owner, Master Data, Key Users and IT."
```

| # | File | Đặt ở mục |
|---|---|---|
| 1 | `erpg-01-erp-does-not-run-itself-en.svg` | ERP Does Not Run Itself |
| 2 | `erpg-02-five-warning-signs-en.svg` | Warning Signs of a Governance Gap |
| 3 | `erpg-03-four-key-roles-en.svg` | Key Roles After Go-Live |
| 4 | `erpg-04-five-lightweight-elements-en.svg` | A Lightweight Governance Model for SMEs |
| 5 | `erpg-05-before-go-live-en.svg` | Governance Starts Before Go-Live |
| 6 | `erpg-06-six-self-check-questions-en.svg` | Self-Assessment |

**Alt:**

1. `erp-does-not-run-itself`: The organization changes in products, processes, staff and structure so ERP must be updated to match; without governance data degrades over time and unowned problems accumulate.
2. `five-warning-signs`: Five warning signs of a governance gap: master data quality deteriorates, problems reported but not resolved, unmanaged change requests, uncontrolled user access and nobody knowing how well the system works.
3. `four-key-roles`: Four key roles after go-live: ERP System Owner, Master Data Manager, Key Users or Super Users, and IT or System Administrator.
4. `five-lightweight-elements`: Five elements of a lightweight governance model for SMEs: change management process, master data governance, user access management, periodic health check and a clear escalation path.
5. `before-go-live`: Three things to define before go-live: the ERP System Owner, the Master Data Manager and the change request process.
6. `six-self-check-questions`: Six self-assessment questions on ERP governance: System Owner, master data owner, contact channel, change request process, handling accounts when people leave and the last data quality review.

**Markdown mẫu:**
```md
![The organization changes in products, processes, staff and s…](/images/insights/erp-governance/erpg-01-erp-does-not-run-itself-en.svg)
![Five warning signs of a governance gap: master data quality …](/images/insights/erp-governance/erpg-02-five-warning-signs-en.svg)
![Four key roles after go-live: ERP System Owner, Master Data …](/images/insights/erp-governance/erpg-03-four-key-roles-en.svg)
![Five elements of a lightweight governance model for SMEs: ch…](/images/insights/erp-governance/erpg-04-five-lightweight-elements-en.svg)
![Three things to define before go-live: the ERP System Owner,…](/images/insights/erp-governance/erpg-05-before-go-live-en.svg)
![Six self-assessment questions on ERP governance: System Owne…](/images/insights/erp-governance/erpg-06-six-self-check-questions-en.svg)
```
